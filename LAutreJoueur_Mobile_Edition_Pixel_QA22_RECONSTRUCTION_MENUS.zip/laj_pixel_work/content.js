/* L’Autre Joueur · Mobile 2D · world generation, no external dependencies. */
(function(root){
'use strict';
const chapterNames=[
'Le Premier Seuil','Les Traces','Le Choix','Le Miroir','La Première Coopération','Le Détour',
'Le Couloir des Murmures','Les Dalles Endormies','La Salle des Doubles','Les Trois Serments',
'La Porte Sans Clé','Le Passage Renversé','Les Marches Brisées','Les Horloges Muettes',
'La Chambre des Échos','Les Reflets Trompeurs','Le Relais Perdu','Les Jardins Oubliés',
'Les Veilleurs de Pierre','La Galerie des Noms','Le Cercle des Ombres','Les Portes Jumelles',
'Le Chemin du Retour','Les Runes du Silence','La Salle des Décisions','Le Labyrinthe Mouvant',
'Les Veines de Cuivre','La Marche du Golem','Les Yeux du Labyrinthe','La Confiance Fragile',
'Le Puits des Souvenirs','La Dernière Patrouille','La Première Vérité','L’Absence',
'L’Origine des Traces','Le Carrefour des Choix',
'Le Plateau des Sentinelles','La Forêt de Basalte','La Mer des Brumes','La Bibliothèque Infinie',
'Le Désert des Horloges','Les Jardins Suspendus','Les Marais des Reflets',
'La Cité des Portes','Les Profondeurs Cristallines','La Faille du Silence',
'Le Royaume des Golems','La Nécropole des Mémoires','La Cathédrale des Serments','Au-delà du Dernier Seuil'];
const descriptions=[
'Une lanterne, trois marques et le sentiment d’être suivi.','Des empreintes vraies et de fausses pistes conduisent à une première découverte.','Deux chemins mettent la confiance à l’épreuve.','Ce que montre une surface n’est pas toujours devant elle.','La première porte que deux personnes peuvent ouvrir ensemble.','Un chemin s’ouvre quand un autre se referme.'];
const epicDescriptions=[
'Des tours de veille balayent un plateau de pierre sous un ciel de cendres.',
'Des arbres de basalte émergent des brumes et barrent les anciennes voies.',
'Des étendues mouvantes dissimulent les sentiers entre des îlots de pierre.',
'Des galeries d’archives infinies conservent des noms qui ne devraient plus exister.',
'Des horloges enfouies découpent un désert de poussière et de rouages.',
'Des terrasses oubliées retiennent une végétation nourrie par des lanternes antiques.',
'Des mares reflètent de faux passages au milieu de sentiers submergés.',
'Une cité sans habitants s’ouvre sur des centaines de portes rivales.',
'Des aiguilles de cristal dispersent la lumière en fragments glacés.',
'Un gouffre silencieux semble absorber les sons, les traces et les promesses.',
'Des géants de pierre veillent sur les marches de leur ancien royaume.',
'Les sépultures murmurent les souvenirs d’inconnus et de compagnons perdus.',
'Une cathédrale monumentale attend que deux voix honorent leur serment.',
'Au bord du monde, le dernier seuil attend une décision que personne ne peut prendre à ta place.'
];
const epicLore=[
'La surveillance fut installée bien avant ton arrivée.',
'Les racines de pierre poussent autour des noms oubliés.',
'Le brouillard garde une direction que la carte ne montre pas.',
'Une page vierge porte deux signatures à l’encre pâle.',
'Une montre arrêtée marque l’heure de la première séparation.',
'Un jardinier inconnu entretenait les lanternes, non les fleurs.',
'Un reflet reste immobile après ton départ.',
'Une porte ne mène nulle part ; elle se souvient pourtant de pas.',
'Un cristal répète un nom que personne n’a prononcé.',
'Le silence de la faille n’efface pas les souvenirs.',
'Les golems gardent des serments qu’ils ne peuvent comprendre.',
'Une stèle porte une date dont tu ne te souviens pas.',
'Deux symboles gravés ne forment qu’un seul engagement.',
'Le dernier seuil ne dit jamais qui doit le franchir.'
];
const themes=[
{n:'Basalte et ivoire',floor:'#202b31',wall:'#53606a',edge:'#83959d',accent:'#e6ae6a',mist:'#06090d',detail:'#293940'},
{n:'Sépia et poussière',floor:'#322c30',wall:'#6d5c5a',edge:'#a9968a',accent:'#e4af80',mist:'#080609',detail:'#423339'},
{n:'Cuivre et ardoise',floor:'#263039',wall:'#617077',edge:'#b1b9b6',accent:'#e4a363',mist:'#080b0d',detail:'#38454b'},
{n:'Miroirs bleus',floor:'#202939',wall:'#506d81',edge:'#94bcd0',accent:'#a8e3ed',mist:'#060b14',detail:'#263e53'},
{n:'Pierre et ambre',floor:'#322f32',wall:'#716a68',edge:'#c1a49a',accent:'#f3bd76',mist:'#0b090b',detail:'#474146'},
{n:'Galeries écarlates',floor:'#33282c',wall:'#77545c',edge:'#b08586',accent:'#e8aa72',mist:'#0e070a',detail:'#52343a'},
{n:'Mousse violette',floor:'#262435',wall:'#595878',edge:'#aea1cd',accent:'#c7a4ff',mist:'#080712',detail:'#39354e'},
{n:'Cendres froides',floor:'#242d31',wall:'#526672',edge:'#a9b8c2',accent:'#bce7ef',mist:'#070b0f',detail:'#384850'},
{n:'Pierre verte',floor:'#28332e',wall:'#546e63',edge:'#a1b6a7',accent:'#b7dd95',mist:'#070d09',detail:'#3a4940'},
{n:'Or oublié',floor:'#332f2a',wall:'#776a52',edge:'#c0b18b',accent:'#f3d68e',mist:'#0e0b07',detail:'#4a4135'},
{n:'Silence glacé',floor:'#26323b',wall:'#617c88',edge:'#b2d3de',accent:'#afe7ff',mist:'#070e14',detail:'#385361'},
{n:'Obsidienne',floor:'#23232b',wall:'#575563',edge:'#b0a9b6',accent:'#f4b0a6',mist:'#090810',detail:'#3b3945'},
{n:'Ruines enchantées',floor:'#2d3040',wall:'#656c8f',edge:'#adb7e7',accent:'#a3d8ff',mist:'#090914',detail:'#424766'},
{n:'Cristaux profonds',floor:'#222a3c',wall:'#4f6497',edge:'#8dc5ee',accent:'#a7eaff',mist:'#05091a',detail:'#2d4473'}];
const epicThemes=[
{n:'Plateau des Sentinelles',floor:'#282d35',wall:'#667584',edge:'#c0d1d8',accent:'#a5c5e8',mist:'#080c12',detail:'#3b5163'},
{n:'Forêt de Basalte',floor:'#27342f',wall:'#527264',edge:'#a8cfaf',accent:'#c2df8d',mist:'#07120c',detail:'#345343'},
{n:'Mer des Brumes',floor:'#27353c',wall:'#64808a',edge:'#bad5e0',accent:'#b9f2ef',mist:'#061118',detail:'#345460'},
{n:'Bibliothèque Infinie',floor:'#302d37',wall:'#766780',edge:'#cfb8cc',accent:'#ebc78c',mist:'#0c0810',detail:'#4e415a'},
{n:'Désert des Horloges',floor:'#393128',wall:'#90745a',edge:'#e1be8f',accent:'#f5d995',mist:'#120b06',detail:'#5b4c37'},
{n:'Jardins Suspendus',floor:'#26382f',wall:'#58846b',edge:'#a4d5b3',accent:'#d8d3a1',mist:'#051109',detail:'#3f634b'},
{n:'Marais des Reflets',floor:'#253739',wall:'#597985',edge:'#b0d3cf',accent:'#8ed7e7',mist:'#041111',detail:'#355a63'},
{n:'Cité des Portes',floor:'#343139',wall:'#877987',edge:'#c9bac9',accent:'#edcba3',mist:'#0d0b12',detail:'#504959'},
{n:'Profondeurs Cristallines',floor:'#22263e',wall:'#6469a4',edge:'#a9bdff',accent:'#80eaff',mist:'#050619',detail:'#373d77'},
{n:'Faille du Silence',floor:'#20282e',wall:'#586974',edge:'#a4b7be',accent:'#dedde3',mist:'#05080c',detail:'#30444c'},
{n:'Royaume des Golems',floor:'#38312b',wall:'#867560',edge:'#d0b996',accent:'#ffbd75',mist:'#0c0905',detail:'#584739'},
{n:'Nécropole des Mémoires',floor:'#302b3b',wall:'#756a92',edge:'#bfb4d5',accent:'#e3a9ca',mist:'#080713',detail:'#4a3b63'},
{n:'Cathédrale des Serments',floor:'#2d2e33',wall:'#777c84',edge:'#ced1d5',accent:'#f5d4ac',mist:'#090a0e',detail:'#464c52'},
{n:'Au-delà du Dernier Seuil',floor:'#252e3d',wall:'#6a8199',edge:'#c2def3',accent:'#f0d7a7',mist:'#060912',detail:'#374960'}];
const motifs=['gravures','traces','serments','miroirs','relais','échos','lanternes','sceaux'];
const behaviors=['observe tes hésitations','ralentit lorsque tu t’éloignes','te rejoint par le chemin sûr','attend devant les reflets','peut maintenir un mécanisme','cherche un détour','réagit aux bruits','évite les dalles instables','observe tes choix répétés','fait signe devant un danger','se souvient des portes refermées','cherche les chemins non visités','surveille les marches','s’arrête pour écouter','retient les traces','hésite devant les miroirs','prend position près des relais','suit la lumière','évite les gardiens de pierre','marque les noms découverts','reste hors des ombres profondes','reconnaît les portes semblables','attend un retour','se méfie des runes effacées','réagit à ton choix précédent','suit les nouveaux passages','observe les mécanismes','ralentit devant les golems','t’avertit d’une présence','module sa distance selon la confiance','reconnaît un souvenir','évite les rondes','cherche la première vérité','résiste à la séparation','se souvient de votre rencontre','s’adapte à l’issue de ton choix'];
function chapter(n){if(n<1||n>50)throw Error('chapitre hors limites');const huge=n>36, t=huge?epicThemes[n-37]:themes[(n-1)%themes.length];return {n,name:chapterNames[n-1],kind:huge?'domaine':'labyrinthe',size:huge?'Immense':'Labyrinthe',palette:t,theme:t.n, mode:['glyph','memory','relay','mirror','glyph','relay','memory','mirror'][(n-1)%8],behavior:behaviors[(n-1)%behaviors.length],description:huge?epicDescriptions[n-37]:(descriptions[n-1]||`Entre ${t.n.toLowerCase()}, trois marques guident tes pas et une présence garde sa distance.`),lore:huge?`Fragment ${String(n).padStart(2,'0')} : ${epicLore[n-37]}`:`Fragment ${String(n).padStart(2,'0')} : Les murs ont gardé ce que les voyageurs ont laissé derrière eux.`,enemySet:n<3?['sentry']:n<10?['sentry','patrol']:n<25?['sentry','patrol','golem']:['sentry','patrol','golem'],special:n===50?'warden':null};}
function rand(seed){let s=(seed>>>0)||1;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};}
const shuffle=(list,r)=>{for(let i=list.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[list[i],list[j]]=[list[j],list[i]];}return list;};
function inside(w,h,x,y){return x>0&&y>0&&x<w-1&&y<h-1;}
function bfs(tiles,w,h,start){const seen=new Int32Array(w*h).fill(-1),queue=[start];seen[start[1]*w+start[0]]=0;let head=0;while(head<queue.length){const [x,y]=queue[head++],d=seen[y*w+x]+1;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const xx=x+dx,yy=y+dy;if(!inside(w,h,xx,yy)||tiles[yy*w+xx]||seen[yy*w+xx]>=0)continue;seen[yy*w+xx]=d;queue.push([xx,yy]);}}return {seen,queue};}
// Trace, based on the hand-authored PC chapter of the same campaign.
function firstThreshold() {
  const w = 48, h = 36;
  const tiles = new Uint8Array(w * h).fill(1);
  const rooms = [
    {id:'meeting', x:2, y:14, w:12, h:10},
    {id:'gallery', x:16, y:2, w:13, h:11},
    {id:'crossing', x:33, y:14, w:13, h:10},
    {id:'reunion', x:16, y:24, w:13, h:11},
    {id:'niche', x:2, y:2, w:10, h:8}
  ];
  const routes = [
    [[12,17],[14,17],[14,9],[17,9]],
    [[27,9],[30,9],[30,17],[34,17]],
    [[39,22],[39,27],[27,27]],
    [[17,30],[13,30],[13,20],[12,20]],
    [[5,15],[5,11],[5,8]]
  ];
  const clear = (x, y) => { tiles[y * w + x] = 0; };
  for (const room of rooms) {
    for (let y = room.y + 1; y < room.y + room.h - 1; y++) {
      for (let x = room.x + 1; x < room.x + room.w - 1; x++) clear(x, y);
    }
  }
  for (const route of routes) {
    for (let i = 1; i < route.length; i++) {
      let [x,y] = route[i - 1];
      const [endX,endY] = route[i];
      const dx = Math.sign(endX - x), dy = Math.sign(endY - y);
      const width = Math.abs(endX - x) + Math.abs(endY - y);
      for (let step = 0; step <= width; step++, x += dx, y += dy) {
        for (let yy = -1; yy <= 1; yy++) {
          for (let xx = -1; xx <= 1; xx++) clear(x + xx, y + yy);
        }
      }
    }
  }
  for (let y = 5; y < 9; y++) tiles[y * w + 23] = 1;
  return {
    ...chapter(1), w, h, tiles, rooms, layout:'trace-pc', start:[7,19], companion:[8,20],
    runes:[[14,13],[20,7],[37,17]], exit:[22,29], secret:[5,5], decoy:[15,11],
    traps:[[15,10],[38,19],[27,28],[11,17]],
    torches:[[4,18],[11,16],[14,15],[18,5],[27,9],[30,14],[34,17],[41,19],[38,25],[22,27],[7,7]],
    enemies:[{id:0,kind:'sentry',x:43.5,y:20.5,home:[43.5,20.5],heading:2.8,seed:5,speed:.8,patrolPhase:0,alert:0}],
    seed:92178
  };
}
function generate(n){if(n===1)return firstThreshold();const ch=chapter(n),r=rand(n*90467+1711),huge=n>36;
const w=huge?75+(n%4)*8:35+(n%4)*4,h=huge?67+(n%3)*8:35+(n%3)*6;
const tiles=new Uint8Array(w*h).fill(1),set=(x,y,v=0)=>{if(inside(w,h,x,y))tiles[y*w+x]=v;};const start=[1,1],stack=[start];set(1,1);let dirs=[[2,0],[-2,0],[0,2],[0,-2]];
while(stack.length){const [x,y]=stack[stack.length-1];const options=shuffle(dirs.slice(),r).filter(([dx,dy])=>inside(w,h,x+dx,y+dy)&&tiles[(y+dy)*w+x+dx]);if(!options.length){stack.pop();continue;}const [dx,dy]=options[0];set(x+dx/2,y+dy/2);set(x+dx,y+dy);stack.push([x+dx,y+dy]);}
// Sparse optional short-cuts: looped mazes; no impassable scripted gates.
for(let i=0;i<(huge?180:22+n%12);i++){const x=2+Math.floor(r()*(w-4)),y=2+Math.floor(r()*(h-4));if(tiles[y*w+x]===1&&((!tiles[y*w+x-1]&&!tiles[y*w+x+1])||(!tiles[(y-1)*w+x]&&!tiles[(y+1)*w+x])))set(x,y);}
// Every large region receives several grand halls, intentionally connected to maze paths.
if(huge){for(let k=0;k<7;k++){const x=3+Math.floor(r()*(w-12)),y=3+Math.floor(r()*(h-12)),rw=3+Math.floor(r()*4),rh=3+Math.floor(r()*4);for(let yy=y;yy<Math.min(y+rh*2,h-2);yy++)for(let xx=x;xx<Math.min(x+rw*2,w-2);xx++)set(xx,yy);}}
const {seen,queue}=bfs(tiles,w,h,start);let unreachable=0;for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++)if(!tiles[y*w+x]&&seen[y*w+x]===-1)unreachable++;
// Rare isolated cleared areas are connected to the main maze by a straight safe corridor.
if(unreachable){for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++)if(!tiles[y*w+x]&&seen[y*w+x]===-1){let xx=x;while(xx>1){set(xx,y);xx--;}let yy=y;while(yy>1){set(1,yy);yy--;}}}
const distances=bfs(tiles,w,h,start);const far=distances.queue.slice().sort((a,b)=>distances.seen[b[1]*w+b[0]]-distances.seen[a[1]*w+a[0]]);const exit=far[0];const reserved=[start,exit];function pick(minDistance=5,preferFar=true){let items=distances.queue.filter(p=>distances.seen[p[1]*w+p[0]]>minDistance&&!reserved.some(q=>Math.abs(q[0]-p[0])+Math.abs(q[1]-p[1])<5));if(!items.length)items=distances.queue.filter(p=>!reserved.some(q=>q[0]===p[0]&&q[1]===p[1]));const pool=preferFar?items.filter(p=>distances.seen[p[1]*w+p[0]]>=distances.seen[exit[1]*w+exit[0]]*.25):items;if(pool.length)items=pool;const p=items[Math.floor(r()*items.length)]||start;reserved.push(p);return [...p];}
const runes=[pick(10),pick(10),pick(10)],secret=pick(8),traps=Array.from({length:huge?16:4+Math.floor(n/10)},()=>pick(7,false));
const torchCount=huge?30:11;const torches=Array.from({length:torchCount},()=>pick(4,false));
const enemies=[];const count=huge?15+Math.floor(n/8):Math.max(1,Math.min(8,Math.floor(n/5)+1));for(let i=0;i<count;i++){const p=pick(12,false);let kind=ch.enemySet[(i+n)%ch.enemySet.length];if(ch.special&&i===0)kind='warden';enemies.push({id:i,kind,x:p[0]+.5,y:p[1]+.5,home:[p[0]+.5,p[1]+.5],heading:r()*Math.PI*2,seed:r()*10,speed:kind==='golem'?.44:kind==='warden'?1.16:.8,patrolPhase:r()*6,alert:0});}
return {...ch,w,h,tiles,start,exit,runes,secret,traps,torches,enemies,seed:n*90467+1711};}
function path(world,a,b,max=4500){const w=world.w,h=world.h,start=[Math.floor(a[0]),Math.floor(a[1])],end=[Math.floor(b[0]),Math.floor(b[1])];if(start[0]===end[0]&&start[1]===end[1])return [end];const seen=new Uint8Array(w*h),prev=new Int32Array(w*h).fill(-1),q=[start[1]*w+start[0]];seen[q[0]]=1;let head=0,goal=end[1]*w+end[0];while(head<q.length&&head<max){const idx=q[head++],x=idx%w,y=Math.floor(idx/w);if(idx===goal)break;for(const d of [1,-1,w,-w]){const ni=idx+d,nx=ni%w,ny=Math.floor(ni/w);if(nx<1||ny<1||nx>=w-1||ny>=h-1||Math.abs(nx-x)+Math.abs(ny-y)!==1||seen[ni]||world.tiles[ni])continue;seen[ni]=1;prev[ni]=idx;q.push(ni);}}if(!seen[goal])return [];const out=[];let cur=goal;while(cur!==q[0]){out.push([cur%w+.5,Math.floor(cur/w)+.5]);cur=prev[cur];if(cur<0)break;}return out.reverse();}
const api={chapters:Array.from({length:50},(_,i)=>chapter(i+1)),chapter,generate,path,bfs};root.LAJContent=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
