# L’Autre Joueur — Édition Pixel

Le jeu se joue en paysage. Sur téléphone, utilise le joystick à gauche, **Agir**, **L’Autre** et **Courir** à droite. Sur ordinateur, utilise les flèches ou ZQSD, E pour agir, F pour appeler le compagnon, M pour la carte et Échap pour faire une pause.

## Lancer la copie locale

Sur Mac, désarchive le fichier, ouvre le dossier dans Terminal, puis lance :

```bash
python3 -m http.server 8080
```

Ouvre ensuite http://localhost:8080/ dans le navigateur. Avec un hébergement HTTPS, le manifeste et le service worker permettent d’ajouter le jeu à l’écran d’accueil et de mettre ses ressources en cache après le premier chargement complet.

## Contenu

- Le Premier Seuil reprend la géométrie 48 × 36 du chapitre PC **Trace**. Les positions des trois empreintes, de la niche et de la sortie correspondent au plan PC. L’interaction tactile, les pièges et le choix à la sortie utilisent les règles de la campagne mobile.
- Les 49 cartes suivantes reprennent les données de la Mobile V3.2 et utilisent le nouveau moteur graphique pixel art. Le chapitre 1 a reçu la composition décorative spécifique de cette édition.
- Les trois musiques fournies sont incluses. La sauvegarde de cette édition est isolée. Une sauvegarde mobile V3.2 est importable dans les Réglages. Les chapitres débloqués, choix et souvenirs sont conservés à l’import. Si tu reprends au milieu du chapitre 1 de la V3.2, sa nouvelle carte redémarre à l’entrée. Tu retrouveras ta position lors des prochaines ouvertures de cette édition.
- Les sprites transparents sont dans `art/sprites-pixel.png`, avec quatre images de 24 × 24 pixels par ligne. De haut en bas, le voyageur, L’Autre, le drone, le golem et le Gardien.

## Installer l’application sur iPhone

Cette édition est préparée comme une application web installable (PWA). Pour l’installer sur iPhone, le jeu doit d’abord être publié sur une adresse HTTPS accessible. Une archive ZIP seule ne peut pas être installée directement comme une application iOS.

1. Ouvre l’adresse HTTPS du jeu dans **Safari** sur l’iPhone.
2. Appuie sur **Partager**.
3. Choisis **Sur l’écran d’accueil**.
4. Vérifie le nom « L’Autre Joueur », puis appuie sur **Ajouter**.
5. Lance le jeu depuis la nouvelle icône. Oriente l’iPhone en paysage.
6. Laisse le premier chargement se terminer avec une connexion active : le service worker met ensuite en cache le jeu et ses ressources pour les ouvertures hors ligne.

Sur ordinateur, ouvre l’adresse HTTPS dans un navigateur compatible et utilise la commande d’installation proposée par celui-ci, si elle est disponible.

**État actuel :** le manifeste, les icônes, le mode autonome, l’orientation paysage et le cache hors ligne sont intégrés au paquet. La publication sur un hébergement HTTPS et l’essai d’installation sur un iPhone physique restent à effectuer. Cette édition n’est pas une application App Store signée.
