# Installer L’Autre Joueur sur iPhone

L’Édition Pixel est configurée comme une application web installable (PWA), avec affichage autonome, icône et orientation paysage.

## Prérequis

Le jeu doit être publié sur une adresse HTTPS accessible depuis l’iPhone. Le fichier ZIP de développement ne s’installe pas directement depuis l’app Fichiers : iOS exige une page web sécurisée pour l’installation PWA.

## Installation

1. Ouvrir l’adresse HTTPS du jeu dans Safari.
2. Appuyer sur le bouton **Partager**.
3. Choisir **Sur l’écran d’accueil**.
4. Conserver le nom **L’Autre Joueur**, puis appuyer sur **Ajouter**.
5. Lancer le jeu depuis son icône et tourner l’iPhone en paysage.
6. Effectuer le premier chargement complet en ligne. Le cache hors ligne sera ensuite disponible pour les ressources mises en cache.

## Limites de cette version

- Il s’agit d’une PWA, pas encore d’une application native distribuée via l’App Store.
- La publication HTTPS et le test sur iPhone physique restent à faire.
- La compatibilité hors ligne doit être confirmée sur l’appareil cible après installation.
