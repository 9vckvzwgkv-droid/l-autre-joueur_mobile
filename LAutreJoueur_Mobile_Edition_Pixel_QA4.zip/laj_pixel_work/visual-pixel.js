/* Presentation layer for the existing Mobile 2D maps. One solid tile stays one solid tile. */
(function (root) {
  'use strict';

  const atl = new Image();
  atl.src = 'art/sprites-pixel.png';
  const size = 24;
  const cache = new Map();
  const moss = ['#1a3330', '#2b4e40', '#426b4e', '#6e8760'];
  const ink = '#0d171f';
  const directions = [[0,-1,1], [1,0,2], [0,1,4], [-1,0,8]];
  const symbols = {
    '1': ['00100','01100','00100','00100','01110'],
    '2': ['01110','00010','01110','01000','01110'],
    '3': ['01110','00010','00110','00010','01110'],
    '✦': ['00100','00100','11111','00100','00100']
  };

  function variant(x, y, chapter) {
    let v = Math.imul(x + 89, 1597334677) ^ Math.imul(y + 131, 3812015801) ^ Math.imul(chapter, 2798796415);
    v = Math.imul(v ^ (v >>> 16), 2246822507);
    return (v ^ (v >>> 13)) >>> 0;
  }

  function mix(a, b, amount) {
    const first = parseInt(a.slice(1), 16), second = parseInt(b.slice(1), 16);
    const rgb = [16, 8, 0].map(shift => {
      const low = (first >> shift) & 255, high = (second >> shift) & 255;
      return Math.round(low + (high - low) * amount).toString(16).padStart(2, '0');
    });
    return '#' + rgb.join('');
  }

  function rect(c, color, x, y, w, h) {
    c.fillStyle = color;
    c.fillRect(x, y, w, h);
  }

  function stone(c, x, y, w, h, base, edge) {
    rect(c, base, x + 1, y, w - 2, h);
    rect(c, base, x, y + 1, w, h - 2);
    rect(c, edge, x + 1, y, w - 2, 1);
    rect(c, mix(base, ink, .35), x + 1, y + h - 1, w - 2, 1);
  }

  function tuft(c, x, y, seed) {
    for (let i = 0; i < 4; i++) {
      const skew = ((seed >> (i * 2)) & 3) - 1, px = x + i * 2, height = 2 + ((seed >> (i + 3)) & 3);
      rect(c, moss[0], px, y - height, 2, height);
      rect(c, moss[1 + i % 2], px + skew, y - height, 2, 2);
      if (i % 2) rect(c, moss[3], px + skew, y - height, 1, 1);
    }
  }

  function wallTile(c, palette, mask, seed, greenery, chapter) {
    const top = mix(palette.wall, ink, .43);
    rect(c, mix(top, ink, .42), 0, 0, size, size);
    for (let y = -1; y < size; y += 8) {
      const offset = y % 3 ? -5 : 0;
      for (let x = offset; x < size; x += 11) {
        const value = variant(seed + x, y, 1) % 7;
        const base = mix(top, palette.edge, value * .037);
        stone(c, x, y, 10, 7, base, mix(base, palette.edge, .24));
        if (value > 3) rect(c, mix(base, ink, .45), x + 6, y + 3, 3, 1);
        if (value === 6) rect(c, mix(base, ink, .48), x + 6, y + 3, 1, 3);
      }
    }
    const edge = mix(palette.edge, top, .31);
    if (mask & 1) {
      rect(c, edge, 0, 0, size, 1);
      rect(c, top, 0, 1, size, 2);
    }
    if (mask & 2) {
      rect(c, ink, 22, 0, 2, size);
      rect(c, edge, 21, 0, 1, size);
    }
    if (mask & 8) {
      rect(c, ink, 0, 0, 1, size);
      rect(c, edge, 1, 0, 1, size);
    }
    if (mask & 4) {
      rect(c, edge, 0, 10, size, 2);
      rect(c, mix(top, palette.edge, .24), 0, 12, size, 3);
      rect(c, ink, 0, 15, size, 9);
      for (let x = 0; x < size; x += 8) {
        const base = mix(top, ink, .41 + ((seed + x) % 3) * .13);
        stone(c, x, 15, 7, 8, base, mix(base, top, .24));
        rect(c, ink, x + 5, 19, 1, 3);
      }
      rect(c, '#0b1219', 0, 23, size, 1);
      if (chapter === 1 && seed % 3 === 0) {
        for (const x of [3, 17]) {
          rect(c, '#111d25', x - 1, 2, 6, 19);
          rect(c, '#576762', x, 4, 4, 15);
          rect(c, '#7c8b76', x, 4, 1, 13);
          rect(c, '#313f41', x + 3, 5, 1, 14);
          rect(c, '#62736a', x - 1, 17, 6, 2);
        }
      }
      if (greenery && seed % 4 !== 0) {
        tuft(c, 2 + seed % 5, 14, seed * 293);
        if (seed % 3 === 0) {
          for (let i = 0; i < 8; i++) {
            const x = 10 + Math.floor(i / 3);
            rect(c, moss[i % 2], x, 14 + i, 1, 1);
            if (i % 3 === 0) rect(c, moss[2], x - 1, 14 + i, 3, 1);
          }
        }
      }
    }
    if (mask && seed % 4 === 1) {
      const tone = mix(palette.accent, top, .46);
      const x = mask & 8 ? 4 : 15, y = 5;
      rect(c, ink, x - 1, y - 1, 6, 6);
      if (chapter === 45) {
        rect(c, tone, x + 1, y, 2, 4);
        rect(c, palette.accent, x + 1, y, 1, 2);
      } else if (chapter === 40 || chapter === 41) {
        rect(c, tone, x, y + 1, 4, 2);
        rect(c, tone, x + 1, y, 2, 4);
      } else {
        rect(c, tone, x + 1, y, 2, 1);
        rect(c, tone, x, y + 1, 1, 2);
        rect(c, tone, x + 3, y + 1, 1, 2);
        rect(c, tone, x + 1, y + 3, 2, 1);
      }
    }
  }

  function floorTile(c, palette, mask, seed, greenery) {
    const base = mix(palette.floor, '#4b6061', .22);
    const edge = mix(base, palette.edge, .24);
    rect(c, mix(base, ink, .42), 0, 0, size, size);
    for (let y = -1; y < size; y += 6) {
      const offset = ((y + seed) % 4) * 2 - 6;
      for (let x = offset; x < size; x += 9) {
        const v = variant(x, y, seed) % 6;
        stone(c, x, y, 9, 6, mix(base, palette.detail, v * .08), mix(edge, base, v * .11));
        if (v === 3) rect(c, mix(base, ink, .29), x + 5, y + 3, 3, 1);
      }
    }
    if (mask & 1) {
      rect(c, mix(ink, base, .25), 0, 0, size, 2);
      rect(c, mix(ink, base, .54), 0, 2, size, 1);
    }
    if (mask & 2) rect(c, mix(ink, base, .48), 23, 0, 1, size);
    if (mask & 8) rect(c, mix(ink, base, .48), 0, 0, 1, size);
    if (mask & 4) rect(c, mix(ink, base, .28), 0, 23, size, 1);
    if (greenery && mask && seed % 3 !== 0) {
      const x = mask & 8 ? 1 : mask & 2 ? 16 : 5 + seed % 7;
      const y = mask & 1 ? 5 : mask & 4 ? 23 : 14;
      tuft(c, x, y, seed + 117);
    }
  }

  function open(world, x, y) {
    return x >= 0 && y >= 0 && x < world.w && y < world.h && world.tiles[y * world.w + x] === 0;
  }

  function microDetail(c, wall, palette, seed, mask, chapter) {
    // Small deterministic pixel accents: no per-frame randomness or world changes.
    const v = (n) => variant(seed * 17 + n * 13, chapter * 7 + n, 3);
    if (wall) {
      // Chipped masonry edges and narrow damp seams give the walls more depth.
      if (v(1) % 3 === 0) {
        const x = 3 + v(2) % 17, y = 4 + v(3) % 13;
        rect(c, mix(palette.wall, ink, .28), x, y, 3, 1);
        rect(c, mix(palette.edge, ink, .34), x + 1, y + 1, 2, 1);
      }
      if (v(4) % 4 === 0) {
        const x = 4 + v(5) % 16, y = 3 + v(6) % 7;
        rect(c, mix(palette.detail, ink, .22), x, y, 1, 4 + v(7) % 4);
        rect(c, mix(palette.edge, ink, .48), x + 1, y + 2, 1, 2);
      }
      if (mask & 4 && v(8) % 3 === 0) {
        const x = 3 + v(9) % 17;
        rect(c, mix(palette.edge, ink, .28), x, 12, 2, 1);
        rect(c, mix(palette.detail, ink, .18), x + 1, 13, 1, 2);
      }
    } else {
      // Hairline cracks, mineral flecks and worn tile corners, kept low contrast.
      if (v(10) % 3 === 0) {
        const x = 3 + v(11) % 16, y = 3 + v(12) % 15;
        const crack = mix(palette.detail, ink, .30);
        rect(c, crack, x, y, 1, 2);
        rect(c, crack, x + 1, y + 2, 2, 1);
        if (v(13) % 2) rect(c, crack, x + 2, y + 3, 1, 2);
      }
      if (v(14) % 2 === 0) {
        const x = 3 + v(15) % 18, y = 3 + v(16) % 18;
        rect(c, mix(palette.edge, palette.floor, .52), x, y, 1, 1);
        if (v(17) % 3 === 0) rect(c, mix(palette.detail, ink, .12), x + 1, y, 1, 1);
      }
      if ((mask & 1) && v(18) % 3 === 0) {
        rect(c, mix(palette.edge, palette.floor, .36), 3 + v(19) % 16, 2, 2, 1);
      }
    }
  }

  function tile(c, x, y, z, wall, p, world) {
    let mask = 0;
    for (const [dx, dy, bit] of directions) {
      if (open(world, x + dx, y + dy) === wall) mask |= bit;
    }
    const seed = variant(x, y, world.n) % 23;
    const key = `${world.n}/${wall}/${mask}/${seed}`;
    let part = cache.get(key);
    if (!part) {
      part = document.createElement('canvas');
      part.width = part.height = size;
      const paint = part.getContext('2d');
      const greenery = [1,7,9,18,38,42,43].includes(world.n) || p.n === 'Pierre verte';
      if (wall) wallTile(paint, p, mask, seed, greenery, world.n);
      else floorTile(paint, p, mask, seed, greenery);
      microDetail(paint, wall, p, seed, mask, world.n);
      if (cache.size >= 700) cache.delete(cache.keys().next().value);
      cache.set(key, part);
    }
    c.drawImage(part, x * z, y * z, z, z);
  }

  function light(c, x, y, radius, rgb, strength) {
    const beam = c.createRadialGradient(x, y, 0, x, y, radius);
    beam.addColorStop(0, `rgba(${rgb},${strength})`);
    beam.addColorStop(.45, `rgba(${rgb},${strength * .48})`);
    beam.addColorStop(1, `rgba(${rgb},0)`);
    rect(c, beam, x - radius, y - radius, radius * 2, radius * 2);
  }

  function drawActor(c, actor, z, t, row, flip, reduced) {
    const x = Math.round(actor.x * z), y = Math.round(actor.y * z);
    const scale = Math.max(1, Math.round(z / (row === 3 ? 21 : row > 1 ? 25 : 21)));
    let state = motion.get(actor);
    if (!state) {
      state = {x: actor.x, y: actor.y, t, steps: 0, active: -2};
      motion.set(actor, state);
    }
    const delta = Math.hypot(actor.x - state.x, actor.y - state.y);
    if (delta > .0001 && delta < .6) {
      state.steps += delta;
      state.active = t;
    }
    state.x = actor.x;
    state.y = actor.y;
    const moving = t - state.active < .12;
    const frame = reduced ? 0 : row === 2 || row === 4 ? Math.floor(t * 6) % 4
      : moving ? Math.floor(state.steps * 7) % 4 : 0;
    c.save();
    c.translate(x, y);
    rect(c, '#080f19a8', -8 * scale, 4 * scale, 15 * scale, 3 * scale);
    if (atl.complete && atl.naturalWidth) {
      if (flip) c.scale(-1, 1);
      c.drawImage(atl, frame * size, row * size, size, size,
        -size / 2 * scale, -16 * scale, size * scale, size * scale);
    } else {
      rect(c, row === 0 ? '#e6bd7a' : '#efaabd', -3, -4, 6, 8);
    }
    c.restore();
  }

  const motion = new WeakMap();

  function person(c, actor, z, human, t, reduced) {
    const flip = Math.cos(actor.angle) < -.13;
    const color = human ? '255,174,85' : '239,128,160';
    const scale = Math.max(1, Math.round(z / 21));
    light(c, actor.x * z + (flip ? -7 : 7) * scale, actor.y * z, z * .95, color, .28);
    drawActor(c, actor, z, t, human ? 0 : 1, flip, reduced);
  }

  function enemy(c, actor, z, t, reduced) {
    const row = actor.kind === 'golem' ? 3 : actor.kind === 'warden' ? 4 : 2;
    const lit = actor.alert > .4;
    light(c, actor.x * z, actor.y * z, z, lit ? '244,93,116' : '124,190,183', lit ? .29 : .1);
    drawActor(c, actor, z, t, row, Math.cos(actor.heading) < -.13, reduced);
  }

  function local(c, x, y, z, draw) {
    const scale = Math.max(1, Math.round(z / 24));
    c.save();
    c.translate(Math.round(x), Math.round(y));
    c.scale(scale, scale);
    draw();
    c.restore();
  }

  function symbol(c, x, y, label, color, z, trace = false) {
    if (trace) light(c, x, y, z * .9, color === "#87e3d9" ? "130,220,203" : "247,175,102", .24);
    local(c, x, y, z, () => {
      rect(c, '#111b23', -7, -5, 14, 11);
      rect(c, '#17242d', -5, -7, 10, 15);
      rect(c, color + '80', -5, -7, 10, 1);
      rect(c, color + '56', -7, -4, 1, 8);
      rect(c, color + '56', 6, -4, 1, 8);
      rect(c, color + '55', -5, 7, 10, 1);
      if (trace) {
        rect(c, color + '88', -4, -3, 2, 3);
        rect(c, color + 'ac', -3, 1, 2, 2);
        rect(c, color + '88', 2, -1, 2, 3);
        rect(c, color + 'ac', 2, 3, 2, 2);
      }
      symbols[label].forEach((line, j) => {
        [...line].forEach((bit, i) => {
          if (bit === '1') rect(c, color, i - 2, j - 2, 1, 1);
        });
      });
    });
  }

  function torch(c, x, y, z, t) {
    light(c, x, y, z, '251,164,79', .17);
    const flicker = Math.floor(t * 6) % 3;
    local(c, x, y, z, () => {
      rect(c, '#1c2429', -4, 3, 8, 5);
      rect(c, '#8f7660', -4, 3, 8, 1);
      rect(c, '#ae6552', -3, -3, 6, 6);
      rect(c, '#f6a35f', -2, -5, 4, 6);
      rect(c, '#ffd086', -1 + flicker - 1, -6 - flicker, 2, 6);
      rect(c, '#fff0bd', -1, -2, 2, 3);
    });
  }

  function gate(c, x, y, z, active) {
    local(c, x, y, z, () => {
      rect(c, '#101b23', -9, -5, 18, 14);
      rect(c, '#263844', -7, -8, 14, 3);
      rect(c, '#607276', -5, -10, 10, 2);
      rect(c, '#53676a', -9, -5, 3, 13);
      rect(c, '#53676a', 6, -5, 3, 13);
      rect(c, active ? '#64bbb5' : '#596275', -5, -6, 10, 1);
      rect(c, '#0e1822', -5, -3, 10, 10);
      rect(c, active ? '#b4f4d4' : '#ad8799', -1, -3, 2, 7);
      rect(c, active ? '#b4f4d4' : '#ad8799', -2, -1, 4, 2);
      rect(c, '#6b7370', -10, 8, 20, 2);
    });
  }

  function trap(c, x, y, z, spent) {
    local(c, x, y, z, () => {
      rect(c, '#17181d', -9, -8, 18, 16);
      rect(c, spent ? '#30292d' : '#75484b', -8, -7, 16, 14);
      rect(c, '#262127', -6, -5, 12, 10);
      for (let i = -6; i <= 6; i += 2) {
        const y = -5 + Math.abs(i);
        rect(c, spent ? '#47363b' : '#f0a378', i, y, 2, 2);
      }
      rect(c, '#803f49', -2, 4, 4, 1);
    });
  }

  function landmarks(c, z, world) {
    if (!world.rooms) return;
    const signs = {
      meeting: '#758f67',
      gallery: '#aac19c',
      crossing: '#6a8d90',
      reunion: '#b38e79',
      niche: '#71888e'
    };
    for (const room of world.rooms) {
      const x = (room.x + room.w / 2) * z;
      const y = (room.y + room.h / 2) * z;
      const color = signs[room.id];
      if (room.id === 'meeting') {
        light(c, x, y - z, z * 3.4, '107,169,123', .23);
      }
      local(c, x, y, z, () => {
        const radius = room.id === 'niche' ? 12 : 22;
        c.globalAlpha = .35;
        for (const side of [-1, 1]) {
          rect(c, color, -radius, side * radius, radius * 2 + 1, 1);
          rect(c, color, side * radius, -radius, 1, radius * 2 + 1);
          rect(c, color, side * radius - 2, -2, 5, 5);
        }
        rect(c, color, -1, -7, 2, 15);
        rect(c, color, -5, -1, 10, 2);
        if (room.id === 'gallery') {
          rect(c, color, -12, -4, 4, 8);
          rect(c, color, 8, -4, 4, 8);
        }
      });
    }
    const steps = [[9.7,18.8], [10.1,18.55], [10.6,18.35], [11,18.05],
      [11.5,17.9], [11.9,17.61], [12.4,17.46], [12.8,17.25],
      [13.3,17.05], [13.8,16.77], [14.2,16.3], [14.65,15.8]];
    for (let i = 0; i < steps.length; i++) {
      const [x,y] = steps[i];
      if (!open(world, Math.floor(x), Math.floor(y))) continue;
      local(c, x * z, y * z, z, () => {
        rect(c, '#87ab82', -1, -1, 2, 2);
        rect(c, '#a7b288', 1, -1, 1, 1);
      });
    }
    const [x,y] = world.decoy;
    symbol(c, (x + .5) * z, (y + .5) * z, '✦', '#a18eac', z);
  }

  function afterFog(c, {player, other, cam, z, w, h, timer, reduced}) {
    const x = w / 2 + (player.x - cam.x) * z;
    const y = h / 2 + (player.y - cam.y) * z;
    const ox = w / 2 + (other.x - cam.x) * z;
    const oy = h / 2 + (other.y - cam.y) * z;
    c.save();
    c.globalCompositeOperation = 'screen';
    light(c, x, y, z * 2.9, '247,174,95', .15);
    light(c, ox, oy, z * 1.7, '188,105,145', .10);
    for (let i = 0; i < 13; i++) {
      const phase = i * 2.399 + (reduced ? 0 : timer * .12);
      const distance = z * (.25 + i * .155);
      const px = x + Math.cos(phase) * distance, py = y + Math.sin(phase) * distance * .74;
      rect(c, i % 4 ? '#d6a96d4d' : '#bde7bd63', Math.round(px / 2) * 2, Math.round(py / 2) * 2, 2, 2);
    }
    c.restore();
  }

  function attract(c, w, h) {
    rect(c, '#0c151b', 0, 0, w, h);
  }

  root.LAJPixelArt = {tile, person, enemy, afterFog, attract, symbol, torch, gate, trap, landmarks};
})(window);
