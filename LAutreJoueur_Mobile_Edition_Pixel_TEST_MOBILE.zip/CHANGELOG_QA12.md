# QA12 — Modernisation des menus et de l’interface

## Modifications
- Ajout de `ui-modern.css`, une feuille de style dédiée aux écrans de menu et panneaux d’interface.
- Refonte visuelle de l’accueil, des boutons, des panneaux secondaires, de la sélection des chapitres, des réglages, du guide, de la carte, du carnet et des dialogues.
- Amélioration des états de focus clavier, des zones tactiles et de la lisibilité sur petits écrans.
- Ajout de la nouvelle feuille de style au HTML et au précache du service worker.
- Cache PWA incrémenté de r12 à r13 pour éviter de conserver l’ancienne interface.

## Préservation
Aucun changement apporté à `game.js`, `content.js`, `visual-pixel.js`, aux cartes, collisions, déplacements, ennemis, IA, énigmes, pièges, progression, sauvegardes, commandes ou audio.
Les identifiants HTML des contrôles existants sont conservés.

## Vérifications effectuées
- Syntaxe JavaScript : game.js, content.js et visual-pixel.js valides.
- Pré-vol QA5 : 10/10 contrôles réussis.
- 79 identifiants HTML uniques.
- Nouvelle feuille de style présente dans index.html et dans le précache PWA.
- Comparaison avec l’archive QA11 : seuls index.html et sw.js ont été modifiés, avec ajout de ui-modern.css et de la documentation QA12.

## Limites
Aucun test de rendu en navigateur réel, ni test physique iPhone/Android n’a été effectué dans cette session. La validation visuelle finale reste à faire sur l’appareil cible.
