# QA51 — Réfraction des cristaux

- Au chapitre 45, chaque caverne possède un cristal à orienter vers une couleur cible propre à son sceau.
- Le joueur utilise **Agir** près du cristal pour le tourner d’un quart de tour. Le rayon, sa direction et la teinte cible sont montrés par le motif pixel art et le retour contextuel.
- Les trois orientations cibles diffèrent ; le sceau ne s’ouvre qu’une fois le rayon accordé à sa teinte.
- Le journal de chapitre indique les teintes déjà accordées et celles encore à régler.
- Les rotations restent dans la sauvegarde exportée ou locale et sont contrôlées à l’import.
- La carte affiche désormais les sceaux restants dans leur ordre rituel réel, y compris pour les ordres renversés.
- Cache hors ligne porté à `laj-mobile-pixel-r60`.

## Vérifications

- Analyse syntaxique des scripts JavaScript principaux et du script intégré dans `index.html`.
- Simulation des trois couleurs cibles du chapitre 45 : aucune n’est accordée au départ, et chacune devient validée à son orientation cible.
- Simulation du bouton **Agir** sur un cristal : l’orientation avance d’un quart de tour et le retour annonce la teinte obtenue.
- Les coordonnées de sceau, de cristal et de sortie restent accessibles ; les cinquante cartes gardent des sorties reliées.
- Le rendu et le confort de la commande sur téléphone réel restent à vérifier.
