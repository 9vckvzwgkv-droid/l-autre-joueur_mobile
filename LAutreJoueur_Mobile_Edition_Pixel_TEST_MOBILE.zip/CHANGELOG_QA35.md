# QA35 — Objectifs répartis dans les salles

## Exploration
- Dans les chapitres 2 à 50, les trois sceaux, le fragment de mémoire et la sortie occupent cinq salles distinctes.
- La sortie est choisie dans une salle éloignée du départ ; les sceaux sont répartis sur des chambres de distance croissante.
- Le souvenir privilégie une salle marquée comme alcôve.
- Ce placement exploite les salles ajoutées en QA34 et encourage l'exploration à travers plusieurs lieux.

## Commandes mobiles et caméra
- Les entrées du joystick et du clavier sont compensées par la projection oblique, afin que le déplacement corresponde à la direction visible dans les salles 2.5D.
- Le chapitre 1 conserve sa géométrie PC et sa projection de dessus.

## Sauvegarde et hors ligne
- Le numéro de géométrie passe à 3. Les sauvegardes gardent les sceaux, souvenirs, choix et confiance ; la position, la carte locale et l'état des pièges sont replacés au seuil lors de la migration des anciens emplacements d'objectifs.
- Le cache PWA passe à `laj-mobile-pixel-r37`.

## Contrôles
- Tous les objectifs et objets restent accessibles dans les 50 cartes.
- Les sceaux, souvenirs et sorties des chapitres 2 à 50 apparaissent dans cinq salles distinctes.
- La compensation entrée/projection est vérifiée dans huit directions de commande.
- Aucun essai visuel ou tactile sur appareil n'est revendiqué.
