# QA53 — Les faisceaux du Plateau des Sentinelles

- Le chapitre 37 place trois tours de veille dans des salles distinctes, avec une ligne de vue dégagée vers une balise commune.
- Leurs faisceaux balayent le plateau puis convergent deux fois par cycle ; les cônes prennent une teinte turquoise pendant la fenêtre commune.
- Chaque sceau exige que les faisceaux soient alignés et que le joueur reste hors de portée visuelle. Des positions praticables à l’abri des trois cônes existent près de chacun des sceaux.
- Une icône pixel art marque la balise. Le rendu des faisceaux, la carte et le contexte proche montrent l’état de la convergence et de la zone masquée.
- Le chapitre passe à `mapVersion` 10. Une ancienne sauvegarde reprend au seuil avec ses sceaux acquis ; son exploration de chapitre repart avec la nouvelle carte.
- Le cache hors ligne passe à `laj-mobile-pixel-r62`.

## Vérifications

- Analyse syntaxique des scripts `content.js`, `game.js` et `visual-pixel.js`.
- Les 50 chapitres générés conservent 50 topologies et identifiants de scénario distincts, des sorties reliées et des pièges sans doublon.
- Chapitre 37 : trois tours sur des cases libres, distinctes des pièges et avec vue sur la balise ; chaque sceau a une approche ombragée atteignable pendant l’alignement.
- Simulation des fenêtres : alignement au début du cycle et à 8 secondes, balayage désaccordé à 4 secondes ; la condition échoue si le joueur est vu.
- Chapitre 39 : ses trois ponts et trois reflets restent présents après cette modification.
- Les ressources déclarées dans le cache hors ligne sont présentes.
- Les essais de jeu complet et sur iPhone/Android réels restent à faire.
