# QA52 — Les courants de la Mer des Brumes

- Le graphe du chapitre 39 forme désormais un archipel de grandes îles reliées par des ponts choisis, au lieu d’un parcours en serpent.
- Trois véritables traversées entre îlots portent une flèche et doivent être franchies dans l’ordre, dans le sens du courant.
- Trois reflets trompeurs se trouvent sur des passages internes aux îles ; leur aspect en rides les distingue des ponts.
- Le contexte de jeu indique le courant attendu, le sens à suivre et les reflets ; le journal et la carte affichent l’avancement et les repères découverts.
- Les passages réussis sauvegardent leur avancement et déplacent le point sûr.
- Le chapitre passe à `mapVersion` 10. Une ancienne sauvegarde reprend au seuil : les sceaux acquis restent, tandis que l’exploration et les traversées recommencent avec la nouvelle carte ; son point sûr est replacé au seuil. Le cache hors ligne passe à `laj-mobile-pixel-r61`.

## Vérifications

- Analyse syntaxique des scripts `content.js`, `game.js` et `visual-pixel.js`.
- Parcours des 50 chapitres générés : 50 topologies et identifiants de scénario distincts, sorties reliées, aucun piège dupliqué.
- Chapitre 39 : carte de 99 × 67 cases, 32 salles, trois ponts et trois reflets accessibles, tous séparés.
- Simulation : un reflet, un pont pris à rebours et un pont franchi dans le désordre ne font pas avancer l’épreuve ; les trois courants réussissent dans l’ordre.
- Toutes les ressources déclarées dans le cache hors ligne existent.
- Le rendu sur appareil et le confort de déplacement tactile restent à vérifier sur iPhone et Android réels.
