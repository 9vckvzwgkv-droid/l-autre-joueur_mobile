(()=>{'use strict';
  const intro=document.getElementById('launch-intro');
  const game=document.getElementById('game');
  const skip=document.getElementById('launch-skip');
  if(!intro||!game)return;
  let reduced=false;
  try{reduced=!!(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);}
  catch(_){reduced=false;}
  try{
    const saved=JSON.parse(localStorage.getItem('lautrejoueur-mobile-2d-pixel')||'null');
    reduced=reduced||saved?.options?.motion===true;
  }catch(_){/* The intro must not depend on browser storage. */}
  if(reduced)intro.classList.add('motion-reduced');
  let closed=false;
  const close=()=>{
    if(closed)return;
    closed=true;
    intro.classList.add('is-closing');
    intro.setAttribute('aria-hidden','true');
    intro.setAttribute('inert','');
    window.setTimeout(()=>{
      intro.hidden=true;
      game.inert=false;
      game.removeAttribute('aria-hidden');
    },reduced?130:360);
  };
  skip?.addEventListener('click',close,{once:true});
  intro.addEventListener('pointerdown',event=>{
    if(event.target===intro||event.target.closest('.launch-intro__art,.launch-intro__shade,.launch-intro__brand'))close();
  },{passive:true});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!closed)close();});
  window.setTimeout(close,reduced?220:1550);
})();
