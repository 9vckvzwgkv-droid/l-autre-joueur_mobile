# QA47 — Épreuves des chapitres 46 et 47

- Chapitre 46 : l’épreuve du silence exige maintenant un appel effectué pendant le rituel, puis trois secondes complètes sans nouvel appel.
- Chapitre 47 : trois marques de pierre numérotées commandent les golems l’un après l’autre. Chaque golem suit un chemin de retour vers son socle et y reste ; les trois doivent être revenus avant d’activer un sceau.
- Le carnet et le repère de proximité affichent les rappels et les socles rejoints. La progression reprend après fermeture puis réouverture du chapitre.
- Chapitre 28 : l’épreuve de la cour des golems vérifie maintenant que le joueur est hors de vue et que le golem lui tourne le dos.
- Les marqueurs du chapitre 47 ont leur motif pixel art de pierre et d’ambre. La géométrie, les pièges et la version de carte restent compatibles avec les sauvegardes existantes.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r56`.

## Vérifications

- Analyse syntaxique réussie pour les scripts de jeu, de contenu, de pixel art et le service worker, ainsi que pour le script intégré à la page.
- Épreuve du chapitre 46 contrôlée : aucun rappel = échec ; moins de trois secondes = échec ; trois secondes après le rappel = réussite.
- Chapitre 47 contrôlé avant et après le retour des golems ; simulation des trois retours par leurs trajets jusqu’aux socles réussie.
- Les 50 chapitres conservent un chemin entre le départ et la sortie, ainsi que des profils de topologie, épreuves, ordres/règles de sceaux et empreintes de carte distincts.
- Les essais complets sur iPhone et Android, l’équilibrage en partie et la publication restent à faire.
