# QA43 — Pièges accordés aux grands domaines

- Les 14 grands domaines disposent maintenant de profils d’effet propres : ralentissement (durée et intensité) et portée/durée de leurs alarmes varient avec le thème.
- Dans la Faille du Silence, trois pièges spéciaux ramènent au dernier point sûr sans effacer les sceaux ni compter une mort. La faille se consume après déclenchement et reçoit un rendu bleu clair distinct.
- Le point sûr est désormais conservé dans la sauvegarde, pour que le rappel reste correct après une fermeture et une reprise de partie. Les anciennes sauvegardes repartent du seuil si elles ne contiennent pas cette donnée.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r52`.

## Vérification

- Analyse syntaxique réussie pour `content.js`, `game.js`, `visual-pixel.js` et `sw.js`.
- Génération des 50 chapitres contrôlée ; 14 profils finaux distincts et trois pièges de rappel dans le chapitre 46.
- Déclenchement isolé du rappel, d’un ralentissement et d’une alarme vérifié ; les rendus pixel correspondants s’exécutent et le point sûr est conservé dans la sauvegarde.
- Les essais sur téléphone et le parcours complet des 50 chapitres restent à faire.
