# QA18 — Identité finalisée et fenêtres contextuelles

Base : QA17.

## Identité visuelle — finition
- Sceau de confirmation cohérent avec le langage visuel de reliques et de pierre sombre.
- Halo et animation subtile du sceau, avec respect de `prefers-reduced-motion`.
- Finitions harmonisées avec les bordures et tons or patiné introduits en QA17.

## Fenêtres contextuelles
- Confirmation compacte, centrée, avec hauteur maximale et contenu défilant si nécessaire.
- Adaptation spécifique aux écrans mobiles en paysage et aux écrans de faible hauteur.
- Boutons d'action accessibles et assez grands pour le tactile.
- Fermeture via Annuler, touche Échap ou clic sur le voile extérieur.
- Focus initial et navigation clavier contenue dans la fenêtre.
- Notifications existantes (`#notice`) habillées comme de petits messages discrets, en bas de l'écran, sans recouvrir inutilement le jeu.

## Périmètre préservé
- Modifications limitées à `index.html`, `ui-modern.css`, `game.js` et `sw.js`, plus ce journal.
- Aucun changement aux chapitres, cartes, énigmes, pièges, progression, sauvegardes, audio ou logique de l'IA.
- Clé de cache service worker incrémentée en r19.

## Vérification et limites
- Vérification statique des éléments HTML et des fonctions de confirmation/notification déjà présentes.
- Vérification que les changements JS sont limités à l'ouverture/fermeture et à l'accessibilité de la boîte de confirmation.
- Aucun test réel sur iPhone/Safari ni test manuel complet du jeu effectué dans cette étape.
