# QA55 — Les horloges du désert

- Le chapitre 41 place trois cadrans arrêtés dans trois salles distinctes. Leurs aiguilles doivent être réglées sur trois heures différentes : 3 h, 6 h et 9 h.
- Une fois ces cadrans accordés, le grand cadran placé au centre doit être activé pour ouvrir la cour.
- La règle déjà présente reste en jeu : les sceaux ne répondent qu’à leur heure dans le cycle du désert.
- Les horloges et le grand cadran ont des marqueurs pixel art. La carte et le journal affichent les réglages, l’ouverture de la cour et l’heure du cycle.
- Les aiguilles et l’état du cadran central sont sauvegardés. Le chapitre passe à `mapVersion` 10 ; les sceaux acquis restent conservés lors de la mise à jour de la carte.
- Le cache hors ligne passe à `laj-mobile-pixel-r64`.

## Vérifications

- Analyse syntaxique de `content.js`, `game.js` et `visual-pixel.js`.
- Génération des 50 chapitres : 50 topologies et identifiants d’énigme distincts, sorties accessibles et aucune position de piège dupliquée.
- Chapitre 41 : trois horloges accessibles dans des salles distinctes ; grand cadran central accessible dans une quatrième salle ; cibles différentes ; objectifs éloignés des pièges et des runes.
- Les ressources déclarées dans le cache hors ligne sont toutes présentes.
- Les parcours complets, la difficulté, le toucher et le rythme réel des fenêtres restent à vérifier en jeu et sur téléphones.
