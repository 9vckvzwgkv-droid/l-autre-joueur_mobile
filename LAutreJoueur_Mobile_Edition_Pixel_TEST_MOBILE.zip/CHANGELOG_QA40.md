# QA40 — Plans et énigmes des chapitres 2 à 36

- Remplacement des familles de graphes réutilisées par 35 topologies distinctes pour les chapitres 2 à 36, avec des plans à salles et des couloirs praticables.
- Ajout d’une épreuve jouable propre à chacun de ces 35 chapitres : traces, choix, miroirs, coopération, détours, échos, dalles rythmiques, cours jumelles, serments, ordre inversé, terrasses, relais, racines, ombres, retours, orientations, patrouilles et synthèses.
- Ajout de repères visibles et activables pour le détour, les relais et les noms ; les marqueurs des cours jumelles et de la chambre d’écho donnent un repère spatial.
- Le chapitre 13 place ses trois sceaux dans des salles avec changement de perspective. Les chapitres 16 et 33 disposent de côtés d’approche accessibles de part et d’autre des sceaux.
- Ajout d’un nom de piège thématique et d’une palette nuancée propre à chacun des chapitres intermédiaires ; le rendu pixel reçoit maintenant le style et la couleur propres au chapitre.
- Les nouvelles données de progression (choix de branche, trace examinée et retour au départ) sont conservées dans la sauvegarde.
- Version de génération portée à 9 et cache PWA porté à `laj-mobile-pixel-r46`.

## Contrôles effectués

- Analyse syntaxique réussie pour `content.js`, `game.js` et `visual-pixel.js`.
- 50 empreintes de cases de carte différentes ; 35 identifiants de topologie, 35 identifiants d’épreuve et 35 palettes thématiques uniques pour les chapitres 2 à 36.
- Les 50 cartes générées ont leurs cases de sol reliées au départ ; les sceaux, souvenirs, sorties, repères, lanternes et cibles d’orientation sont posés sur des cases libres.
- Les trois approches de chaque chapitre miroir ont un passage libre ; les chapitres à double rive disposent d’un espace libre des deux côtés.
- Les marqueurs interactifs ne chevauchent ni piège, ni lanterne, ni sceau, ni souvenir, ni ennemi.
- Les 35 familles de pièges intermédiaires ont un libellé propre.

Ces contrôles portent sur le code et les cartes générées. Ils ne remplacent pas les parties complètes, le réglage de difficulté ou l’essai sur téléphone.
