#!/usr/bin/env python3
"""Static release preflight for L'Autre Joueur Mobile 2D."""
from pathlib import Path
from html.parser import HTMLParser
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
class Audit(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.refs=[]; self.buttons=[]; self.current_button=None
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a: self.ids.append(a['id'])
        if tag in ('script','img','link','audio','source'):
            value=a.get('src') or a.get('href')
            if value and not value.startswith(('http:','https:','data:','#')): self.refs.append(value.split('?')[0])
        if tag=='button': self.current_button={'id':a.get('id','(sans id)'), 'label':a.get('aria-label') or a.get('title'), 'text':''}
    def handle_data(self, data):
        if self.current_button is not None: self.current_button['text'] += data.strip()
    def handle_endtag(self, tag):
        if tag=='button' and self.current_button is not None:
            if not self.current_button['label'] and not self.current_button['text']:
                self.buttons.append(self.current_button['id'])
            self.current_button=None

checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))

html=(ROOT/'index.html').read_text(encoding='utf-8')
p=Audit(); p.feed(html)
check('IDs HTML uniques', len(p.ids)==len(set(p.ids)), f'{len(p.ids)} IDs, {len(p.ids)-len(set(p.ids))} doublon(s)')
missing=[r for r in p.refs if not (ROOT/r).exists()]
check('Ressources locales HTML présentes', not missing, ', '.join(missing[:8]))
check('Boutons avec nom accessible', not p.buttons, ', '.join(p.buttons))
manifest=json.loads((ROOT/'manifest.webmanifest').read_text(encoding='utf-8'))
check('Manifeste PWA orientation mobile + standalone', manifest.get('orientation') in ('any','portrait','landscape') and manifest.get('display')=='standalone', f"{manifest.get('orientation')} / {manifest.get('display')}")
for icon in manifest.get('icons',[]): check(f"Icône {icon.get('sizes')}", (ROOT/icon['src']).is_file(), icon['src'])
sw=(ROOT/'sw.js').read_text(encoding='utf-8')
match=re.search(r"const\s+FILES\s*=\s*\[(.*?)\];",sw,re.S)
files=re.findall(r"['\"]([^'\"]+)['\"]",match.group(1)) if match else []
missing_sw=[f for f in files if not (ROOT/f.replace('./','')).exists()]
check('Service worker précache ressources existantes', bool(files) and not missing_sw, ', '.join(missing_sw))
check('Service worker cache versionné', bool(re.search(r"laj-mobile-pixel-r\d+",sw)), '')
check('Sauvegarde locale + copie de secours', 'localStorage.setItem(SAVE_KEY' in (ROOT/'game.js').read_text() and 'BACKUP_KEY' in (ROOT/'game.js').read_text(), '')
check('Export et import de sauvegarde présents', 'function exportSave' in (ROOT/'game.js').read_text() and 'async function importSave' in (ROOT/'game.js').read_text(), '')

print('# QA5 — Pré-vol statique')
for name,ok,detail in checks: print(('PASS' if ok else 'FAIL')+' | '+name+((' — '+detail) if detail else ''))
print(f'\nRésultat : {sum(ok for _,ok,_ in checks)}/{len(checks)} contrôles réussis')
sys.exit(0 if all(ok for _,ok,_ in checks) else 1)
