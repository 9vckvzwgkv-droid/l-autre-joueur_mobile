'use strict';
const fs = require('node:fs');
const path = require('node:path');
const C = require('../content.js');
const root = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const exists = f => fs.existsSync(path.join(root, f));
const problems = [];
const html = read('index.html');
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const idCounts = ids.reduce((a, id) => (a[id] = (a[id] || 0) + 1, a), {});
const duplicateIds = Object.entries(idCounts).filter(([, n]) => n > 1).map(([id]) => id);
if (duplicateIds.length) problems.push({type:'duplicate-html-id', ids:duplicateIds});
const idRefs = new Set([...read('game.js').matchAll(/\$\(["']([\w-]+)["']\)/g)].map(m => m[1]));
const missingIds = [...idRefs].filter(id => !idCounts[id]);
if (missingIds.length) problems.push({type:'missing-dom-id', ids:missingIds});

const htmlAssets = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)].map(m => m[1]).filter(v => !/^(https?:|data:|#|mailto:|tel:)/i.test(v));
const cssFiles = htmlAssets.filter(v => v.endsWith('.css'));
const directAssets = htmlAssets.filter(v => !v.endsWith('.css') && !v.endsWith('.webmanifest'));
const cssAssets = [];
for (const f of cssFiles) {
  if (!exists(f)) problems.push({type:'missing-css', file:f});
  if (!exists(f)) continue;
  const src = read(f);
  for (const m of src.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)) {
    const v = m[1].trim();
    if (/^(data:|https?:|#)/i.test(v)) continue;
    const target = path.normalize(path.join(path.dirname(f), v));
    cssAssets.push(target);
    if (!exists(target)) problems.push({type:'missing-css-asset', from:f, asset:v, resolved:target});
  }
}
for (const f of directAssets) if (!exists(f)) problems.push({type:'missing-html-asset', file:f});

const sw = read('sw.js');
const filesMatch = sw.match(/const FILES=\[(.*?)\];/s);
if (!filesMatch) problems.push({type:'service-worker-files-array-missing'});
const swFiles = filesMatch ? Function('return [' + filesMatch[1] + ']')() : [];
for (const item of swFiles) {
  const rel = item === './' ? 'index.html' : item.replace(/^\.\//, '');
  if (!exists(rel)) problems.push({type:'missing-service-worker-asset', file:item});
}
if (!swFiles.includes('./ui-hud-pixel.css')) problems.push({type:'hud-css-not-precached'});
const manifest = JSON.parse(read('manifest.webmanifest'));
for (const icon of manifest.icons || []) if (!exists(icon.src)) problems.push({type:'missing-pwa-icon',file:icon.src});

const chapters=[];
const mapHashes=new Set();
for (let n=1;n<=50;n++) {
  const world=C.generate(n);
  mapHashes.add(require('node:crypto').createHash('sha256').update(Buffer.from(world.tiles)).digest('hex'));
  const flood=C.bfs(world.tiles, world.w, world.h, world.start);
  const passable=[];
  for(let y=1;y<world.h-1;y++) for(let x=1;x<world.w-1;x++) if(!world.tiles[y*world.w+x]) passable.push([x,y]);
  const unreachable=passable.filter(([x,y])=>flood.seen[y*world.w+x] < 0);
  const checkPoint=(p)=>Array.isArray(p)&&Number.isInteger(p[0])&&Number.isInteger(p[1])&&p[0]>0&&p[1]>0&&p[0]<world.w-1&&p[1]<world.h-1&&!world.tiles[p[1]*world.w+p[0]]&&flood.seen[p[1]*world.w+p[0]]>=0;
  const placements=[['start',world.start],['exit',world.exit],...world.runes.map((p,i)=>['rune'+(i+1),p]),['secret',world.secret],...world.traps.map((p,i)=>['trap'+(i+1),p]),...world.enemies.map((e,i)=>['enemy'+(i+1),[Math.floor(e.x),Math.floor(e.y)]])];
  const bad=placements.filter(([,p])=>!checkPoint(p)).map(([name])=>name);
  if (unreachable.length || bad.length) problems.push({type:'map-connectivity-or-placement',chapter:n,unreachable:unreachable.length,bad});
  if(!Array.isArray(world.runes)||world.runes.length!==3) problems.push({type:'rune-count',chapter:n,count:world.runes?.length});
  if(!world.exit||!world.secret||!Array.isArray(world.traps)||!Array.isArray(world.enemies)) problems.push({type:'missing-world-data',chapter:n});
  chapters.push({chapter:n,name:world.name,kind:world.kind,width:world.w,height:world.h,walkable:passable.length,traps:world.traps.length,enemies:world.enemies.length,puzzleMode:world.mode,theme:world.theme,unreachable:unreachable.length,invalidPlacements:bad});
}
const names = new Set(chapters.map(c=>c.name));
if(names.size!==50) problems.push({type:'chapter-name-duplicates',unique:names.size,total:50});
const labyrinths=chapters.filter(c=>c.chapter<=36 && c.kind==='labyrinthe').length;
const domains=chapters.filter(c=>c.chapter>=37 && c.kind==='domaine').length;
if(labyrinths!==36||domains!==14) problems.push({type:'chapter-type-count',labyrinths,domains});
const trapCounts=[...new Set(chapters.map(c=>c.traps))].sort((a,b)=>a-b);
const puzzleModes=[...new Set(chapters.map(c=>c.puzzleMode))];

const game=read('game.js');
const content=read('content.js');
const defaultsMatch=game.match(/const DEFAULT_CONTROLS=(\{[^;]+\});/);
const legacyMatch=game.match(/const LEGACY_DEFAULT_CONTROLS=(\{[^;]+\});/);
const controlDefaults=defaultsMatch?Function('return '+defaultsMatch[1])():{};
const controlDefaultsValid=Object.values(controlDefaults).length===4&&Object.values(controlDefaults).every(p=>p.x>=8&&p.x<=92&&p.y>=14&&p.y<=86);
if(!controlDefaultsValid) problems.push({type:'touch-control-defaults-out-of-bounds'});
if(!/isLegacyDefault/.test(game)) problems.push({type:'legacy-control-default-migration-missing'});
const status={
  archiveFiles: (()=>{let n=0;const walk=d=>{for(const x of fs.readdirSync(path.join(root,d),{withFileTypes:true})){if(x.isFile())n++;else if(x.isDirectory())walk(path.join(d,x.name));}};walk('.');return n;})(),
  htmlIds:ids.length,jsDomIdReferences:idRefs.size,cssFiles:cssFiles.length,cssAssetReferences:cssAssets.length,serviceWorkerPrecacheEntries:swFiles.length,
  chapters:chapters.length,labyrinths,domains,distinctMapLayouts:mapHashes.size,controlDefaultsValid,legacyControlsMigrated:/isLegacyDefault/.test(game),allMapsConnected:chapters.every(c=>c.unreachable===0&&c.invalidPlacements.length===0),trapCounts,puzzleModes,
  domainsTrapCounts:[...new Set(chapters.filter(c=>c.chapter>=37).map(c=>c.traps))],
  domainsSizes:{minWidth:Math.min(...chapters.filter(c=>c.chapter>=37).map(c=>c.width)),maxWidth:Math.max(...chapters.filter(c=>c.chapter>=37).map(c=>c.width)),minHeight:Math.min(...chapters.filter(c=>c.chapter>=37).map(c=>c.height)),maxHeight:Math.max(...chapters.filter(c=>c.chapter>=37).map(c=>c.height))},
  cacheVersion:(sw.match(/const CACHE='([^']+)'/)||[])[1]||null,
  companion: {hasPathFollowing:/otherPath=C\.path\(world,\[other\.x,other\.y\],\[player\.x,player\.y\]\)/.test(game),hasTrustThresholds:/save\.trust<35/.test(game)&&/save\.trust>65/.test(game),hasDangerWarning:/otherWarnTimer/.test(game),hasExplicitMemoryModel:/memoryBuffer|actionHistory|observedActions|playerBehaviorModel|decisionMemory/i.test(game)},
  trapMechanics: {genericCapture:/if\(!trapActive\[i\]&&distTo\(player,p\)<\.38\)\{trapActive\[i\]=true;capture\(/.test(game),captureReturnsToSafePoint:/player\.x=sx;player\.y=sy;/.test(game),resetChapterOnTrap:false},
  chapterGeneration:{seeded:/rand\(n\*90467\+1711\)/.test(content),commonRuneExitObjective:/runes=\[pick\(10\),pick\(10\),pick\(10\)\]/.test(content),trapCountRule:(content.match(/traps=Array\.from\(\{length:huge\?16:/)||[])[0]||null}
};
const report={generatedAt:new Date().toISOString(),status,problems,chapters};
fs.writeFileSync(path.join(root,'tests/QA31_AUDIT.json'),JSON.stringify(report,null,2)+'\n');
if(problems.length){console.error(JSON.stringify({status,problems},null,2));process.exitCode=1;} else console.log(JSON.stringify({status,problems:[]},null,2));
