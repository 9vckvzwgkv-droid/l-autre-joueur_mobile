"""Produce the original pixel panels and transparent game sprite atlas."""
from math import sin
from pathlib import Path
from random import Random

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / 'dist' / 'art'
OUT.mkdir(parents=True, exist_ok=True)
W, H = 400, 248
rng = Random(9612)
art = Image.new('RGB', (W, H))
d = ImageDraw.Draw(art)


def box(x, y, w, h, color):
    d.rectangle((x, y, x + w - 1, y + h - 1), fill=color)


def poly(points, color):
    d.polygon(points, fill=color)


def line(points, color, width=1):
    d.line(points, fill=color, width=width)


def blend(a, b, t):
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


# A vaulted crypt with an opening in the vegetation. Deliberately banded light.
for y in range(H):
    for x in range(W):
        r = ((x - 199) / 193) ** 2 + ((y - 122) / 155) ** 2
        t = max(0, 1 - r)
        t = int(t * 21) / 21
        art.putpixel((x, y), blend((7, 13, 21), (73, 111, 101), t))

for j, (x, y, w, h) in enumerate([(19, 46, 27, 164), (49, 70, 24, 141),
    (96, 64, 18, 137), (124, 87, 12, 108), (274, 65, 13, 127),
    (293, 51, 25, 149), (330, 38, 27, 167), (364, 0, 15, 218)]):
    color = ['#172c32', '#1d3539', '#254544'][j % 3]
    poly([(x, y), (x + w - 7, y + 3), (x + w, y + 28),
          (x + w - 4, y + h), (x - 4, y + h)], color)
    box(x + w - 7, y + 24, 3, h - 26, '#304e4a')
    for yy in range(y + 31, y + h - 4, 14):
        start = x + rng.randrange(0, 6)
        line([(start, yy + 2), (start + w // 2, yy + 2), (x + w - 5, yy)],
             '#162c32')
        box(start + 2, yy + 3, max(1, w // 3), 1, '#3a5550')

for i in range(23):
    x = rng.randrange(37, 365)
    y = rng.randrange(154, 212)
    poly([(x - 9, y + 29), (x - 8, y + 10), (x, y + 2), (x + 1, y - 10),
          (x + 4, y + 4), (x + 10, y + 12), (x + 11, y + 26)],
         rng.choice(('#172e34', '#203d40', '#2d4947')))

# Broad runic gateway, framing deeper steps into the crypt.
outer = [(147, 191), (147, 125), (153, 109), (167, 93), (189, 82), (211, 79),
         (234, 86), (254, 99), (270, 120), (274, 191)]
middle = [(154, 191), (154, 128), (160, 112), (173, 98), (191, 90), (211, 87),
          (232, 94), (249, 105), (262, 124), (265, 191)]
inner = [(164, 193), (164, 132), (170, 120), (182, 108), (197, 103), (211, 101),
         (227, 106), (243, 117), (253, 132), (254, 193)]
poly(outer, '#14262b')
poly([(x, y + 4) for x, y in outer], '#273c3d')
poly(middle, '#45554d')
poly(inner, '#101b26')
line(outer, '#52615a', 2)
line([(x + 1, y - 3) for x, y in inner], '#89917a')
line(inner, '#5d7165', 2)
for a, b in [(2, 3), (3, 4), (5, 6), (6, 7)]:
    line([outer[a], middle[b]], '#1f3333', 2)
for x in (149, 154, 157, 260, 264, 270):
    for y in range(139 + (x % 3) * 4, 189, 14):
        box(x, y, 4, 2, '#253a3b')
        box(x, y + 2, 3, 1, '#677269')
for inset, color in [(0, '#172934'), (6, '#213d46'), (9, '#2e4c54'), (11, '#192c38')]:
    poly([(194 + inset, 180), (194 + inset, 141), (200 + inset, 131), (209, 126 + inset),
          (218 - inset, 130), (226 - inset, 141), (226 - inset, 180)], color)
line([(208, 141), (208, 147), (205, 150), (208, 154), (208, 161)], '#9de1d5')
line([(209, 143), (212, 149), (210, 153)], '#4e9090')
box(208, 148, 2, 3, '#e5f0bd')
for i in range(7):
    y = 169 + i * 4
    w = 15 + i * 6
    poly([(209 - w, y + 2), (209 - w + 4, y), (209 + w - 4, y),
          (209 + w, y + 2), (209 + w, y + 3), (209 - w, y + 3)], '#263841')
    box(209 - w + 3, y, w * 2 - 6, 1, '#4b6666')

# Distant fog and suspended dust are individual pixels.
for i in range(510):
    x, y = rng.randrange(W), rng.randrange(57, 218)
    if 169 < x < 249 and 117 < y < 171 and i % 5:
        continue
    if rng.random() < .37:
        col = rng.choice(('#779786', '#416960', '#a7b492', '#4d726b'))
        box(x, y, 1 if i % 15 else 2, 1, col)

surface = [(0, 207), (40, 211), (79, 213), (115, 211), (143, 207),
           (168, 204), (197, 204), (228, 202), (254, 203), (281, 207),
           (322, 207), (356, 211), (400, 202)]
poly([*surface, (399, 247), (0, 247)], '#141f27')
line(surface, '#3c514c', 2)
for i in range(170):
    x = rng.randrange(3, 397)
    y = rng.randrange(210, 247)
    w = rng.randrange(2, 13)
    box(x, y, w, rng.randrange(1, 3), rng.choice(('#293d3d', '#203034', '#365049', '#0d181f')))

# Leaf shapes with three values and irregular hanging vines.
def fern(x, y, height, palette, wind=0):
    for k in range(height):
        yy = y - k
        xx = x + round((k / height) ** 2 * wind)
        box(xx, yy, 1, 1, palette[1])
        if k > 1 and k % 3 == 1:
            reach = max(1, int((1 - k / height) * height * .35))
            for side in (-1, 1):
                tip = xx + side * (reach + rng.randrange(0, 3))
                poly([(xx, yy + 1), (tip, yy - 3), (tip, yy - 4), (xx + side, yy - 1)], palette[0])
                line([(xx + side, yy), (tip - side, yy - 3)], palette[2])


for i in range(65):
    x = rng.randrange(W)
    y = rng.randrange(197, 219)
    if 126 < x < 259 and i % 4:
        continue
    pal = rng.choice((('#162f34', '#263f42', '#376255'), ('#1f413d', '#3e6352', '#688569'),
                      ('#273a39', '#536c56', '#868b66')))
    fern(x, y, rng.randrange(9, 43), pal, rng.randrange(-8, 9))

poly([(0, 0), (400, 0), (400, 62), (376, 50), (351, 38), (328, 31), (305, 34),
      (286, 22), (257, 19), (223, 16), (190, 18), (160, 25), (129, 33), (102, 37),
      (74, 49), (48, 60), (21, 70), (0, 81)], '#091119')
for i in range(175):
    x = rng.randrange(0, W)
    y = int(18 + 52 * ((x - 208) / 208) ** 2) + rng.randrange(-9, 10)
    size = rng.randrange(3, 11)
    col = rng.choice(('#192f31', '#213b38', '#2d524a', '#355749', '#111f28'))
    poly([(x - size, y - 2), (x, y - 3), (x + size, y + 3),
          (x + 2, y + 6), (x - 3, y + 4)], col)
for x, y, depth in [(27, 65, 52), (47, 51, 39), (63, 41, 60), (108, 34, 49),
                    (137, 30, 27), (315, 33, 42), (349, 42, 63), (377, 51, 52)]:
    for i in range(depth):
        xx = x + int(sin(i * .12) * 4)
        box(xx, y + i, 2, 1, '#233d3a')
        if i % 4 == 0:
            side = rng.choice((-1, 1))
            poly([(xx, y + i), (xx + side * 7, y + i + 1),
                  (xx + side * 4, y + i + 4), (xx, y + i + 2)], '#335847')
            box(xx + side * 3, y + i + 1, 2, 1, '#5b755a')

# Grid-aligned sprites: 24px square, four animation frames per actor.
sprites = Image.new('RGBA', (96, 120))

HERO = [
    '         oooo           ', '       ooHHHHoo         ', '      oHHHHhhHoo        ',
    '      oHHhffffho        ', '     oHHhfsffsho        ', '     oHHhffffffo        ',
    '      oHhfffffo         ', '      ohohhhhhoo        ', '     ooGGhhhGGgoo       ',
    '    ogGGGgGGggGgoo      ', '    ogGGggGGGgGggo      ', '   ooGGGggGGGgggooo     ',
    '   oggGGggGGggggoloo    ', '   ogGGGggccooggoLlo    ', '  ooGGGGgggggggoLoWo    ',
    '  ogGGGGggGGgggoLoWo    ', '  ogGGGGgggggggoLllo    ', ' ooGGggGGggggoooLlo     ',
    ' ooggggggooooo  oo      ', '  oooogggo ooo          ',
]
GOLEM = [
    '        oooooo          ', '      oonnnnmmoo        ', '    ooNNNnnnmmmmoo      ',
    '   oNNNNnnmmmNmmmo      ', '   oNNnnnnooommmmo      ', '   ommNNnoWWommmmo      ',
    '  ooomNNnoLLommmmooo    ', ' oNnnommmnmmnnmoonnmo   ', ' oNNNooomnmmooNNnnmo   ',
    ' onnNNnNnNnNnNNNnnmo    ', ' omnnnnmNNmnNnnmmmo     ', '  ommmnmnmnmnmmmoo      ',
    '  oommnnmmmnmmomo       ', '  oooommmmmmmmooo       ', '    ommmmoommmo         ',
    '    ommmmoommmo         ', '    ooooo  oooo         ',
]
DRONE = [
    '           l            ', '       ooonoo           ', '     oomNNNNmmoo        ',
    '   oomNNNnnnnmmoo       ', '  onNNnoooooonnnnoo     ', ' oNNnnooLWWLoonnmmmo    ',
    ' omnmmmoLWWLommmmnmo    ', '  oommmoolloommmooo     ', '     ooooooooooo        ',
    '      l       l         ',
]
common = dict(o='#111820', H='#547071', h='#2d484d', f='#d1ae84', s='#433c3f',
              G='#3e675d', g='#23444a', c='#9a8267', l='#b46c4e', L='#f1ae64', W='#fff0b0')
other = dict(common, H='#896b87', h='#423b58', f='#d4bfcc', s='#493447',
             G='#665671', g='#383449', c='#8c7188', l='#ac5a79', L='#f497a4', W='#ffd7ca')
stone = dict(o='#101c25', m='#41454c', n='#69716c', N='#9d9c82', l='#a45356',
             L='#e79473', W='#ffe0a3')
metal = dict(o='#101923', m='#393849', n='#585672', N='#9186a1', l='#8d698c',
             L='#a3c7ca', W='#d9fae4')


def sprite(rows, palette, col, row, offset=0, flip=False, boots=False):
    draw = ImageDraw.Draw(sprites)
    x0, y0 = col * 24, row * 24
    for y, letters in enumerate(rows):
        for x, ch in enumerate(letters):
            if ch != ' ':
                draw.point((x0 + (23 - x if flip else x), y0 + y + offset), fill=palette[ch])
    if boots:
        for x, y in [(7, 20 + (col % 2)), (13, 20 + ((col + 1) % 2))]:
            if flip:
                x = 21 - x
            draw.rectangle((x0 + x, y0 + y + offset, x0 + x + 2, y0 + y + offset + 1),
                           fill=palette['o'])


for i in range(4):
    sprite(HERO, common, i, 0, 1 - int(i == 1), boots=True)
    sprite(HERO, other, i, 1, 1 - int(i == 1), boots=True)
    sprite(DRONE, metal, i, 2, 6 + (i % 3))
    sprite(GOLEM, stone, i, 3, 2 + i % 2, flip=i >= 2)
    sprite(DRONE, dict(metal, L='#ed7d96', W='#ffd0b8'), i, 4, 6 + i % 3)
sprites.save(OUT / 'sprites-pixel.png')

# The two warm lights on the cover belong to the same sprites as in the game.
for x, y, frame, row, aura in [(151, 207, 1, 0, (237, 154, 76)),
                              (251, 201, 0, 1, (225, 113, 150))]:
    for dy in range(-22, 23):
        for dx in range(-28, 29):
            f = max(0, 1 - (dx / 28) ** 2 - (dy / 22) ** 2)
            xx, yy = x + dx + 5, y + dy - 6
            if f > 0 and 0 <= xx < W and 0 <= yy < H:
                p = art.getpixel((xx, yy))
                art.putpixel((xx, yy), blend(p, aura, int(f * 8) * .028))
    frame_img = sprites.crop((frame * 24, row * 24, (frame + 1) * 24, (row + 1) * 24))
    art.paste(frame_img, (x - 12, y - 21), frame_img)
for x, y, c in [(159, 201, '#d3b17d'), (166, 200, '#977d67'), (173, 199, '#746b55'),
                (245, 195, '#b3848e'), (237, 195, '#925e77')]:
    box(x, y, 2, 1, c)

poly([(0, 226), (17, 227), (24, 224), (50, 228), (78, 236), (104, 240),
      (138, 242), (178, 247), (256, 247), (284, 239), (321, 229), (359, 228),
      (384, 215), (400, 214), (400, 247), (0, 247)], '#090f18')
for i in range(39):
    x = rng.choice([rng.randrange(0, 60), rng.randrange(340, 400)])
    fern(x, rng.randrange(233, 250), rng.randrange(9, 31),
         ('#0e1d27', '#1c3336', '#294942'), rng.randrange(-10, 11))

art.save(OUT / 'seuil-pixel.png', optimize=True)
