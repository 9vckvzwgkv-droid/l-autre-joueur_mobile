'use strict';
const C = require('../content.js');
const failures = [];
let checks = 0;
function assert(ok, label) { checks++; if (!ok) failures.push(label); }
function walkable(world, p) {
  if (!Array.isArray(p) || p.length < 2) return false;
  const x = Math.floor(p[0]), y = Math.floor(p[1]);
  return x >= 0 && y >= 0 && x < world.w && y < world.h && world.tiles[y * world.w + x] === 0;
}
function reachable(world, from, to) {
  const sx = Math.floor(from[0]), sy = Math.floor(from[1]);
  const tx = Math.floor(to[0]), ty = Math.floor(to[1]);
  const seen = new Uint8Array(world.w * world.h);
  const queue = [sy * world.w + sx]; seen[queue[0]] = 1;
  for (let head = 0; head < queue.length; head++) {
    const i = queue[head], x = i % world.w, y = Math.floor(i / world.w);
    if (x === tx && y === ty) return true;
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx=x+dx, ny=y+dy;
      if(nx<0||ny<0||nx>=world.w||ny>=world.h) continue;
      const ni=ny*world.w+nx;
      if(!seen[ni] && world.tiles[ni]===0){seen[ni]=1;queue.push(ni);}
    }
  }
  return false;
}
const summary=[];
for(let n=1;n<=50;n++){
  const w=C.generate(n);
  assert(w && w.w*w.h===w.tiles.length,`Chapitre ${n}: dimensions/tuiles incohérentes`);
  assert(w.start && walkable(w,w.start),`Chapitre ${n}: départ non praticable`);
  assert(w.exit && walkable(w,w.exit),`Chapitre ${n}: sortie non praticable`);
  assert(Array.isArray(w.runes)&&w.runes.length===3,`Chapitre ${n}: trois runes absentes`);
  assert(w.runes.every(p=>walkable(w,p)),`Chapitre ${n}: rune dans un mur`);
  assert(w.secret&&walkable(w,w.secret),`Chapitre ${n}: secret non praticable`);
  assert(reachable(w,w.start,w.exit),`Chapitre ${n}: sortie inaccessible`);
  for(let i=0;i<w.runes.length;i++) assert(reachable(w,w.start,w.runes[i]),`Chapitre ${n}: rune ${i+1} inaccessible`);
  assert(reachable(w,w.start,w.secret),`Chapitre ${n}: secret inaccessible`);
  assert(Array.isArray(w.traps)&&w.traps.every(p=>walkable(w,p)),`Chapitre ${n}: piège dans un mur`);
  assert(Array.isArray(w.enemies)&&w.enemies.every(e=>walkable(w,[e.x,e.y])),`Chapitre ${n}: ennemi dans un mur`);
  const path=C.path(w,w.start,w.exit);
  assert(Array.isArray(path)&&path.length>0&&path.every(p=>walkable(w,p)),`Chapitre ${n}: chemin calculé invalide`);
  summary.push({chapter:n,width:w.w,height:w.h,tiles:w.tiles.length,pathToExit:path.length,runes:w.runes.length,traps:w.traps.length,enemies:w.enemies.length,largeDomain:n>36});
}
console.log(JSON.stringify({checks,passed:checks-failures.length,failed:failures.length,failures,chapters:summary},null,2));
process.exit(failures.length?1:0);
