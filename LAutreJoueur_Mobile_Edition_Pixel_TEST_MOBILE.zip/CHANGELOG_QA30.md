# QA30 — Micro-interactions et transitions discrètes

## Objectif
Donner aux menus une sensation plus réactive et moderne sans les surcharger ni s'éloigner du pixel art 2D.

## Modifications
- Ajout de `ui-motion.css`, chargé après les feuilles de finition.
- Retours visuels courts sur survol, pression et focus des boutons de menus, fenêtres et commandes HUD.
- Entrée des panneaux par un déplacement de quelques pixels, sans zoom, flou ni animation décorative permanente.
- Respect de `prefers-reduced-motion` : animations et transitions supprimées dans ce mode.
- Cache du service worker passé à `laj-mobile-pixel-r31`, feuille ajoutée au précache.

## Préservation
Aucun changement dans `game.js`, `content.js`, `visual-pixel.js`, les données de chapitres, la progression, les sauvegardes, les énigmes ou l'IA.

## Vérifications
Contrôles statiques à effectuer avant diffusion. Aucun test visuel sur appareil réel n'est revendiqué.
