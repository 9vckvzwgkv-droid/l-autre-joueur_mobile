# QA50 — Serments à deux marques

- Le chapitre 49 utilise une paire de marques distinctes pour chacun des trois sceaux.
- L’Autre rejoint la seconde marque à l’approche du sceau courant ; le joueur peut lui demander d’attendre avant d’activer le rituel.
- L’état de placement paraît sur les repères, dans le contexte de jeu, le journal et la carte.
- La règle refuse un compagnon non arrêté ou les deux personnages sur une même marque.
- La sauvegarde du chapitre passe à `mapVersion` 10 pour réinitialiser les anciennes données locales de cette énigme en préservant les sceaux et la progression globale.
- Le cache hors ligne passe à `laj-mobile-pixel-r59`.

## Vérifications

- Analyse syntaxique des scripts principaux.
- Parcours des données générées pour les 50 chapitres : sorties accessibles, aucun doublon de piège, identifiants de mécanique et topologies tous distincts dans cette génération.
- Simulation de la règle du chapitre 49 dans les trois cas : compagnon en mouvement, duo sur marques distinctes et duo sur la même marque.
- Génération du chapitre 49 : chaque paire est espacée de deux cases praticables ; ses marques et sa sortie sont accessibles.
- Aucune validation sur iPhone ou Android réel n’a été effectuée.
