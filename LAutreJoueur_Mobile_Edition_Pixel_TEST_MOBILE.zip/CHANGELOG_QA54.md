# QA54 — Les cotes de la Bibliothèque Infinie

- Le chapitre 40 place trois volumes aux cotes incomplètes dans des salles d’archives séparées. Le joueur doit les lire selon l’ordre des travées A, B puis C.
- Après les volumes, la page aux signatures cachée devient lisible et requise avant l’activation des sceaux. La page révèle le fragment « ELIA ».
- Le contexte proche, le journal, la carte et les marqueurs pixel art exposent les cotes et l’avancement de l’énigme.
- Le chapitre passe à `mapVersion` 10. Une ancienne partie reprend au seuil avec ses sceaux et souvenirs ; la découverte locale, le brouillard et les livres sont réinitialisés pour la nouvelle carte.
- Le cache hors ligne passe à `laj-mobile-pixel-r63`.

## Vérifications

- Analyse syntaxique de `content.js`, `game.js` et `visual-pixel.js`.
- Génération des 50 chapitres : 50 topologies et 50 identifiants d’énigme distincts, sorties accessibles et aucune position de piège dupliquée.
- Chapitre 40 : carte de 75 × 75 cases, 32 salles et trois livres sur des cases praticables, accessibles et séparées ; ordre vérifié A-0? → B-1? → C-2?. La page aux signatures est distincte et exigée par la condition des sceaux.
- Les parcours complets, la vérification de la difficulté et les essais sur téléphones réels restent à faire.
