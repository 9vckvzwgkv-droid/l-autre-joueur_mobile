# QA28 — harmonisation moderne pixel art

## Direction retenue
Menus modernes de jeu 2D pixel art : panneaux mats, contours nets, accents pierre/mousse/or discrets, animations courtes en pas de pixel. L'ornementation est volontairement réduite pour préserver la lisibilité et laisser respirer les contenus.

## Modifications
- Ajout de `ui-unity.css`, dernière couche de finition cohérente pour les panneaux, boutons, chapitres, réglages, atelier tactile, carte et carnet.
- Réduction des doubles cadres, sceaux trop présents, halos et ombres décoratives.
- Uniformisation des états primaire, secondaire, danger, survol, appui et focus.
- Transition d'apparition courte en steps, sans zoom ni flou; respect de `prefers-reduced-motion`.
- Cache hors ligne mis à jour en `laj-mobile-pixel-r29`.

## Périmètre préservé
Aucun fichier de gameplay, de contenu, de sauvegarde, d'audio ou de logique de commandes modifié. Seuls `index.html`, `sw.js`, `ui-unity.css` sont modifiés/ajoutés.

## Contrôles
Validation syntaxique CSS/JS, présence de la feuille dans l'HTML et le cache, intégrité ZIP. Pas de test réel Safari/Android/ordinateur revendiqué.
