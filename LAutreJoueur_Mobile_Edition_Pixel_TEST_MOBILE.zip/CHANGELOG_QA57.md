# QA57 — Les Marais des Reflets

- Le chapitre 43 place trois bassins réels et trois reflets trompeurs autour des salles des runes. Chaque reflet inverse le sens du courant réel.
- Lire les rides d’un bassin réel révèle le côté depuis lequel la rune doit être approchée. Les trois vrais courants doivent être examinés ; les sceaux exigent ensuite l’approche correcte.
- Le joueur peut aussi examiner les reflets, qui signalent leur inversion sans valider la piste.
- Les marqueurs d’eau pixel art apparaissent dans le monde, sur la carte et dans le journal. Les lectures sont sauvegardées.
- Le chapitre passe à `mapVersion` 10. Une ancienne partie reprend au seuil avec ses sceaux acquis ; l’exploration locale et les lectures de bassins recommencent sur la nouvelle carte.
- Le cache hors ligne passe à `laj-mobile-pixel-r66`.

## Vérifications

- Analyse syntaxique de `content.js`, `game.js` et `visual-pixel.js`.
- Génération des 50 chapitres : 50 topologies et identifiants d’énigme distincts, sorties accessibles et aucune position de piège dupliquée.
- Chapitre 43 : carte de 99 × 75 cases et 30 salles. Six bassins distincts et praticables se trouvent dans les trois salles des runes ; leurs passages sont accessibles ; chaque paire indique des directions opposées.
- Les 29 ressources déclarées dans le cache hors ligne sont présentes.
- Le parcours complet des chapitres, l’équilibre et les essais tactiles restent à faire.
