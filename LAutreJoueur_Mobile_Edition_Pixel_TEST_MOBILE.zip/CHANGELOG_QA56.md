# QA56 — Les lanternes des Jardins Suspendus

- Le chapitre 42 répartit trois lanternes-guide sur les terrasses. Chacune tourne vers une direction gravée différente, en quatre positions cardinales.
- Une lanterne accordée fait apparaître une racine lumineuse sur le chemin praticable vers le halo qu’elle guide.
- Les trois sceaux gardent la condition déjà prévue : être activés près de leur halo correspondant.
- Les repères, les directions cibles, la carte et le journal montrent l’état des trois lanternes ; les orientations sont sauvegardées.
- Le chapitre passe à `mapVersion` 10. Une ancienne partie reprend au seuil avec ses sceaux déjà acquis ; son exploration et l’état des lanternes redémarrent sur la nouvelle carte.
- Le cache hors ligne passe à `laj-mobile-pixel-r65`.

## Vérifications

- Analyse syntaxique de `content.js`, `game.js` et `visual-pixel.js`.
- Génération des 50 chapitres : 50 topologies et identifiants d’énigme distincts, sorties accessibles et aucune position de piège dupliquée.
- Chapitre 42 : carte de 91 × 67 cases, 30 salles ; trois commandes de lanterne en salles séparées, cibles ouest/est/sud, trois halos et chemins accessibles entre chaque commande et son halo.
- Les 29 ressources déclarées dans le cache hors ligne sont présentes.
- Les parcours complets, l’équilibre et les essais sur téléphones restent à faire.
