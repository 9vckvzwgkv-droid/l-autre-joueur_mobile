# QA61 — diversité des épreuves et confort mobile

- Ajout d’une illustration de lancement dans l’univers du jeu : basalte sombre, bordures d’or, végétation et lumière ambrée. Une animation courte peut être passée par toucher ou bouton ; le réglage de réduction des animations est respecté.
- Remplacement de l’icône générique par une icône dédiée illustrée, en formats iOS et Android.
- Correction des panneaux de réglages : les cartes conservent leur hauteur et le contenu défile à l’intérieur du panneau, y compris sur petit écran.
- Adoucissement du passage de la vue de dessus vers une perspective 2.5D légère dans les salles marquées. La commande de déplacement est compensée pour rester alignée avec l’image ; l’option de réduction des mouvements garde la vue de dessus.
- Réduction de la répétition des épreuves à trois sceaux : 41 chapitres ont maintenant une condition de sortie liée à leur mécanique dédiée. Neuf conservent leurs énigmes à sceaux.
- Mise à jour du cache hors ligne vers `laj-mobile-pixel-r70`.

Cette passe ne comprend pas de parcours intégral des 50 chapitres ni d’essai sur téléphone. Les interactions et les objectifs doivent encore être validés sur iPhone et Android avant de considérer la campagne prête à commercialiser.
