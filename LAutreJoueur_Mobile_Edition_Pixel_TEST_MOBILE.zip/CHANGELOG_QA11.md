# QA11 — Signatures visuelles des environnements

## Modifications
- Ajout de motifs de sol pixel-art déterministes, discrets et propres aux familles de thèmes.
- Les 14 grands domaines (chapitres 37 à 50) disposent chacun d'une signature de décor regroupée selon leur identité : sentinelles/cité, forêt/jardins, brumes/marais, archives/nécropole/cathédrale, désert/royaume des golems, cristaux/faille/dernier seuil.
- Les chapitres labyrinthes réutilisent une rotation contrôlée de ces familles pour diversifier les textures sans surcharger l'image.
- Cache PWA incrémenté de r11 à r12.

## Préservation
Aucune modification des cartes, chemins, murs solides, collisions, déplacements, ennemis, IA, énigmes, pièges, progression, sauvegardes, commandes, audio ou format paysage. Effets purement visuels, calculés de manière déterministe.

## Limites
Les contrôles automatisés ne remplacent pas une inspection visuelle en jeu. Aucun test physique iPhone/Android n'a été effectué pour cette version.
