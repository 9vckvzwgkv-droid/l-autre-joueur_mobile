# QA46 — Ordre de profondeur des personnages

- Les ennemis, L’Autre et le joueur sont maintenant dessinés selon leur profondeur projetée dans la scène, au lieu de toujours placer le joueur devant les autres personnages.
- Les cônes de veille restent sous les personnages ; leur dessin ne change pas la détection, les déplacements, les collisions ni les règles des pièges.
- Cette superposition rend plus lisibles les croisements dans les salles en perspective et les passages 2.5D.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r55`.

## Vérification

- Analyse syntaxique réussie pour les scripts et le script intégré.
- Ordre de dessin contrôlé dans une scène oblique avec deux voyageurs, un drone et une patrouille.
- Les 50 cartes gardent un trajet accessible entre le départ et la sortie.
- L’apparence réelle doit encore être examinée sur téléphone.
