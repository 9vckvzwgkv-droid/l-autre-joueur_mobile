# QA8 — Identité visuelle des drones de patrouille

## Modifications
- Ajout d'une ligne dédiée de 4 images pixel-art pour les drones de patrouille.
- Animation de survol/scanner en 4 temps, avec variations très limitées pour rester lisible sur petit écran.
- Le moteur attribue désormais cette ligne aux ennemis `patrol`; les sentinelles, golems et gardiens conservent leurs lignes existantes.
- Cache PWA incrémenté de r9 à r10.

## Préservation
Aucun changement de carte, collision, déplacement, IA, détection, dégâts, énigme, progression, sauvegarde ou audio. Les versions PC et QA6/QA7 restent intactes.
