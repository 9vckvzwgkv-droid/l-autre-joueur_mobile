# QA29 — Finition pixel-art légère

## Objectif
Poursuivre la direction moderne 2D pixel art sans charger les menus de cadres, sceaux, ornements ou effets supplémentaires.

## Modifications
- Ajout de `ui-pixel-finish.css`, chargé après les feuilles d'interface existantes.
- Harmonisation légère des contours, surfaces mates, rayons et états actifs.
- États clavier clairement visibles et hauteur tactile minimale de 44 px pour les boutons ciblés.
- Accent ambre réservé aux actions principales et à la sélection ; suppression des pseudo-éléments décoratifs redondants sur les grands panneaux.
- Respect renforcé de `prefers-reduced-motion`.
- Cache du service worker passé à `laj-mobile-pixel-r30` et nouvelle feuille ajoutée au précache.

## Préservation
Aucun changement dans `game.js`, `content.js`, `visual-pixel.js`, les données de chapitres, la progression, les sauvegardes, les énigmes ou l'IA.

## Vérifications
À compléter avant diffusion : syntaxe JS/CSS, références locales et intégrité ZIP. Aucun test sur appareil réel n'est revendiqué.
