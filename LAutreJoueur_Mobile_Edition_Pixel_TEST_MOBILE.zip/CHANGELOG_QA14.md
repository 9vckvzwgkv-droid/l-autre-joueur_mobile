# QA14 — Refonte complète des menus et de l'interface

## Direction visuelle
- Recomposition du menu d'accueil en écran éditorial plus large, avec hiérarchie visuelle renforcée.
- Harmonisation des panneaux, boutons, cartes de chapitre, confirmations et transitions.
- Panneaux Carte et Carnet plus adaptés à leur contenu, avec carte détaillée et zoom.
- Refonte des réglages en sections dédiées, curseurs plus grands et lisibles.

## Réglages réellement fonctionnels
- Volume de musique appliqué au mixage des pistes en cours.
- Volume des bruitages appliqué au niveau des effets sonores.
- Boutons d'aperçu audio.
- Réglage de visibilité, animations réduites et contraste renforcé conservés.
- Option de mini-carte permanente pendant l'exploration.
- Taille et opacité des commandes tactiles.
- Éditeur tactile permettant de déplacer individuellement le joystick, Agir, L'Autre et Courir ; disposition enregistrée localement et réinitialisable.
- Niveau de détail/zoom de la carte et commandes de zoom dans le panneau Carte.

## Périmètre de préservation
- Aucun changement aux données des 50 chapitres, à la génération des labyrinthes, aux collisions, déplacements, ennemis, IA de L'Autre, énigmes, pièges, progression ou conditions de fin.
- Les réglages supplémentaires sont ajoutés de manière rétrocompatible aux sauvegardes existantes.
- Les commandes tactiles gardent leurs identifiants et leurs gestionnaires d'interaction.

## Validation
- Vérifications syntaxiques JavaScript et structure HTML effectuées après génération.
- Le rendu réel, les interactions tactiles et le mixage audio doivent encore être confirmés sur iPhone et ordinateur.
