# QA41 — Ambiances pixel par chapitre

- Les particules lumineuses après le brouillard prennent maintenant leurs couleurs dans la palette du chapitre ; les ambiances des 50 lieux sont donc moins regroupées en quelques familles.
- Ajout d’un léger mouvement de respiration au repos et d’une variation douce de la lumière des deux voyageurs.
- Ajout de motifs de décor pixel propres aux 14 topologies des grands domaines : tours, racines, îlots, rayonnages, cadrans, terrasses, marais, portes, cristaux, faille, forteresse, nécropole, nef et convergence.
- Les salles repères reprennent davantage la couleur d’accent du chapitre, avec conservation du traitement de la carte PC du premier seuil.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r49`.

## Vérification

- Analyse syntaxique réussie pour `content.js`, `game.js` et `visual-pixel.js`.
- Les dessins des salles, pièges et particules ont été exécutés sur les données des 50 chapitres sans erreur de rendu côté code.
- Les cartes, objectifs et identifiants de niveaux ne changent pas dans cette passe visuelle.

Les nouveaux motifs sont vérifiés dans le code ; l’équilibre visuel doit encore être confirmé par un parcours à l’écran sur téléphone et tablette.
