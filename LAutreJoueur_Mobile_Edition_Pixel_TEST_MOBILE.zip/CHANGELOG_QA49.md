# QA49 — Épreuve des ponts de la Faille du Silence

- Le chapitre 46 propose trois ponts praticables au-dessus de l’abîme.
- Le pont stable émet une vibration régulière ; les deux autres tremblent par à-coups.
- La proximité donne un retour visuel, sonore et, si le téléphone le permet et que les effets de mouvement sont activés, une courte vibration.
- Traverser un pont instable ramène au dernier point sûr sans retirer les sceaux.
- L’épreuve ne demande plus d’appeler L’Autre ; elle suit la fiche de conception validée.
- La carte 46 passe à `mapVersion` 10. À la reprise, la progression des sceaux reste conservée tandis que position, carte révélée et pièges locaux obsolètes sont réinitialisés.
- Cache hors ligne porté à `laj-mobile-pixel-r58`.

## Contrôles effectués

- Analyse syntaxique de `content.js`, `game.js`, `visual-pixel.js`, `companion-ai.js` et `sw.js`.
- Génération de la carte 46 : trois ponts sur des cases praticables, un pont sûr, deux ponts instables, aucun piège en double ni pont posé sur un objectif.
- Un chemin de 125 cases relie le seuil à la sortie générée dans cette graine.
- Simulation des deux issues : le pont stable ouvre l’épreuve sans dégâts ; un pont instable conserve le sceau et renvoie au point sûr.
- Le rendu et l’équilibrage sur téléphone réel restent à vérifier.
