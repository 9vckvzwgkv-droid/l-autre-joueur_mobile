# QA38 — Énigme de lanterne

- Les sceaux associés à la lumière n’ont plus de lanterne posée directement dessus. Chaque sceau reçoit une lanterne dédiée à proximité ; le joueur doit se placer dans le chevauchement entre sa portée d’interaction et la zone éclairée.
- L’indice tactile et le carnet gardent une instruction courte : approcher le sceau dans la lumière.
- La géométrie de génération passe en version 6 ; le cache hors ligne PWA passe à `laj-mobile-pixel-r41`.

## Contrôles ciblés
- Les trois scripts JavaScript passent l’analyse syntaxique.
- Les 15 chapitres qui utilisent la règle de lumière ont tous un emplacement de lanterne atteignable sans collision, à portée du sceau.
- L’audit de campagne confirme 50 plans physiques différents, 50 combinaisons d’ordre et de gestes, aucune carte déconnectée et aucun objectif, ennemi ou lanterne en mur.
- Le chapitre 1 conserve sa carte dédiée et ses points clés.

Ces contrôles ne remplacent pas le jeu complet des chapitres ni les essais sur téléphone. Les mécaniques spéciales décrites pour les 50 chapitres dans la proposition restent à implémenter et à rapprocher du scénario PC original.
