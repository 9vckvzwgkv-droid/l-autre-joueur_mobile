# QA26 — Carte et carnet de souvenirs

## Base
Construite directement depuis `LAutreJoueur_Mobile_Edition_Pixel_QA25_PAUSE_CONFIRMATIONS.zip`.

## Périmètre
Finition visuelle ciblée de `#panel-map` et `#panel-journal` dans `ui-relic.css`, et incrément du cache du service worker vers `laj-mobile-pixel-r27`.

### Carte
- Cadre de cartographie renforcé, bandeau de repères et toile de fond plus profonde.
- Barre de zoom mieux hiérarchisée ; cibles tactiles portées à 44 px.
- Zone canvas encadrée comme une tablette de pierre, sans changer son dessin ni ses dimensions internes.
- Légende mieux isolée et centrée.

### Carnet
- Identité de registre/archives distincte de la carte, tout en conservant la palette du sanctuaire.
- Description du chapitre traitée comme fragment de mémoire.
- Progression séparée visuellement des indices et du secret.
- Typographie et espacements ajustés en portrait et en paysage.

## Préservation
Aucun changement à `game.js`, `content.js`, `visual-pixel.js`, aux données de sauvegarde, au calcul de carte, au rendu des fragments ou à la progression. Aucun identifiant HTML ni écouteur d'événement modifié.

## Vérifications
- Syntaxe JavaScript : `node --check` sur les scripts du jeu et le service worker.
- Parsing CSS : aucun jeton d'erreur avec tinycss2.
- Références locales CSS : contrôlées.
- Archive : test ZIP réussi.
- Pas de test visuel certifié sur appareil réel ; vérifier Safari iOS, Android et ordinateur après déploiement.
