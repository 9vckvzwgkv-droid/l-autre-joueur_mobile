# QA42 — Cap arrière des voyageurs

- Le joueur et L’Autre gardent leurs quatre images de marche, mais leur silhouette change maintenant lorsqu’ils se dirigent vers le haut : le visage est couvert par l’arrière de leur capuche. Le golem masque aussi ses yeux lorsqu’il tourne le dos.
- Le cap reste lié à l’orientation réelle du personnage ; les commandes, les collisions, l’IA du compagnon et la progression ne changent pas.
- L’option de réduction des mouvements continue de supprimer le balancement au repos.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r51`.

## Vérification

- Analyse syntaxique réussie pour `content.js`, `game.js` et `visual-pixel.js`.
- Le rendu des deux personnages a été exécuté dans les quatre orientations principales, y compris l’orientation arrière.

La lisibilité du nouvel angle doit encore être vérifiée à taille réelle sur iPhone et Android.
