# QA23 — Peaufinage des menus

## Base de travail

Reprise de l'archive QA22 `LAutreJoueur_Mobile_Edition_Pixel_QA22_RECONSTRUCTION_MENUS.zip`. La direction artistique pierre sombre, mousse, végétation et or est conservée.

## Finitions apportées

- Renforcement de la lisibilité : taille des petits libellés, descriptions, aides et valeurs de réglage relevées.
- Navigation plus claire : barre de titre des panneaux maintenue visible pendant le défilement et bouton Retour plus facile à toucher.
- Confort tactile : cibles des boutons, curseurs, cases à cocher, contrôles de carte et actions de sauvegarde agrandies ou consolidées.
- Sélection des chapitres : différence visuelle plus nette entre chapitre en cours et chapitres scellés, sans modifier la logique de déverrouillage.
- Réglages : cartes et curseurs mieux espacés, textes d'aide plus contrastés.
- Carte, carnet, atelier de commandes et dialogues : détails de taille, de contraste et d'espacement harmonisés.
- Le réglage « Contraste renforcé » couvre désormais aussi les nouveaux composants de la QA22.
- Les états clavier, tactile, survol à la souris et réduction des animations sont renforcés.

## Fichiers modifiés

- `index.html` : ajout de `ui-polish.css` après la feuille QA22.
- `sw.js` : ajout de la nouvelle feuille au cache et passage à `laj-mobile-pixel-r24`.

## Nouveau fichier

- `ui-polish.css` : couche de finitions indépendante, limitée à l'interface.

## Préservation

Aucun changement dans `game.js`, `content.js`, `visual-pixel.js`, le contenu des chapitres, les énigmes, les pièges, les sauvegardes, l'IA, les contrôles de gameplay ou les fichiers audio.

## Vérifications effectuées

- Syntaxe JavaScript des fichiers du jeu et du service worker : inchangée depuis QA22, contrôlée.
- Analyse CSS de `ui-relic.css` et `ui-polish.css` : aucune erreur de parsing.
- Références locales des textures et feuilles de style : présentes.
- Archive ZIP : intégrité contrôlée.

La vérification visuelle dans un vrai Safari iPhone/iPad, Android et navigateur de bureau reste à effectuer. Une capture automatisée avec Chromium n'a pas pu être obtenue dans cet environnement, donc cette QA ne prétend pas certifier tous les rendus d'écran.
