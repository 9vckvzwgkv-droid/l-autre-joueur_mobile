# L’Autre Joueur Mobile — état après QA49

## Chapitre 46 · La Faille du Silence

- L’épreuve correspond maintenant à la conception validée : trois ponts traversent la faille, sans appel à L’Autre.
- Chaque pont donne un indice à proximité. Le pont stable émet une pulsation régulière ; les deux ponts instables donnent une secousse irrégulière et provoquent un retour au point sûr lorsqu’on les traverse.
- Le joueur conserve ses sceaux en cas d’erreur. L’indice associe affichage, son et vibration mobile facultative ; l’option d’accessibilité pour les mouvements est respectée.
- La carte 46 utilise la version 10. Une ancienne partie qui reprend ce chapitre garde ses sceaux et son état de campagne, mais recommence l’exploration locale au seuil.

## Vérifications de cette version

- `content.js`, `game.js`, `visual-pixel.js`, `companion-ai.js` et `sw.js` passent l’analyse syntaxique JavaScript.
- La génération du chapitre 46 donne trois ponts sur des cases praticables, un sûr, deux instables, sans collision de pièges ou chevauchement avec les objectifs.
- Un chemin de 125 cases rejoint la sortie pour la graine examinée.
- La simulation confirme que le pont stable valide l’épreuve sans compter de piège et que le pont instable conserve la progression, compte le piège et ramène au point sûr.
- Le manifeste autorise le portrait et le paysage (`orientation: any`). Le cache hors ligne est `laj-mobile-pixel-r58`.

## Reste à faire

- Comparer les règles réelles des chapitres 37 à 50 à chacune de leurs fiches : la présence d’un identifiant unique ne prouve pas que l’épreuve réalise toute sa conception.
- Parcourir les 50 chapitres, vérifier la difficulté et les situations de blocage, puis équilibrer les plus grands labyrinthes.
- Contrôler le rendu et les commandes tactiles sur des iPhone et Android réels, y compris les zones sûres, les performances, les rotations et la reprise de sauvegarde.
- Vérifier l’installation hors ligne sur un hébergement HTTPS, préparer les éléments de publication et décider de la voie de distribution native.

La proposition de conception demeure la référence des cinquante chapitres. La fiche PC originale et son projet source restent à comparer si leurs documents de conception détaillés sont fournis.
