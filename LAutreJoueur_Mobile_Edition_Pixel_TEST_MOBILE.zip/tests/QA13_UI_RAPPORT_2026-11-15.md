# QA13 — Rapport interface — 2026-11-15

- Modifications limitées à ui-modern.css, game.js (remise à zéro du scroll d’un panneau UI), sw.js (cache r14), changelog et rapport.
- Aucune modification des données de chapitres ni des systèmes de gameplay.
- Le contrôle de rendu physique sur iPhone reste à effectuer par l’utilisateur après publication.
