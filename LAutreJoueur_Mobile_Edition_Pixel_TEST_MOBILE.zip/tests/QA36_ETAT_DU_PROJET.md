# L’Autre Joueur Mobile — état après QA36

Le projet reste une édition mobile 2D pixel art de la campagne de 50 chapitres. Les cartes-salles, les pièges et ennemis, les sceaux, les choix, la progression, le HUD tactile et la présentation en projection 2.5D dans certaines salles restent conservés.

## Travail achevé dans cette étape
- La mémoire de L’Autre est enregistrée dans la sauvegarde locale et dans les exports/imports.
- Les anciennes sauvegardes reçoivent les compteurs manquants à zéro sans perdre la progression.
- L’Autre adapte doucement son suivi et ses avertissements au rythme, aux captures, aux appels et à l'exploration du joueur.
- Le carnet exprime cette adaptation en français.
- Le modèle de mémoire est préchargé et mis en cache pour le fonctionnement hors ligne ; cache PWA `laj-mobile-pixel-r38`.
- 15 contrôles ciblés passent, couvrant la migration des sauvegardes, l'adaptation du compagnon, le chargement hors ligne, les entrées tactiles et les scripts du paquet.

## À terminer avant une édition commerciale
- Faire les essais tactiles, visuels et de performance sur iPhone et Android réels, en portrait et paysage.
- Jouer et équilibrer toute la campagne, ses énigmes, ennemis, pièges et fins avec des joueurs.
- Finaliser les scènes 2.5D, les animations et l'accessibilité sur appareils mobiles.
- Vérifier installation et mise à jour PWA sur appareils réels, hébergement HTTPS, mentions, droits des ressources et exigences des boutiques visées.

Les contrôles réalisés ici sont ciblés et ne certifient pas une publication commerciale.
