# L’Autre Joueur Mobile — état après QA52

## Chapitre 39 · La Mer des Brumes

- Le plan relie de grandes salles regroupées en îlots par de véritables ponts.
- Trois ponts portent des flèches. Il faut les traverser dans l’ordre et dans le sens indiqué.
- Trois nappes internes aux îlots sont des reflets trompeurs. Elles ont une silhouette en rides distincte des ponts.
- Le contexte proche du joueur donne un repère de direction. La carte et le journal suivent les passages réussis.
- Un passage validé déplace le point sûr et l’avancement est sauvegardé. Une ancienne sauvegarde du chapitre reprend au seuil : les sceaux acquis restent, l’exploration et les traversées sont remises à zéro pour la nouvelle carte, et le point sûr est adapté.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 chapitres générés ont 50 topologies et identifiants de scénario distincts. Les 50 sorties sont reliées et les pièges ne se dupliquent pas dans cette génération.
- Le chapitre 39 génère une carte de 99 × 67 cases avec 32 salles, trois ponts et trois reflets. Les six repères sont accessibles, libres de pièges et espacés.
- La simulation refuse un reflet, un passage à rebours et un passage dans le désordre, puis valide les trois ponts dans l’ordre.
- Toutes les ressources du cache hors ligne sont présentes ; celui-ci utilise `laj-mobile-pixel-r61`.

## État des grands labyrinthes

- 37 : sentinelles et zones sûres — mécanique présente, à comparer à la synchronisation des faisceaux prévue.
- 38 : clairières reliées par les racines — progression ordonnée déjà présente.
- 39 : ponts de brume, courants et reflets — épreuve intégrée et simulée.
- 40 à 44 : volumes, horloges, lanternes, reflets de marais et portes de quartier — à rapprocher de leurs fiches et enrichir.
- 45 : prismes tournants et trois couleurs cibles — implémenté et simulé.
- 46 : trois ponts vibratoires, un sûr — implémenté et simulé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et simulé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 37, 40 à 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles.
