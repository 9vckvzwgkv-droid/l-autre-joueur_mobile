# L’Autre Joueur Mobile — état après QA53

## Chapitre 37 · Le Plateau des Sentinelles

- Trois sentinelles occupent des tours séparées, avec une vue dégagée vers la balise centrale.
- Leurs faisceaux balayent de longues portées. Ils convergent sur la balise deux fois par cycle de 16 secondes et prennent une teinte turquoise pendant la fenêtre commune.
- Chaque sceau ne répond que pendant cette fenêtre, si le joueur reste hors de tous les cônes. Le contexte indique si les faisceaux bougent, s’ils sont accordés ou si le joueur est hors de danger.
- La balise utilise un symbole pixel art ; la carte et le journal exposent l’état de veille.
- Une ancienne sauvegarde du chapitre reprend au seuil avec ses sceaux acquis. L’exploration locale est réinitialisée pour la nouvelle carte.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 chapitres générés ont 50 topologies et identifiants de scénario distincts. Les sorties sont reliées et les pièges ne se dupliquent pas dans cette génération.
- Le chapitre 37 génère une carte de 83 × 75 cases et 28 salles. Les trois tours ont une ligne de vue vers la balise ; les sceaux et la sortie sont reliés ; chaque sceau possède une case d’approche hors des faisceaux pendant l’alignement.
- La fenêtre s’ouvre au début du cycle et à 8 secondes, se ferme au milieu du balayage, et la règle refuse le joueur lorsqu’une sentinelle le voit.
- Le chapitre 39 conserve ses trois vrais ponts et ses trois reflets.
- Toutes les ressources du cache hors ligne sont présentes ; celui-ci utilise `laj-mobile-pixel-r62`.

## État des grands labyrinthes

- 37 : convergence de trois faisceaux et zones d’ombre — implémenté et simulé.
- 38 : clairières reliées par les racines — progression ordonnée présente.
- 39 : ponts de brume, courants et reflets — implémenté et simulé.
- 40 à 44 : volumes, horloges, lanternes, reflets de marais et portes de quartier — à rapprocher de leurs fiches et enrichir.
- 45 : prismes tournants et trois couleurs cibles — implémenté et simulé.
- 46 : trois ponts vibratoires, un sûr — implémenté et simulé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et simulé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 40 à 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles.
