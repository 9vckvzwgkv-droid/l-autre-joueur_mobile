# L’Autre Joueur — état après QA34

## Direction de production
- Produit principalement mobile, joué en paysage, avec commandes tactiles configurables et interface fixe au-dessus de la scène.
- Campagne de 50 chapitres maintenue. Le premier chapitre conserve le plan de référence du jeu PC ; les 49 suivants gardent les noms et thèmes de la campagne mobile.
- Les chapitres 2 à 50 ont des salles de plusieurs cases, des passages de trois cases et des connexions en boucle. Les zones ne reposent plus sur de longs couloirs d'une case.
- Des salles de profondeur inclinent et aplatissent progressivement la projection de la scène, avec un petit sanctuaire comme repère. Le HUD et les commandes ne sont pas transformés.
- Le mouvement tactile/clavier est compensé pour garder la même direction apparente dans les salles en perspective.
- Menus et HUD utilisent pierre sombre, végétation, or patiné et lumière ambrée.
- Les domaines 37 à 50 ont 20 dalles mortelles et 15 runes engourdissantes ; les labyrinthes gardent leur capture avec retour au dernier point sûr.

## Progression et rétrocompatibilité
Les sauvegardes plus anciennes conservent leurs chapitres terminés, choix, confiance, runes acquises et souvenirs. Pour une carte dont la géométrie a changé, la position, la carte locale et l'état des pièges sont réinitialisés au seuil afin d'assurer un départ praticable.

## Contrôles exécutés pour QA34
La génération déterministe des 50 mondes a été parcourue : aucun secteur praticable isolé ni objectif ou objet testé inaccessible n'a été trouvé. Les 14 domaines exposent la répartition attendue des pièges. La formule de déplacement compensé correspond à la projection pour huit directions de commande. Les fichiers JavaScript modifiés passent l'analyse syntaxique.

Ces contrôles ne remplacent pas l'essai de rythme et de lisibilité en jeu. La scène 2.5D doit être réglée et validée visuellement sur iPhone et Android.

## Travail restant vers une version commerciale
1. Remplacer le simple changement de cadrage par des séquences 2.5D mises en scène, avec accès/retour explicite et rythme adapté au tactile ; valider l'orientation des commandes en situation réelle.
2. Donner à chaque lieu ses énigmes, secrets, risques et comportements plutôt que la seule répartition différente des mêmes objectifs.
3. Construire la mémoire des habitudes de L'Autre et ses décisions relationnelles.
4. Revoir l'équilibrage des pièges, ennemis, grandes salles et retours après échec en jouant la campagne.
5. Effectuer l'assurance qualité visuelle, tactile, de performance, hors ligne et d'installation sur appareils réels, puis publier sur HTTPS.
