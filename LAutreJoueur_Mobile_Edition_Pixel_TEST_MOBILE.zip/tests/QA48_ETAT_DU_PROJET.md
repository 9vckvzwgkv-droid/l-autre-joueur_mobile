# L’Autre Joueur Mobile — état après QA48

## Téléphone en portrait ou paysage

- La partie se lance désormais dans les deux orientations. Elle ne s’arrête plus et ne cache plus l’interface lorsque le téléphone est vertical.
- Le canevas se redimensionne à la fenêtre ; les commandes par défaut adoptent un placement vertical en portrait et un placement large en paysage. Les ajustements manuels restent conservés.
- Une rotation arrête l’entrée de déplacement en cours, puis replace les commandes selon la nouvelle orientation sans ouvrir le menu Pause.
- Les menus, le HUD et les commandes tactiles ne sont plus masqués en portrait.
- Le manifeste PWA autorise l’orientation libre. L’écran demandant de tourner l’appareil a été retiré.
- Cache PWA : `laj-mobile-pixel-r57` (état QA48, remplacé depuis).

## Contrôle technique

- Le code conserve la partie active lors d’un passage simulé de 320 × 568 à 844 × 390 pixels ; les commandes restent visibles et se replacent.
- Le placement manuel du joystick a été conservé dans le contrôle du réglage.
- Le manifeste JSON et les scripts JavaScript passent l’analyse syntaxique.

## État du contenu

- Les corrections des chapitres 28, 46 et 47 restent intégrées.
- Les contrôles précédents confirment 50 cartes avec des signatures distinctes et des sorties accessibles.
- La fiche de conception PC complète reste à comparer si elle devient disponible.

## Travail restant

- Vérifier le rendu, le confort tactile, les zones sûres d’écran et les performances en portrait et paysage sur iPhone et Android réels.
- Parcourir et équilibrer les 50 chapitres en partie, avec une attention particulière aux domaines 37 à 50.
- Confirmer l’installation hors ligne sur appareil après publication HTTPS.
- Préparer la publication mobile et décider si une enveloppe native/App Store est nécessaire.
