# L’Autre Joueur Mobile — état après QA45

## Salles 2.5D

- Les salles marquées en profondeur affichent un escalier pixel art à cinq paliers, avec faces supérieures, contremarches et côtés ombrés.
- Les teintes suivent la palette du chapitre ; les repères ambrés renforcent le lien avec les fils d’or et runes du jeu.
- Le système est visuel. Le déplacement et la collision restent sur le même plan de marche pour préserver les parcours et les commandes mobiles.
- Cache PWA : `laj-mobile-pixel-r54`.

## État de campagne et vérifications

- Les 50 cartes restent accessibles ; les chapitres 2 à 36 conservent leurs topologies et conditions distinctes, et les 14 grands domaines gardent leurs identités propres.
- Analyse syntaxique réussie pour les quatre scripts JavaScript et le script intégré à la page.
- Rendu exécuté sur les 50 cartes : 182 salles en profondeur dessinées, sans erreur (10 890 appels de dessin pixel).
- Les 50 trajets du départ à la sortie restent accessibles.
- Les essais d’équilibrage complets et les validations sur iPhone et Android restent nécessaires.
- Publication HTTPS et installation PWA sur appareils réels restent à effectuer.
