# L’Autre Joueur — état du projet et audit QA31

Base auditée : **QA30 — Édition Pixel Mobile**. Ce rapport décrit les fichiers de cette archive, pas une éventuelle copie déjà publiée sur GitHub Pages.

## 1. Éléments présents dans cette archive

- Moteur navigateur 2D sur canvas, rendu pixel-art et effets de visibilité.
- 50 entrées de chapitre, chacune générée par `content.js` avec un nom, un thème, une description, un fragment de lore, une palette et un comportement décrit.
- Chapitres 1 à 36 classés comme labyrinthes ; chapitres 37 à 50 classés comme grands domaines.
- Trois sceaux par carte, une sortie, un secret facultatif, des pièges et des ennemis.
- Déplacement clavier et tactile, interaction, commande de L’Autre, course, pause, carte, carnet et sélection des chapitres.
- Confiance, choix de fin de chapitre, progression séquentielle, sauvegarde locale, export/import et copie de sauvegarde précédente.
- Audio, réglages d’affichage, contraste, animations réduites, mini-carte et éditeur de position des commandes.
- Manifeste PWA, icônes, service worker et ressources audio/graphismes prévues pour le cache.

## 2. Résultats des contrôles automatiques QA31

| Contrôle | Résultat |
|---|---:|
| Chapitres générés et inspectés | 50 / 50 |
| Labyrinthes | 36 |
| Grands domaines | 14 |
| Cartes avec cases praticables inaccessibles | 0 |
| Départs, sorties, sceaux, secrets, pièges ou ennemis placés sur une case invalide | 0 |
| Identifiants HTML dupliqués | 0 |
| Références DOM du jeu sans élément HTML correspondant | 0 |
| Références locales HTML/CSS/service worker manquantes | 0 |
| Icônes PWA absentes | 0 |
| Problèmes détectés par le script d’audit | 0 |

L’audit vérifie la structure, les ressources et la génération des cartes. Il ne prouve pas à lui seul que chaque énigme est amusante, équilibrée ou compréhensible pendant une partie réelle.

## 3. Fonctionnalités : présentes, mais avec des limites

### Cartes et chapitres

Les 50 cartes sont générées de manière déterministe à partir du numéro de chapitre. Les 36 premiers sont des labyrinthes d’environ 35–48 cases de large sur 35–47 de haut. Les 14 domaines sont plus grands, de 75 à 99 cases de large sur 67 à 83 de haut. Les tests QA31 confirment que toutes les cases praticables de ces cartes sont reliées au départ et que les objets testés sont accessibles.

**Limite :** il s’agit d’une génération procédurale basée sur une même famille d’algorithmes, pas de 50 cartes toutes dessinées et mises en scène individuellement. Les palettes et les noms différencient les lieux, mais le caractère réellement unique de chaque expérience doit encore être développé et testé.

### Énigmes et objectifs

Le jeu contient trois sceaux et une sortie dans chaque chapitre. Quatre modes d’ordre de sceaux sont employés : `glyph`, `memory`, `relay` et `mirror`, qui reviennent selon une séquence. Le mode relais permet une interaction particulière avec L’Autre et un secours manuel.

**Limite :** les quatre modes ne constituent pas 50 énigmes singulières avec des mécanismes et résolutions propres à chaque chapitre. L’objectif général reste largement le même : obtenir trois sceaux puis franchir la sortie.

### Pièges et conséquences

Le nombre généré est de 4 à 7 pièges dans les labyrinthes selon le numéro de chapitre, et de **16 pièges dans chacun des 14 domaines**. Dans le moteur actuel, toucher un piège déclenche la capture générique : le personnage revient au dernier point sûr et conserve les sceaux déjà obtenus.

**Écart au cahier des charges :** les domaines 37–50 n’ont pas encore les quelque 20 pièges mortels et 15 pièges ralentisseurs souhaités. Les deux catégories distinctes ne sont pas implémentées et la mort ne redémarre pas le chapitre entier depuis zéro.

### L’Autre et son IA

Le compagnon peut attendre ou revenir vers le joueur, calcule un chemin pour le rejoindre, et sa distance/vitesse de suivi varie selon le niveau de confiance. À partir d’un certain niveau de confiance, il peut aussi signaler un danger proche.

**Écart au cahier des charges :** l’implémentation ne contient pas encore de système explicite qui mémorise les habitudes du joueur, compare ses actions dans le temps et élabore une stratégie d’adaptation. Les comportements affichés dans les descriptions de chapitres ne correspondent pas tous à des comportements autonomes réellement programmés. Les comportements agressifs ou protecteurs conditionnés par la relation restent à construire.

### Caméra, profondeur et fins

La scène est rendue par un canvas 2D avec vue de dessus. La fin actuelle propose un choix de partir ensemble ou seul, avec des textes qui varient selon la confiance.

**Écart au cahier des charges :** les bascules de caméra entre vue du dessus et vue de face pour les descentes/montées ne sont pas présentes. Il n’y a pas encore de confrontation finale jouable spécifique à une relation négative au chapitre 50.

## 4. Corrections incluses dans QA31

- Le HUD est resserré et clarifie l’information du chapitre, les sceaux, la confiance et les raccourcis.
- La mini-carte adopte un cadre pixel plus discret.
- Le conteneur des commandes tactiles couvre désormais la scène entière. Les positions sont donc calculées par rapport à l’écran complet, et non par rapport à la hauteur intrinsèque du joystick.
- Les positions tactiles par défaut sont réorganisées. Une ancienne position strictement identique aux anciens réglages par défaut est migrée ; les positions personnalisées différentes sont conservées.
- Le cache PWA est incrémenté à `laj-mobile-pixel-r32` et la nouvelle feuille CSS est ajoutée au précache.

Aucune règle de progression, de génération des labyrinthes, d’énigme, d’ennemi ou de capture n’a été modifiée.

## 5. Points restant à réaliser pour atteindre le projet prévu

1. Concevoir et coder les catégories de pièges des domaines 37–50, leurs avertissements et la reprise depuis le début du chapitre après un piège mortel.
2. Donner à chaque chapitre une énigme, une mécanique, un secret et un danger réellement caractérisés, au-delà de la permutation des trois sceaux.
3. Construire une IA de L’Autre fondée sur une mémoire d’actions, des observations, des choix tactiques et une relation pouvant réellement modifier son comportement.
4. Ajouter les changements de caméra et les séquences de profondeur/hauteur prévus pour les domaines 37–50.
5. Tester les chapitres et commandes en conditions réelles, notamment sur Safari iPhone en paysage et sur ordinateur.

## 6. Limite de la validation QA31

Les contrôles statiques et les tests automatisés de génération ont été exécutés. Une tentative de lancement automatisé Chromium a été bloquée par l’environnement local (`ERR_BLOCKED_BY_ADMINISTRATOR`). Aucun essai visuel ou tactile sur iPhone physique, Android ou ordinateur réel n’est revendiqué. La mise en ligne GitHub Pages n’a pas été vérifiée par cette procédure.
