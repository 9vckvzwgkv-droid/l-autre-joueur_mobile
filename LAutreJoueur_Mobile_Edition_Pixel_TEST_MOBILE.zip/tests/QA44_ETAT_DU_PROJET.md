# L’Autre Joueur Mobile — état après QA44

## Campagne et navigation

- Les 50 cartes se génèrent toujours ; les 14 derniers domaines restent grands et thématisés.
- Les alarmes donnent une destination aux ennemis mobiles proches : ils empruntent un chemin valide vers la dalle sonore pendant quelques secondes. Chaque alarme des grands domaines est placée à portée d’au moins une patrouille mobile. Les sentinelles gardent leur poste et montent en alerte.
- L’alerte audio reste sous le seuil de capture. Un ennemi doit encore voir le joueur pour poursuivre sa capture.
- Le calcul de trajet couvre maintenant toute la carte, au lieu de s’arrêter après 4 500 cases examinées. C’est nécessaire aux domaines allant jusqu’à 99 × 83 cases ; les 50 trajets départ-sortie ont été vérifiés.
- Les profils de ralentissement et d’alarme restent propres aux 14 grands thèmes ; les trois pièges de rappel du chapitre 46 conservent les sceaux et le point sûr en sauvegarde.
- Version de carte maintenue à 9 : seuls les emplacements de piège sonore changent, la géométrie, la progression de chapitre et l’ordre des pièges restent compatibles avec les sauvegardes existantes.
- Cache PWA : `laj-mobile-pixel-r53`.

## Contrôles effectués

- Analyse syntaxique de `content.js`, `game.js`, `visual-pixel.js`, `sw.js` et du script intégré à `index.html`. Les 29 ressources listées pour le mode hors ligne existent dans le paquet.
- Génération des 50 chapitres ; trajet depuis le départ jusqu’à la sortie contrôlé pour chaque carte (longueur calculée : 25 à 175 pas). Les 14 chapitres finaux ont chacun une alarme à portée d’une patrouille mobile.
- Test des 14 grands domaines : chaque alarme générée a une patrouille mobile à portée, son trajet vers la source est calculé et elle avance effectivement vers celle-ci. L’alerte audio seule ne capture pas le joueur.
- Les interactions de ralentissement et de rappel de faille restent vérifiées depuis QA43.

## Reste à valider

- Parcourir les 50 chapitres pour l’équilibrage, la lisibilité des indices et les transitions 2.5D.
- Contrôler commandes tactiles, cadrage, lisibilité et performances sur téléphones iPhone et Android réels.
- Publier sur HTTPS et vérifier l’installation PWA hors ligne sur les appareils visés ; préparer les éventuelles fiches de boutique.
- Comparer le scénario au projet source ou aux fiches PC originales si elles deviennent disponibles.
