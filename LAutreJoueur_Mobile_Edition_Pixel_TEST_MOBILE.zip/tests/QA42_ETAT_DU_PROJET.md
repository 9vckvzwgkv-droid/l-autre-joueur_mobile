# L’Autre Joueur Mobile — état après QA42

## Direction visuelle et animation

- Présentation pixel art 2D, avec quelques salles en perspective 2.5D.
- Le joueur et L’Autre ont une animation de marche à quatre images, une respiration discrète au repos et une apparence arrière lorsqu’ils se dirigent vers le haut ; le golem masque ses yeux quand il tourne le dos.
- Les drones, golems et Gardien gardent leurs animations ; les 14 domaines ont des motifs d’architecture pixel dédiés et chaque chapitre garde sa palette ambiante.
- Le réglage de réduction des mouvements supprime les balancements et animations non essentiels.
- Cache PWA : `laj-mobile-pixel-r51`.

## État de campagne

- 50 chapitres avec cartes et épreuves travaillées, sans suppression des fonctions existantes.
- Le chapitre 1 garde son plan dédié lié aux repères PC. Les chapitres 2 à 36 possèdent leurs topologies et conditions distinctes ; les 14 grands domaines finaux ont leurs plans, thèmes et pièges propres.
- Les anciennes sauvegardes restent prises en charge, avec remise au seuil si la géométrie de chapitre a évolué.

## Contrôle et limites

- Analyse syntaxique réussie pour les trois scripts principaux.
- Les fonctions de rendu des personnages s’exécutent pour quatre orientations principales.
- Le rendu n’a pas été contrôlé sur écran physique ; le nouvel arrière de cape et le cadrage doivent être ajustés si nécessaire sur téléphone et tablette.
- Les 50 chapitres doivent encore être parcourus pour l’équilibrage. La publication HTTPS, les validations iOS/Android et la préparation App Store ne sont pas terminées.
