# L’Autre Joueur Mobile — état après QA40

## État de la campagne

- Le chapitre 1 conserve sa carte dédiée liée au repère PC.
- Les chapitres 2 à 36 ont chacun une topologie de salles propre et une condition d’énigme jouable spécifique.
- Les chapitres 37 à 50 gardent leurs quatorze plans de grands domaines et leurs épreuves dédiées.
- Les 50 chapitres ont des pièges thématiques, des salles ouvertes et des objectifs répartis pour soutenir l’exploration. Les 35 palettes intermédiaires ont été différenciées et nuancées depuis les couleurs du jeu.
- La sauvegarde conserve les progrès de jalons et les nouveaux choix de branche/retour ; les anciennes sauvegardes restent reconnues et la carte en cours redémarre au seuil si sa géométrie change.
- Génération de carte : version 9. Cache PWA : `laj-mobile-pixel-r46`.

## Contrôle de cohérence des données

- `content.js`, `game.js` et `visual-pixel.js` passent l’analyse syntaxique.
- 50 signatures de cases de sol différentes, 35 topologies intermédiaires, 35 identifiants d’épreuve et 35 palettes intermédiaires différents.
- Les cartes générées sont accessibles depuis leur point de départ ; les objectifs et repères sont sur des cases praticables.
- Les approches de miroir, de rive et de trace ont des cases libres conformes à leur règle.
- Tous les chapitres intermédiaires ont un nom de piège thématique.

## Travail restant avant une édition commerciale

- Jouer les 50 chapitres du début à la fin sur petit téléphone, grand téléphone et tablette ; régler les indices, les temps de fenêtre, les rencontres et la durée des chapitres.
- Comparer la campagne à la fiche PC complète si elle devient disponible. Le ZIP PC fourni jusque-là est une application compilée sans plans détaillés des 50 labyrinthes.
- Vérifier la lisibilité et le cadrage 2.5D, les commandes tactiles, le contraste, l’accessibilité, les performances, le son et les reprises de sauvegarde sur iOS et Android.
- Compléter les animations et la finition des décors, préparer l’hébergement HTTPS, puis décider du parcours de publication mobile.

QA40 valide la cohérence des données et l’existence des conditions de jeu dans le code. Il ne certifie pas encore l’équilibrage, une partie complète ou la compatibilité sur appareils physiques.
