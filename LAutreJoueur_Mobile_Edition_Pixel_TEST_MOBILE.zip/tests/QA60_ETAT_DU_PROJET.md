# QA60 — sauvegardes et préparation au test mobile

## Changement apporté

Les sauvegardes automatiques tentent maintenant un enregistrement à la fermeture ou à la mise en cache de la page via `pagehide`. Si le stockage local refuse une écriture, le joueur voit un avertissement en cours de jeu et dans les Réglages. L’export télécharge quand même l’état courant en mémoire et indique clairement l’échec de la copie locale. Le service worker utilise `laj-mobile-pixel-r69` pour diffuser le nouveau script.

Le guide `LISEZ_MOI_PIXEL.md` décrit aussi comment ouvrir le jeu depuis un téléphone connecté au même Wi-Fi que le Mac. Ce mode permet d’essayer les commandes tactiles, mais ne fournit pas l’installation PWA ni le mode hors ligne, qui demandent HTTPS.

Le workflow du dépôt fourni a été corrigé puis lancé avec succès. Il extrait le ZIP placé à la racine du dépôt, puis publie les seuls fichiers du jeu sur https://9vckvzwgkv-droid.github.io/l-autre-joueur_mobile/. Le dossier local reste sans dépôt Git associé. Son archive QA60 a été construite après le ZIP du dépôt et n’a pas été synchronisée ; le site live n’inclut donc pas encore les changements QA60 de sauvegarde.

## État de vérification

Aucun test automatisé, lancement visuel ni parcours sur téléphone n’a été effectué dans cette passe. L’exécution réussie de GitHub Actions confirme l’extraction et la publication, pas le fonctionnement en jeu. Le code de sauvegarde doit encore être éprouvé après mise en arrière-plan, fermeture de l’onglet, redémarrage du navigateur et export/import sur iPhone et Android.

Les résultats des contrôles structurels antérieurs sur les cinquante cartes et les chapitres 44, 48 et 50 sont consignés dans `QA59_ETAT_DU_PROJET.md`. Ils ne valident pas cette modification de sauvegarde.

## Points encore ouverts

- Parcourir les 50 chapitres et régler leur rythme, leurs indications et leur difficulté.
- Vérifier tactilité, affichage portrait/paysage, lisibilité des changements 2.5D et performances sur appareils iOS et Android.
- Confirmer la reprise et l’import/export sur appareil réel.
- Héberger le jeu sur HTTPS, vérifier l’installation et l’ouverture hors ligne, puis préparer les éventuelles distributions App Store et Android.
- Comparer la campagne avec les fiches PC complètes lorsqu’elles seront disponibles.
