# L’Autre Joueur Mobile — état après QA46

## Profondeur visuelle

- Dans les scènes obliques, les personnages sont dessinés selon leur position projetée : les entités situées plus bas dans la scène passent devant celles qui sont plus haut.
- Les cônes de veille sont rendus sous les personnages ; aucun comportement d’ennemi ou de contrôle n’est changé.
- Les escaliers à cinq paliers des salles en profondeur restent actifs et teintés par la palette des chapitres.
- Cache PWA : `laj-mobile-pixel-r55`.

## Vérifications à cette étape

- Analyse syntaxique réussie pour les quatre scripts et le script intégré à la page.
- Scénario de croisement vérifié : drone en arrière-plan, voyageurs à mi-profondeur, patrouille au premier plan selon la coordonnée projetée.
- Les 50 trajets départ-sortie restent accessibles.
- La lecture des scènes 2.5D doit encore être examinée sur téléphone réel ; le jeu n’a pas encore été parcouru intégralement.
- Publication HTTPS et essais d’installation sur iPhone et Android restent à faire.
