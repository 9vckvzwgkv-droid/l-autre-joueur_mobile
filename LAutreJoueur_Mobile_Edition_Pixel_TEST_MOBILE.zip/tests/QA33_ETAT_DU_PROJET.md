# L’Autre Joueur — état après les passes visuelles et QA33

## Changements intégrés
- Interface harmonisée autour de la pierre sombre, de la mousse, de l'or patiné et des runes ambrées (`ui-world-polish.css`).
- Menu d'accueil décoré avec l'illustration du seuil, un cadre minéral et des motifs de lierre.
- Sceaux éveillés, porte et marqueurs de carte réaccordés à l'ambre et au vert mousse.
- Dans les domaines 37 à 50, génération de 20 dalles mortelles et 15 runes engourdissantes par domaine.
- Avertissement contextuel et halo des pièges proches ; effets de piège distincts.
- Les dalles mortelles recommencent les sceaux et l'exploration locale au seuil. La dalle déclenchée reste neutralisée ; les pièges des chapitres 1 à 36 gardent leur retour au dernier point sûr.
- Les souvenirs déjà inscrits dans la sauvegarde restent acquis en cas de reprise ou de retour dans leur chapitre.
- Le style, le moteur et les ressources locales sont pris en charge par la version PWA `laj-mobile-pixel-r34`.

## État de validation
Ces changements n'ont pas encore été joués ou prévisualisés dans un navigateur ou sur appareil. Leur génération et leurs conséquences doivent être contrôlées sur plusieurs domaines avant d'en fixer l'équilibrage.

## Travail restant pour une édition commercialisable
1. Créer des séquences 2.5D jouables pour les grandes zones, avec une caméra de profondeur liée à des passages identifiables.
2. Remplacer la répétition du schéma « trois sceaux puis sortie » par des énigmes et dangers propres aux lieux.
3. Donner à L'Autre une mémoire d'actions et des comportements protecteurs ou agressifs effectivement pilotés par la relation.
4. Vérifier les commandes, la lisibilité, le rythme, les sauvegardes, le son et les performances sur téléphone et ordinateur.
5. Valider le paquet PWA, l'installation HTTPS et la publication cible.
