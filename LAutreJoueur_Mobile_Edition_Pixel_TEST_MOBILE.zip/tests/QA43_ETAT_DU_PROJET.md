# L’Autre Joueur Mobile — état après QA43

## Campagne et pièges

- La campagne comporte toujours 50 chapitres, avec les 14 grands domaines distincts en fin de parcours.
- Les alarmes et ralentissements des 14 domaines ont chacun des paramètres propres au thème.
- Dans le chapitre de la Faille du Silence, trois dalles spéciales renvoient au dernier point sûr. Les sceaux restent acquis, la dalle se consume et le joueur bénéficie d’un bref instant de protection pour se réorienter.
- Les sauvegardes retiennent maintenant la position du dernier point sûr. Les anciennes sauvegardes restent compatibles et utilisent le seuil comme solution de repli.
- Cache PWA : `laj-mobile-pixel-r52`.

## Contrôle et limites

- `content.js`, `game.js`, `visual-pixel.js` et `sw.js` passent l’analyse syntaxique. Les 50 cartes se génèrent ; les 14 profils de domaine sont présents et distincts, avec ralentissements et alarmes disponibles dans chaque grand domaine.
- Vérification isolée du déclenchement : rappel de faille sans mort ni perte de sceaux, ralentissement racines aux valeurs prévues, alarme de veille limitée à sa portée thématique. Le dessin pixel de la faille et d’un piège de racines s’exécute sans erreur. Le point sûr est aussi confirmé dans les données de sauvegarde.
- Les 50 chapitres ne sont pas encore parcourus intégralement pour l’équilibrage.
- Aucun contrôle sur un téléphone physique n’a été réalisé ici ; commandes, visibilité et confort de lecture restent à valider sur iPhone et Android.
- Publication HTTPS, essais d’installation et préparation App Store restent à effectuer.
