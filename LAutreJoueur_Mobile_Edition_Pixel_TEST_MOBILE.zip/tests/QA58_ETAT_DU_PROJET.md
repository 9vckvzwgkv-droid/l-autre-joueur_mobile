# QA58 — état du projet

Cette passe implémente les propositions restantes pour les chapitres 44, 48 et 50. Les modifications sont dans le code, mais elles n’ont pas encore été lancées ni parcourues en jeu.

## Chapitres avancés

- **44 — La Cité des Portes :** plan de quartier à consulter avant les trois herses. Les enseignes spirale, aiguille et croissant sont dessinées distinctement ; leur ordre est indiqué après lecture du plan. Le plan lu et les portes ouvertes alimentent les repères proches, la carte et la sauvegarde.
- **48 — La Nécropole des Mémoires :** trois fragments de L’Autre désignent chacun une tombe. Il faut écouter les trois fragments, associer les tombes dans leur ordre, puis retrouver le souvenir caché, qui reste nécessaire aux sceaux. Les lectures sont sauvegardées.
- **50 — Au-delà du Dernier Seuil :** trois signes — trace, lanterne et serment — doivent être lus dans un ordre défini par la carte et inscrit dans le carnet. Les sceaux demandent aussi l’exploration d’au moins la moitié des salles et la proximité de L’Autre. Le choix « partir ensemble / partir seul » est conservé.
- Les chapitres 44, 48 et 50 utilisent `mapVersion` 10. Le cache hors ligne est maintenant `laj-mobile-pixel-r67`.

## État des grands domaines

- 37 : faisceaux de sentinelles — implémenté précédemment, parcours complet à vérifier.
- 38 : clairières et racines — mécanique présente, parcours complet à vérifier.
- 39 : ponts et courants — travaillé en QA52, parcours complet à vérifier.
- 40 : cotes et page aux signatures — approfondi en QA54.
- 41 : cadrans et cour centrale — approfondi en QA55.
- 42 : lanternes, racines lumineuses et halos — approfondi en QA56.
- 43 : rides réelles et reflets inversés — approfondi en QA57.
- 44 : plan incomplet et enseignes de portes — implémenté en QA58, non vérifié en jeu.
- 45 : prismes colorés — mécanique présente.
- 46 : pont stable révélé par ses vibrations — mécanique présente.
- 47 : rappel ordonné des golems — mécanique présente, parcours complet à vérifier.
- 48 : fragments associés aux tombes — implémenté en QA58, non vérifié en jeu.
- 49 : marques distinctes pour les deux voyageurs — mécanique présente.
- 50 : synthèse des trois signes avant le choix final — implémentée en QA58, non vérifiée en jeu.

## Vérifications à faire

Aucun test automatisé, parcours complet ou essai sur téléphone n’a été exécuté pour QA58. Il faut vérifier la syntaxe et le lancement du jeu, les placements sur les cartes générées, les interactions dans le bon et le mauvais ordre, la reprise des sauvegardes, la progression des sceaux et la fin du chapitre 50.

Restent également à faire le parcours des cinquante chapitres, l’équilibrage, les essais tactiles et visuels sur iPhone et Android, les contrôles de performance et d’installation hors ligne, ainsi que la comparaison avec le scénario PC complet si ses fiches détaillées ou son projet source sont disponibles.
