# QA61 — état du projet mobile

## Changements préparés

L’accueil dispose d’une illustration cohérente avec l’univers du jeu et d’une animation d’environ 1,5 seconde, avec bouton de passage et prise en compte de la réduction des mouvements. L’icône de l’application utilise la même direction artistique.

Les panneaux de réglages ne doivent plus comprimer leurs cartes : la page défile verticalement tout en gardant les boutons et options lisibles. La caméra conserve une vue de dessus dans les salles ordinaires et transite progressivement vers une perspective 2.5D discrète dans les salles en profondeur. Les commandes de déplacement suivent ce cadrage.

Les 41 chapitres concernés utilisent des objectifs spécifiques au lieu d’exiger systématiquement trois activations de sceaux. Les neuf autres conservent leur épreuve de sceaux. Les identifiants d’épreuves intermédiaires sont distincts. Ces changements visent directement la répétition signalée en test, mais ne prouvent pas à eux seuls que l’expérience des 50 chapitres est équilibrée et sans ressemblances ressenties.

## Vérification

- Pré-vol mobile : 11 contrôles réussis sur 11 (identifiants HTML, accessibilité des boutons, ressources, icônes, service worker, manifeste, sauvegardes). Le pré-vol accepte maintenant correctement l’orientation `any`, compatible avec le jeu en portrait et en paysage.
- Audit des cartes : 700 assertions réussies, zéro échec.
- Audit structurel complet : 50 chapitres, 36 labyrinthes, 14 domaines, 50 dispositions distinctes et reliées, aucun problème de ressource ou de placement. Le rapport est dans `tests/QA61_AUDIT.json`.
- Vérification de syntaxe : cinq scripts JavaScript réussis.
- Publication GitHub Pages : exécution QA61 terminée avec succès, commit `3c69a2e83e24fae8f3300138964b4c1ed0f636b9`, [résultat du déploiement](https://github.com/9vckvzwgkv-droid/l-autre-joueur_mobile/actions/runs/44958424729).

Ces contrôles ne remplacent pas un lancement visuel ou une partie sur appareil. Aucun parcours complet sur téléphone n’a encore été fait pour QA61 ; les réglages, la transition de caméra, les nouvelles épreuves, les sauvegardes interrompues et le mode hors ligne doivent être éprouvés sur iPhone et Android.

## À faire avant commercialisation

- Parcourir chaque chapitre et vérifier son objectif, ses indices, ses pièges, sa sortie et sa différence de rythme.
- Refaire les captures sur iPhone en portrait et paysage, notamment Réglages, et confirmer que les cartes ne se chevauchent plus.
- Évaluer la transition de caméra et la lisibilité des commandes tactiles dans plusieurs salles 2.5D ; vérifier les performances sur appareil réel.
- Confirmer l’accueil, l’icône, le mode hors ligne et les sauvegardes sur iOS et Android.
- Comparer l’ensemble à la documentation PC dès que les fiches détaillées ou le projet source deviennent accessibles.
- Préparer une version distribuable et vérifier les droits des ressources avant toute vente.
