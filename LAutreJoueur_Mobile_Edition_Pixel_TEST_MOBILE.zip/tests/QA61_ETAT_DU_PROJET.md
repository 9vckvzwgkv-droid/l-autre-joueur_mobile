# QA61 — état du projet mobile

## Changements préparés

L’accueil dispose d’une illustration cohérente avec l’univers du jeu et d’une animation d’environ 1,5 seconde, avec bouton de passage et prise en compte de la réduction des mouvements. L’icône de l’application utilise la même direction artistique.

Les panneaux de réglages ne doivent plus comprimer leurs cartes : la page défile verticalement tout en gardant les boutons et options lisibles. La caméra conserve une vue de dessus dans les salles ordinaires et transite progressivement vers une perspective 2.5D discrète dans les salles en profondeur. Les commandes de déplacement suivent ce cadrage.

Les 41 chapitres concernés utilisent des objectifs spécifiques au lieu d’exiger systématiquement trois activations de sceaux. Les neuf autres conservent leur épreuve de sceaux. Les identifiants d’épreuves intermédiaires sont distincts. Ces changements visent directement la répétition signalée en test, mais ne prouvent pas à eux seuls que l’expérience des 50 chapitres est équilibrée et sans ressemblances ressenties.

## Vérification

Aucun test automatisé ni parcours sur téléphone n’a été réalisé dans cette passe. Le rapport QA59 documente les précédents contrôles structurels des cartes ; il ne valide pas les changements QA61. L’état de publication Pages doit être confirmé après synchronisation de cette archive.

## À faire avant commercialisation

- Parcourir chaque chapitre et vérifier son objectif, ses indices, ses pièges, sa sortie et sa différence de rythme.
- Refaire les captures sur iPhone en portrait et paysage, notamment Réglages, et confirmer que les cartes ne se chevauchent plus.
- Évaluer la transition de caméra et la lisibilité des commandes tactiles dans plusieurs salles 2.5D ; vérifier les performances sur appareil réel.
- Confirmer l’accueil, l’icône, le mode hors ligne et les sauvegardes sur iOS et Android.
- Comparer l’ensemble à la documentation PC dès que les fiches détaillées ou le projet source deviennent accessibles.
- Préparer une version distribuable et vérifier les droits des ressources avant toute vente.
