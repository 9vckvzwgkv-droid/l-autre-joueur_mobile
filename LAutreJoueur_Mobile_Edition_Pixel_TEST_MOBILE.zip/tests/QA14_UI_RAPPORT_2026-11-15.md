# QA14 — Rapport de validation interface — 2026-11-15

## Contrôles effectués
- PASS — `node --check game.js`
- PASS — `node --check content.js`
- PASS — `node --check visual-pixel.js`
- PASS — 98 identifiants HTML, aucun doublon.
- PASS — 76 références directes `$()` du JavaScript, toutes présentes dans le HTML.
- PASS — ressources locales référencées par HTML présentes.
- PASS — feuille `ui-modern.css` liée et précachée par le service worker.
- PASS — cache PWA incrémenté à `laj-mobile-pixel-r15`.
- PASS — `content.js`, `visual-pixel.js`, `style.css`, `visual-pixel.css` et les ressources art/audio inchangés depuis QA13.

## Fonctions ajoutées à l'interface
- Curseurs de volume plus grands, avec affichage du pourcentage et aperçu sonore.
- Volume musique pilotant les pistes audio ; volume bruitages pilotant les effets WebAudio.
- Mini-carte permanente activable/désactivable.
- Carte détaillée avec zoom réglable et boutons + / −.
- Éditeur de disposition tactile : déplacement individuel du joystick, Agir, L'Autre et Courir ; positions sauvegardées localement et réinitialisables.
- Réglage de taille et d'opacité des commandes tactiles.
- Réglages additionnels rétrocompatibles avec les sauvegardes antérieures.
- Menus d'accueil, réglages, pause, chapitres, carte, carnet et dialogues harmonisés.

## Limites de validation
- Le navigateur de test local a refusé l'ouverture (`ERR_BLOCKED_BY_ADMINISTRATOR`) ; aucun test visuel automatisé de navigateur n'a donc pu être mené.
- Aucun test physique iPhone/Android ou ordinateur n'a été effectué dans cette session.
- Le contrôle réel du volume et du placement tactile doit être confirmé sur l'appareil après publication.

## Périmètre de préservation
Aucun changement aux données des 50 chapitres, à la génération des cartes, aux collisions, aux déplacements, aux ennemis, à l'IA de L'Autre, aux énigmes, aux pièges, à la progression ou aux conditions de fin.
