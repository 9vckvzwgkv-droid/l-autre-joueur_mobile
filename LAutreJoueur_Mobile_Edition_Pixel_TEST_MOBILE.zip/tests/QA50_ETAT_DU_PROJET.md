# L’Autre Joueur Mobile — état après QA50

## Chapitre 49 · La Cathédrale des Serments

- Trois paires de marques accompagnent les trois sceaux. Le voyageur doit rester sur la marque du sceau actif ; L’Autre rejoint la marque distincte, puis le joueur peut lui demander d’attendre.
- À l’approche du sceau courant, L’Autre se dirige vers sa marque. Le repère a un motif pixel art propre, s’allume quand le compagnon est dessus, et apparaît sur la carte. Le journal et le HUD décrivent l’étape.
- La condition rejette l’absence d’attente et les deux personnages sur la même marque.
- La carte 49 passe à `mapVersion` 10. Les anciennes données locales de ce chapitre sont rafraîchies à la reprise ; les sceaux acquis et la progression de campagne sont préservés.

## Vérifications de cette version

- `content.js`, `game.js`, `visual-pixel.js`, `companion-ai.js` et `sw.js` passent l’analyse syntaxique JavaScript.
- Génération des cinquante chapitres : 50 topologies et 50 identifiants d’épreuve distincts dans cette passe, aucun chemin départ-sortie manquant et aucun piège dupliqué.
- Chapitre 49 : les trois paires ont une séparation de deux cases ; les six positions sont praticables et les chemins du seuil aux marques et à la sortie sont présents.
- La simulation de la règle du serment refuse l’absence d’attente, accepte les deux personnages sur leurs marques distinctes et refuse leur présence sur la même marque.
- Le chapitre 49 atteint la sortie par un chemin de 130 cases dans la graine examinée. Le chapitre 46 conserve ses trois ponts, un stable et deux instables.
- Le cache PWA utilise `laj-mobile-pixel-r59`; le manifeste permet le portrait et le paysage.

## Travail restant avant publication

- Comparer et compléter les épreuves et géométries des quatorze grands domaines, en commençant par les écarts entre les mécaniques actuelles et les énigmes prévues dans le tableau.
- Parcourir tous les chapitres pour vérifier leurs énigmes, leur rythme, leur lisibilité et les cas de blocage ; les audits de données ne remplacent pas cette partie.
- Effectuer les vérifications visuelles et tactiles sur téléphones iPhone et Android réels, en portrait et paysage, puis vérifier la sauvegarde et le jeu hors ligne.
- Publier sur HTTPS, vérifier le parcours d’installation et préparer les visuels, informations et contrôles requis par la voie de distribution choisie.

Le ZIP de l’application PC fourni est une application compilée et ne contient pas le dossier de conception détaillé des cinquante labyrinthes. Cette édition suit la proposition mobile validée ; la comparaison scénario par scénario avec le jeu PC attend toujours ses fiches ou son projet source.
