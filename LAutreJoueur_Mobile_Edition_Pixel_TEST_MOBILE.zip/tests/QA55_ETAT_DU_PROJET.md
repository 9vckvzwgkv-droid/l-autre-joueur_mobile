# L’Autre Joueur Mobile — état après QA55

## Chapitre 41 · Le Désert des Horloges

- Trois cadrans arrêtés sont répartis dans trois salles. Chaque aiguille tourne sur les repères 12 h, 3 h, 6 h et 9 h ; les socles gravés donnent les heures à atteindre : 3 h, 6 h et 9 h.
- Les cadrans accordés font apparaître le grand cadran de la cour centrale. L’actionner ouvre la cour et autorise les sceaux.
- La règle temporelle déjà présente est conservée : le cadran cyclique tourne et chaque sceau ne répond que pendant son heure.
- Les icônes pixel art distinguent l’heure actuelle de l’heure cible. Le contexte proche, la carte et le journal indiquent les cadrans réglés, l’état de la cour et l’heure du cycle.
- La carte mesure 83 × 83 cases et comprend 36 salles. Les trois réglages sont accessibles dans des salles distinctes ; le grand cadran central se trouve dans une quatrième salle, sans chevauchement avec les runes ou pièges dans la génération contrôlée.
- L’état des aiguilles et du grand cadran est sauvegardé. Une ancienne sauvegarde du chapitre passe au seuil de la nouvelle carte avec les sceaux acquis ; son exploration locale et les nouveaux réglages recommencent.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 cartes générées conservent 50 topologies et identifiants d’énigme distincts, des sorties accessibles et des pièges sans positions dupliquées.
- Les trois heures fixes sont distinctes et les interactions de sceau gardent le cycle horaire antérieur après l’ouverture de la cour.
- Les 29 ressources déclarées par le cache hors ligne existent dans le paquet.
- Ces contrôles structurels ne remplacent pas le parcours de la campagne ni des essais sur téléphone.

## État des grands labyrinthes

- 37 : convergence de trois faisceaux et zones d’ombre — implémenté et contrôlé.
- 38 : clairières reliées par les racines — progression ordonnée présente.
- 39 : ponts de brume, courants et reflets — implémenté et contrôlé.
- 40 : cotes d’archives, volumes ordonnés et page aux signatures obligatoire — implémenté et contrôlé structurellement.
- 41 : horloges arrêtées, grand cadran central et sceaux temporisés — implémenté et contrôlé structurellement.
- 42 à 44 : lanternes, reflets de marais et portes de quartier — à rapprocher de leurs propositions.
- 45 : prismes tournants et trois couleurs cibles — implémenté et contrôlé.
- 46 : trois ponts vibratoires, un sûr — implémenté et contrôlé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et contrôlé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 42 à 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles. Le cache PWA actuel utilise `laj-mobile-pixel-r64`.
