# L’Autre Joueur — état après QA35

Le projet conserve sa campagne mobile de 50 chapitres, ses commandes configurables, son HUD, sa carte, ses sauvegardes, son audio, son mode hors ligne, ses pièges et ses ennemis. Le chapitre 1 conserve le plan PC **Trace**.

## Monde mobile
- Les cartes des chapitres 2 à 50 s'articulent autour de salles de plusieurs cases reliées par des passages larges et des boucles.
- Les sceaux, le souvenir et la sortie sont répartis dans cinq salles distinctes.
- Des chambres dédiées portent des éléments de sanctuaire et activent une projection oblique 2.5D progressive. Les commandes tactiles et le HUD restent plats ; les directions d'entrée sont converties pour correspondre au mouvement à l'écran.
- Les grands domaines conservent 20 pièges mortels et 15 pièges ralentisseurs.

## Progression
Les sauvegardes antérieures gardent la progression narrative et les sceaux acquis. Comme les objectifs ont changé de salle, la position, les découvertes cartographiques et les pièges déclenchés sont remis au seuil lors de la migration géométrique. Le nouveau `mapVersion` est 3.

## Contrôles structurels QA35
- 50 cartes : aucun secteur praticable isolé et aucun objectif, piège ou ennemi testé sur une case inaccessible.
- 49 cartes refaites : sortie, trois sceaux et souvenir dans cinq salles distinctes.
- 14 domaines : répartition 20/15 des pièges confirmée.
- Le déplacement calculé dans huit directions se reprojette dans la même direction d'écran ; les scripts modifiés passent l'analyse syntaxique.

## Encore nécessaire pour une édition commerciale
Les séquences 2.5D doivent devenir de vraies petites mises en scène jouables et être validées sur iPhone et Android. La campagne a encore besoin d'énigmes propres aux lieux, d'une mémoire d'actions pour L'Autre, d'un équilibrage en partie, de contrôles de performance et d'une vérification PWA/publication HTTPS.
