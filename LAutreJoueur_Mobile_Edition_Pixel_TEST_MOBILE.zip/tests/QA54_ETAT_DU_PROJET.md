# L’Autre Joueur Mobile — état après QA54

## Chapitre 40 · La Bibliothèque Infinie

- Trois volumes aux cotes incomplètes sont placés dans des salles d’archives distinctes. Leur ordre correct est celui des travées A, B puis C.
- Les volumes ne suffisent pas : le joueur doit ensuite trouver la page cachée aux signatures pâles. Celle-ci dévoile le nom et devient une condition obligatoire pour éveiller les sceaux.
- Le repère proche affiche la cote du livre à consulter. Le journal et la carte montrent l’avancement ; chaque livre a un marqueur pixel art ambré propre à sa cote.
- La carte générée mesure 75 × 75 cases et comprend 32 salles. Les trois livres et la page sont accessibles et ne partagent pas de salle.
- Le chapitre utilise l’identité d’archives déjà prévue : travées, poussière dorée, palette prune et ambre, pièges de rayonnages.
- Le chapitre passe à `mapVersion` 10. À la reprise d’une ancienne sauvegarde dans ce chapitre, les sceaux acquis et les souvenirs sont conservés ; la position revient au seuil et l’exploration, les pièges consommés et la progression des livres repartent sur la nouvelle carte.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 cartes générées ont 50 topologies et 50 identifiants d’énigme distincts ; chaque sortie est accessible et aucune carte testée ne duplique la position d’un piège.
- Le chapitre 40 possède ses trois livres, leur ordre est A-0? → B-1? → C-2?, et la condition des sceaux exige la page de signatures après les volumes.
- Ces contrôles vérifient la génération et les conditions codées ; ils ne constituent pas un parcours complet en jeu.

## État des grands labyrinthes

- 37 : convergence de trois faisceaux et zones d’ombre — implémenté et contrôlé.
- 38 : clairières reliées par les racines — progression ordonnée présente.
- 39 : ponts de brume, courants et reflets — implémenté et contrôlé.
- 40 : cotes d’archives, volumes ordonnés et page aux signatures obligatoire — implémenté et contrôlé structurellement.
- 41 à 44 : horloges, lanternes, reflets de marais et portes de quartier — à rapprocher de leurs propositions.
- 45 : prismes tournants et trois couleurs cibles — implémenté et contrôlé.
- 46 : trois ponts vibratoires, un sûr — implémenté et contrôlé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et contrôlé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 41 à 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles. Le cache PWA actuel utilise `laj-mobile-pixel-r63`.
