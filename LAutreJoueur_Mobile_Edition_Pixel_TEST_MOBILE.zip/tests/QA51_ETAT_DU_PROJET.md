# L’Autre Joueur Mobile — état après QA51

## Chapitre 45 · Les Profondeurs Cristallines

- L’énigme demande maintenant de réfracter la lumière de chaque sceau vers sa teinte cible, au lieu de simplement regarder un marqueur.
- Chaque cristal tourne d’un quart de tour lorsque le joueur agit près de lui. Le rayon dessiné suit cette orientation ; le cristal et la rune reprennent la couleur à viser.
- Les trois cibles possèdent des orientations et des couleurs différentes. Le contexte annonce la direction actuelle et la couleur visée ; le journal indique les couleurs accordées et celles à régler.
- La sauvegarde locale, l’export et l’import transportent les trois orientations, avec contrôle des valeurs.

## Vérifications de cette version

- Les scripts JavaScript principaux et le script intégré dans `index.html` passent l’analyse syntaxique.
- Simulation des trois runes : l’orientation initiale échoue pour chaque sceau, les trois orientations cibles réussissent.
- Simulation de l’action sur le cristal : une pression tourne le rayon d’un quart de tour et affiche un retour sonore et textuel.
- Les cinquante chapitres conservent chacun un identifiant de mécanique et un profil de topologie distincts dans cette génération. Les sceaux, souvenirs et sorties sont reliés au seuil ; les pièges ne sont pas dupliqués.
- Le manifeste autorise le portrait et le paysage ; le cache hors ligne utilise `laj-mobile-pixel-r60` et toutes ses ressources déclarées existent.

## État des grands labyrinthes

- 45 : prismes tournants et trois couleurs cibles — implémenté et simulé.
- 46 : trois ponts vibratoires, un sûr — implémenté et simulé.
- 47 : trois golems à rappeler dans l’ordre puis à laisser rentrer — mécanique déjà présente, parcours complet à faire.
- 49 : deux marques distinctes par sceau — implémenté et simulé.
- Les fiches des chapitres 37 à 44, 48 et 50 restent à comparer en détail au jeu. Plusieurs demandes de conception sont plus riches que les conditions actuelles ; les identifiants distincts ne suffisent pas à en faire des énigmes complètes.

## Travail restant

- Développer les différences manquantes des chapitres 37 à 44, 48 et 50, puis vérifier toutes les épreuves en jeu.
- Parcourir et équilibrer les cinquante chapitres, en particulier les quatorze grands domaines et les risques de blocage.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur téléphones iPhone et Android réels.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La référence de jeu PC fournie était compilée et n’incluait pas les plans de conception détaillés. La comparaison avec le scénario complet PC reste donc conditionnée à ses fiches ou à son projet source.
