# L’Autre Joueur Mobile — état après QA56

## Chapitre 42 · Les Jardins Suspendus

- Trois lanternes-guide sont placées dans trois salles distinctes. Chacune s’oriente selon quatre directions cardinales ; les signes cibles sont l’ouest, l’est et le sud.
- Quand une lanterne est correctement orientée, un chemin de racines pixel art apparaît le long des passages jusqu’au halo qu’elle guide.
- L’épreuve conserve la règle déjà prévue : chaque sceau ne répond que si le joueur se tient dans le halo de sa lanterne correspondante.
- Les marqueurs montrent l’orientation présente et la direction cible. La carte et le journal comptent les lanternes accordées ; les réglages sont sauvegardés.
- La carte mesure 91 × 67 cases et comprend 30 salles. Les trois commandes de lanterne sont accessibles dans des salles séparées. Les trois halos sont praticables et reliés par des passages accessibles.
- Le chapitre passe à `mapVersion` 10. Les anciennes sauvegardes reprennent au seuil avec leurs sceaux acquis ; le brouillard, les pièges consommés et les orientations locales sont réinitialisés.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 cartes générées conservent 50 topologies et identifiants d’énigme distincts, des sorties accessibles et des pièges sans positions dupliquées.
- Les cibles cardinales des lanternes sont différentes de leur position de départ ; les trois chemins calculés rejoignent des halos accessibles.
- Les 29 ressources déclarées par le cache hors ligne existent dans le paquet.
- Ces contrôles structurels ne remplacent pas une partie complète ni des essais sur appareils mobiles.

## État des grands labyrinthes

- 37 : convergence de trois faisceaux et zones d’ombre — implémenté et contrôlé.
- 38 : clairières reliées par les racines — progression ordonnée présente.
- 39 : ponts de brume, courants et reflets — implémenté et contrôlé.
- 40 : cotes d’archives, volumes ordonnés et page aux signatures obligatoire — implémenté et contrôlé structurellement.
- 41 : horloges arrêtées, grand cadran central et sceaux temporisés — implémenté et contrôlé structurellement.
- 42 : lanternes orientables, sentiers de racines lumineuses et halos des sceaux — implémenté et contrôlé structurellement.
- 43 et 44 : reflets de marais et portes de quartier — à rapprocher de leurs propositions.
- 45 : prismes tournants et trois couleurs cibles — implémenté et contrôlé.
- 46 : trois ponts vibratoires, un sûr — implémenté et contrôlé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et contrôlé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 43 et 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles. Le cache PWA actuel utilise `laj-mobile-pixel-r65`.
