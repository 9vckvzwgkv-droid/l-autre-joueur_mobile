# L’Autre Joueur Mobile — état après QA37

Le projet contient une campagne mobile de 50 chapitres, des commandes tactiles, des sauvegardes, un compagnon qui mémorise certaines habitudes, des salles pixel art et des changements de perspective 2.5D dans certaines salles. Cette passe relie la génération des cartes aux profils de chapitres et donne des signes visuels thématiques aux pièges.

## Résultat de cette passe
- 50 combinaisons d’ordre des sceaux et de gestes différentes dans les données ; elles ne représentent pas encore 50 énigmes conçues comme des systèmes entièrement distincts.
- 50 dispositions différentes au niveau des cases générées, avec des familles de graphes procédurales réutilisées dans plusieurs chapitres intermédiaires.
- Quatorze topologies, ambiances et styles de pièges pour les chapitres 37 à 50.
- Trois effets de piège : mortel, ralentissant et sonore.
- Tous les objectifs, ennemis et passages des cartes générées restent accessibles depuis le départ.
- La carte PC dédiée du chapitre 1 garde sa disposition et ses points clés.
- Cache PWA hors ligne : `laj-mobile-pixel-r40`.

## À réaliser avant de parler d’édition commerciale
- Valider la proposition de conception des 50 labyrinthes et énigmes avec les plans PC originaux, lorsqu’ils seront disponibles. Le ZIP fourni est une application compilée, sans dossier de niveaux complet.
- Relire les propositions de génération avec le scénario PC complet lorsqu’il sera disponible ; vérifier les raccords narratifs et les mécaniques originales de chaque chapitre.
- Jouer les 50 chapitres du début à la fin, équilibrer les énigmes, le compagnon, les ennemis et les trois effets de piège.
- Vérifier commandes, lisibilité, performances, sauvegardes et affichage sur iPhone et Android, en portrait et paysage.
- Finaliser animations, ambiance sonore, accessibilité, installation/mise à jour hors ligne, mentions, droits et exigences de la plateforme de diffusion choisie.

Les résultats de QA37 vérifient la cohérence des données générées et l’analyse syntaxique ; ils ne certifient pas une publication commerciale.
