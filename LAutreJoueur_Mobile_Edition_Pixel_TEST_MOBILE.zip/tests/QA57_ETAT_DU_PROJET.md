# L’Autre Joueur Mobile — état après QA57

## Chapitre 43 · Les Marais des Reflets

- Chaque salle de rune dispose de deux bassins : les rides réelles et leur reflet. Les deux indications pointent vers des côtés opposés.
- Examiner les rides réelles révèle le côté praticable à suivre pour rejoindre la rune. Les trois vraies indications doivent être lues avant que les sceaux répondent ; le joueur doit ensuite approcher chaque rune par le côté indiqué.
- Examiner un faux reflet marque la lecture dans le carnet, mais ne fait pas progresser l’épreuve. Le texte signale que son courant est inversé.
- Six repères d’eau pixel art sont visibles dans les bassins. La carte montre les repères explorés et à découvrir ; le journal compte les vrais courants lus. La progression est sauvegardée.
- La carte mesure 99 × 75 cases et contient 30 salles. Les six bassins sont sur des cases praticables dans les trois salles des runes et restent accessibles.
- Le chapitre passe à `mapVersion` 10. Les anciennes sauvegardes reprennent au seuil avec leurs sceaux acquis ; le brouillard, les pièges consommés et les lectures de bassins recommencent.

## Vérifications de cette version

- Les scripts principaux passent l’analyse syntaxique.
- Les 50 cartes générées conservent 50 topologies et identifiants d’énigme distincts, des sorties accessibles et des pièges sans positions dupliquées.
- Les six bassins sont accessibles et distincts ; les trois couples de directions sont opposés et chaque paire de bassins est associée à la bonne salle de rune.
- Les 29 ressources déclarées par le cache hors ligne existent dans le paquet.
- Ces contrôles structurels ne remplacent pas le parcours complet ni des essais sur téléphones.

## État des grands labyrinthes

- 37 : convergence de trois faisceaux et zones d’ombre — implémenté et contrôlé.
- 38 : clairières reliées par les racines — progression ordonnée présente.
- 39 : ponts de brume, courants et reflets — implémenté et contrôlé.
- 40 : cotes d’archives, volumes ordonnés et page aux signatures obligatoire — implémenté et contrôlé structurellement.
- 41 : horloges arrêtées, grand cadran central et sceaux temporisés — implémenté et contrôlé structurellement.
- 42 : lanternes orientables, sentiers de racines lumineuses et halos des sceaux — implémenté et contrôlé structurellement.
- 43 : rides réelles et reflets inversés avant l’approche des runes — implémenté et contrôlé structurellement.
- 44 : portes de quartier et plan incomplet — à rapprocher de sa proposition.
- 45 : prismes tournants et trois couleurs cibles — implémenté et contrôlé.
- 46 : trois ponts vibratoires, un sûr — implémenté et contrôlé.
- 47 : golems rappelés dans l’ordre puis renvoyés à leurs socles — mécanique présente, parcours complet à faire.
- 48 : souvenir de la nécropole — condition présente, à rapprocher de l’association entre fragments et tombes.
- 49 : deux marques distinctes par sceau — implémenté et contrôlé.
- 50 : exploration convergente et choix final — structure présente, énigme de synthèse à approfondir.

## Travail restant

- Rapprocher les épreuves des chapitres 44, 48 et 50 de leurs propositions, sans retirer leurs mécaniques actuelles.
- Parcourir et équilibrer les cinquante chapitres, en vérifiant notamment les blocages, les retours et la lisibilité des quatorze grands domaines.
- Faire les essais visuels, tactiles, d’orientation, de performance et de sauvegarde sur iPhone et Android.
- Vérifier l’installation hors ligne depuis un hébergement HTTPS, puis préparer la publication et la distribution choisie.

La version PC fournie était compilée et ne contenait pas les fiches détaillées de campagne. La comparaison avec le scénario complet PC reste à faire si ces fiches ou le projet source deviennent disponibles. Le cache PWA actuel utilise `laj-mobile-pixel-r66`.
