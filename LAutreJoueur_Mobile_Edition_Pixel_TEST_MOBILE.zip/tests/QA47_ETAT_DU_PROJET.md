# L’Autre Joueur Mobile — état après QA47

## Énigmes et progression

- Chapitre 46 : l’épreuve du silence ne réussit plus immédiatement. Il faut appeler L’Autre pendant l’étape concernée puis laisser retomber l’écho pendant trois secondes.
- Chapitre 47 : chaque repère désigne un golem précis. Le joueur rappelle les trois gardiens dans l’ordre ; chacun emprunte le chemin vers son socle et s’y immobilise. L’épreuve des runes attend les trois retours.
- Le repère proche et le carnet indiquent les rappels demandés et les socles rejoints. À la reprise, les golems déjà rappelés sont replacés sur leurs socles conformément à la progression sauvegardée.
- Chapitre 28 : rester masqué ne suffit plus, le joueur doit également attendre que le golem tourne le dos.
- Les marques ont un motif pixel art de pierre sombre et d’ambre. La géométrie n’a pas changé ; la sauvegarde conserve sa version de carte 9.
- Cache PWA : `laj-mobile-pixel-r56`.

## Vérifications de cette étape

- Analyse syntaxique réussie pour `game.js`, `content.js`, `visual-pixel.js`, `sw.js` et le script intégré à `index.html`.
- Les 50 sorties restent accessibles depuis leur départ.
- Les 50 chapitres ont des identifiants de topologie, d’épreuve, d’ordre et de règle de sceau, ainsi que des empreintes de carte distincts.
- Chapitre 46 : l’épreuve échoue sans appel ou avant trois secondes et réussit après le délai complet.
- Chapitre 47 : l’épreuve reste fermée avant les retours ; une simulation de déplacement a ramené les trois golems sur leurs cases de socle.
- Chapitre 28 : l’épreuve réussit quand le golem masqué tourne le dos et échoue quand il fait face au joueur.

## Travail restant

- Comparer les détails de scénario avec une fiche PC complète si elle est disponible.
- Parcourir et équilibrer les 50 chapitres en jeu, en particulier les grands domaines 37 à 50.
- Examiner l’affichage 2.5D, les contrôles, les performances, les sauvegardes et l’installation hors ligne sur iPhone et Android réels.
- Finaliser l’hébergement HTTPS et la préparation de publication mobile.
