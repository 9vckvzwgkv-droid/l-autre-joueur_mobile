# L’Autre Joueur Mobile — état après QA39

La proposition de conception des 50 chapitres a été validée par le joueur comme base de travail. Cette étape transforme les mécaniques des chapitres 37 à 50 en épreuves réellement vérifiées par le jeu.

## Progrès vérifié
- Quatorze épreuves de domaine, une par chapitre final.
- Parcours numéroté et sauvegardé pour les racines (38), feuillets (40) et portes (44).
- Fenêtre de marée pour le chapitre 39, phases de cadran pour le 41, lanternes de sceau pour le 42.
- Approche depuis le côté indiqué pour les reflets (43), orientation vers des prismes (45), fenêtre de silence (46), cachette face aux golems (47), souvenir préalable (48), attente du compagnon (49) et exploration de la moitié des salles (50).
- Repères visibles dans le monde ; état de la marée, du cadran et de l’exploration visible près du sceau et dans le carnet.
- 50 plans distincts au niveau des cases et 50 combinaisons d’ordre et d’actions différentes.
- Aucun repère de domaine ne se trouve dans un mur ou ne chevauche un piège, une lanterne ou un ennemi.
- Cache PWA hors ligne `laj-mobile-pixel-r42`, génération en version 7.

## Travail restant
- Donner aux chapitres 2 à 36 leurs mécaniques propres, au-delà des combinaisons d’actions sur les sceaux.
- Reconcevoir les familles procédurales répétées pour que chaque labyrinthe ait un rythme et une silhouette distincts, puis jouer les 50 cartes.
- Comparer les propositions avec le scénario PC original si les fiches ou le projet source deviennent disponibles.
- Vérifier l’expérience tactile, le contraste, les performances, les sauvegardes et l’installation sur iPhone et Android.
- Finir animations, sons, accessibilité et préparation de diffusion.

QA39 confirme le code des mécaniques finales et les données de carte ; il ne certifie pas une partie complète ni une publication commerciale.
