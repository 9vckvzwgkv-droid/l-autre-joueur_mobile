/* Presentation layer for the existing Mobile 2D maps. One solid tile stays one solid tile. */
(function (root) {
  'use strict';

  const atl = new Image();
  atl.src = 'art/sprites-pixel.png';
  const size = 24;
  const cache = new Map();
  const moss = ['#1a3330', '#2b4e40', '#426b4e', '#6e8760'];
  const ink = '#0d171f';
  const directions = [[0,-1,1], [1,0,2], [0,1,4], [-1,0,8]];
  const trapLooks = {
    sentinel:{base:'#344a58',accent:'#c3dbed',glow:'156,193,223',motif:'rays'},
    racines:{base:'#354938',accent:'#a6d27d',glow:'129,187,105',motif:'roots'},
    noyade:{base:'#29444c',accent:'#8ed7dd',glow:'93,183,194',motif:'ripples'},
    rayonnages:{base:'#4a3847',accent:'#d4a97b',glow:'198,145,104',motif:'shelves'},
    engrenages:{base:'#51452e',accent:'#f0c26b',glow:'226,173,77',motif:'gear'},
    ronces:{base:'#354331',accent:'#bed278',glow:'164,195,102',motif:'thorns'},
    vase:{base:'#304642',accent:'#82c4b0',glow:'103,177,153',motif:'bog'},
    herses:{base:'#49404b',accent:'#dab5c9',glow:'183,139,174',motif:'bars'},
    cristaux:{base:'#303b65',accent:'#9ce9ff',glow:'116,209,243',motif:'crystal'},
    abime:{base:'#2d343a',accent:'#d4d6db',glow:'161,177,188',motif:'rift'},
    seismes:{base:'#504032',accent:'#e0aa68',glow:'214,152,81',motif:'cracks'},
    tombes:{base:'#44384d',accent:'#d8a9c5',glow:'183,132,171',motif:'tomb'},
    vitraux:{base:'#3b3c4d',accent:'#eed8ac',glow:'216,190,147',motif:'glass'},
    fracture:{base:'#354158',accent:'#edcf8d',glow:'208,176,104',motif:'fracture'}
  };
  const trapLookNames = Object.keys(trapLooks);
  const symbols = {
    '1': ['00100','01100','00100','00100','01110'],
    '2': ['01110','00010','01110','01000','01110'],
    '3': ['01110','00010','00110','00010','01110'],
    '?': ['01110','10001','00010','00100','00100'],
    '✦': ['00100','00100','11111','00100','00100']
  };

  function variant(x, y, chapter) {
    let v = Math.imul(x + 89, 1597334677) ^ Math.imul(y + 131, 3812015801) ^ Math.imul(chapter, 2798796415);
    v = Math.imul(v ^ (v >>> 16), 2246822507);
    return (v ^ (v >>> 13)) >>> 0;
  }

  function mix(a, b, amount) {
    const first = parseInt(a.slice(1), 16), second = parseInt(b.slice(1), 16);
    const rgb = [16, 8, 0].map(shift => {
      const low = (first >> shift) & 255, high = (second >> shift) & 255;
      return Math.round(low + (high - low) * amount).toString(16).padStart(2, '0');
    });
    return '#' + rgb.join('');
  }

  function rgbTriplet(hex) {
    return [1, 3, 5].map(index => parseInt(hex.slice(index, index + 2), 16)).join(',');
  }

  function rect(c, color, x, y, w, h) {
    c.fillStyle = color;
    c.fillRect(x, y, w, h);
  }

  function stone(c, x, y, w, h, base, edge) {
    rect(c, base, x + 1, y, w - 2, h);
    rect(c, base, x, y + 1, w, h - 2);
    rect(c, edge, x + 1, y, w - 2, 1);
    rect(c, mix(base, ink, .35), x + 1, y + h - 1, w - 2, 1);
  }

  function tuft(c, x, y, seed) {
    for (let i = 0; i < 4; i++) {
      const skew = ((seed >> (i * 2)) & 3) - 1, px = x + i * 2, height = 2 + ((seed >> (i + 3)) & 3);
      rect(c, moss[0], px, y - height, 2, height);
      rect(c, moss[1 + i % 2], px + skew, y - height, 2, 2);
      if (i % 2) rect(c, moss[3], px + skew, y - height, 1, 1);
    }
  }

  function wallTile(c, palette, mask, seed, greenery, chapter) {
    const top = mix(palette.wall, ink, .43);
    rect(c, mix(top, ink, .42), 0, 0, size, size);
    for (let y = -1; y < size; y += 8) {
      const offset = y % 3 ? -5 : 0;
      for (let x = offset; x < size; x += 11) {
        const value = variant(seed + x, y, 1) % 7;
        const base = mix(top, palette.edge, value * .037);
        stone(c, x, y, 10, 7, base, mix(base, palette.edge, .24));
        if (value > 3) rect(c, mix(base, ink, .45), x + 6, y + 3, 3, 1);
        if (value === 6) rect(c, mix(base, ink, .48), x + 6, y + 3, 1, 3);
      }
    }
    const edge = mix(palette.edge, top, .31);
    if (mask & 1) {
      rect(c, edge, 0, 0, size, 1);
      rect(c, top, 0, 1, size, 2);
    }
    if (mask & 2) {
      rect(c, ink, 22, 0, 2, size);
      rect(c, edge, 21, 0, 1, size);
    }
    if (mask & 8) {
      rect(c, ink, 0, 0, 1, size);
      rect(c, edge, 1, 0, 1, size);
    }
    if (mask & 4) {
      rect(c, edge, 0, 10, size, 2);
      rect(c, mix(top, palette.edge, .24), 0, 12, size, 3);
      rect(c, ink, 0, 15, size, 9);
      for (let x = 0; x < size; x += 8) {
        const base = mix(top, ink, .41 + ((seed + x) % 3) * .13);
        stone(c, x, 15, 7, 8, base, mix(base, top, .24));
        rect(c, ink, x + 5, 19, 1, 3);
      }
      rect(c, '#0b1219', 0, 23, size, 1);
      if (chapter === 1 && seed % 3 === 0) {
        for (const x of [3, 17]) {
          rect(c, '#111d25', x - 1, 2, 6, 19);
          rect(c, '#576762', x, 4, 4, 15);
          rect(c, '#7c8b76', x, 4, 1, 13);
          rect(c, '#313f41', x + 3, 5, 1, 14);
          rect(c, '#62736a', x - 1, 17, 6, 2);
        }
      }
      if (greenery && seed % 4 !== 0) {
        tuft(c, 2 + seed % 5, 14, seed * 293);
        if (seed % 3 === 0) {
          for (let i = 0; i < 8; i++) {
            const x = 10 + Math.floor(i / 3);
            rect(c, moss[i % 2], x, 14 + i, 1, 1);
            if (i % 3 === 0) rect(c, moss[2], x - 1, 14 + i, 3, 1);
          }
        }
      }
    }
    if (mask && seed % 4 === 1) {
      const tone = mix(palette.accent, top, .46);
      const x = mask & 8 ? 4 : 15, y = 5;
      rect(c, ink, x - 1, y - 1, 6, 6);
      if (chapter === 45) {
        rect(c, tone, x + 1, y, 2, 4);
        rect(c, palette.accent, x + 1, y, 1, 2);
      } else if (chapter === 40 || chapter === 41) {
        rect(c, tone, x, y + 1, 4, 2);
        rect(c, tone, x + 1, y, 2, 4);
      } else {
        rect(c, tone, x + 1, y, 2, 1);
        rect(c, tone, x, y + 1, 1, 2);
        rect(c, tone, x + 3, y + 1, 1, 2);
        rect(c, tone, x + 1, y + 3, 2, 1);
      }
    }
  }

  function floorTile(c, palette, mask, seed, greenery) {
    const base = mix(palette.floor, '#4b6061', .22);
    const edge = mix(base, palette.edge, .24);
    rect(c, mix(base, ink, .42), 0, 0, size, size);
    for (let y = -1; y < size; y += 6) {
      const offset = ((y + seed) % 4) * 2 - 6;
      for (let x = offset; x < size; x += 9) {
        const v = variant(x, y, seed) % 6;
        stone(c, x, y, 9, 6, mix(base, palette.detail, v * .08), mix(edge, base, v * .11));
        if (v === 3) rect(c, mix(base, ink, .29), x + 5, y + 3, 3, 1);
      }
    }
    if (mask & 1) {
      rect(c, mix(ink, base, .25), 0, 0, size, 2);
      rect(c, mix(ink, base, .54), 0, 2, size, 1);
    }
    if (mask & 2) rect(c, mix(ink, base, .48), 23, 0, 1, size);
    if (mask & 8) rect(c, mix(ink, base, .48), 0, 0, 1, size);
    if (mask & 4) rect(c, mix(ink, base, .28), 0, 23, size, 1);
    if (greenery && mask && seed % 3 !== 0) {
      const x = mask & 8 ? 1 : mask & 2 ? 16 : 5 + seed % 7;
      const y = mask & 1 ? 5 : mask & 4 ? 23 : 14;
      tuft(c, x, y, seed + 117);
    }
  }

  function open(world, x, y) {
    return x >= 0 && y >= 0 && x < world.w && y < world.h && world.tiles[y * world.w + x] === 0;
  }

  function microDetail(c, wall, palette, seed, mask, chapter) {
    // Small deterministic pixel accents: no per-frame randomness or world changes.
    const v = (n) => variant(seed * 17 + n * 13, chapter * 7 + n, 3);
    if (wall) {
      // Chipped masonry edges and narrow damp seams give the walls more depth.
      if (v(1) % 3 === 0) {
        const x = 3 + v(2) % 17, y = 4 + v(3) % 13;
        rect(c, mix(palette.wall, ink, .28), x, y, 3, 1);
        rect(c, mix(palette.edge, ink, .34), x + 1, y + 1, 2, 1);
      }
      if (v(4) % 4 === 0) {
        const x = 4 + v(5) % 16, y = 3 + v(6) % 7;
        rect(c, mix(palette.detail, ink, .22), x, y, 1, 4 + v(7) % 4);
        rect(c, mix(palette.edge, ink, .48), x + 1, y + 2, 1, 2);
      }
      if (mask & 4 && v(8) % 3 === 0) {
        const x = 3 + v(9) % 17;
        rect(c, mix(palette.edge, ink, .28), x, 12, 2, 1);
        rect(c, mix(palette.detail, ink, .18), x + 1, 13, 1, 2);
      }
    } else {
      // Hairline cracks, mineral flecks and worn tile corners, kept low contrast.
      if (v(10) % 3 === 0) {
        const x = 3 + v(11) % 16, y = 3 + v(12) % 15;
        const crack = mix(palette.detail, ink, .30);
        rect(c, crack, x, y, 1, 2);
        rect(c, crack, x + 1, y + 2, 2, 1);
        if (v(13) % 2) rect(c, crack, x + 2, y + 3, 1, 2);
      }
      if (v(14) % 2 === 0) {
        const x = 3 + v(15) % 18, y = 3 + v(16) % 18;
        rect(c, mix(palette.edge, palette.floor, .52), x, y, 1, 1);
        if (v(17) % 3 === 0) rect(c, mix(palette.detail, ink, .12), x + 1, y, 1, 1);
      }
      if ((mask & 1) && v(18) % 3 === 0) {
        rect(c, mix(palette.edge, palette.floor, .36), 3 + v(19) % 16, 2, 2, 1);
      }
      // Region-specific floor signatures: restrained 1–2 px motifs make the
      // fourteen large domains easier to distinguish without changing collision.
      const domain = chapter >= 37 ? chapter - 36 : 0;
      const motif = domain || ((chapter - 1) % 14) + 1;
      const px = 4 + v(20) % 15, py = 4 + v(21) % 15;
      const shade = mix(palette.detail, palette.floor, .34);
      if (motif === 1 || motif === 8) { // sentinels / city: ordered masonry marks
        if (v(22) % 3 === 0) { rect(c, shade, px, py, 4, 1); rect(c, shade, px + 3, py + 1, 1, 2); }
      } else if (motif === 2 || motif === 6) { // basalt forest / hanging gardens
        if (v(22) % 3 === 0) { rect(c, shade, px, py, 1, 4); rect(c, shade, px + 1, py + 2, 3, 1); }
      } else if (motif === 3 || motif === 7) { // mist sea / marsh reflections
        if (v(22) % 3 === 0) { rect(c, shade, px, py, 5, 1); rect(c, mix(shade, palette.edge, .28), px + 1, py + 2, 3, 1); }
      } else if (motif === 4 || motif === 12 || motif === 13) { // archives / necropolis / cathedral
        if (v(22) % 4 === 0) { rect(c, shade, px, py, 1, 5); rect(c, shade, px + 2, py + 1, 1, 3); rect(c, shade, px + 4, py, 1, 5); }
      } else if (motif === 5 || motif === 11) { // clock desert / golem realm
        if (v(22) % 3 === 0) { rect(c, shade, px, py, 3, 1); rect(c, shade, px + 1, py + 1, 1, 3); rect(c, shade, px + 3, py + 3, 2, 1); }
      } else if (motif === 9 || motif === 10 || motif === 14) { // crystals / fault / last threshold
        if (v(22) % 3 === 0) { rect(c, shade, px + 1, py, 1, 4); rect(c, mix(shade, palette.accent, .2), px, py + 2, 3, 1); }
      }
    }
  }

  function tile(c, x, y, z, wall, p, world) {
    let mask = 0;
    for (const [dx, dy, bit] of directions) {
      if (open(world, x + dx, y + dy) === wall) mask |= bit;
    }
    const seed = variant(x, y, world.n) % 23;
    const key = `${world.n}/${wall}/${mask}/${seed}`;
    let part = cache.get(key);
    if (!part) {
      part = document.createElement('canvas');
      part.width = part.height = size;
      const paint = part.getContext('2d');
      const greenery = [1,7,9,18,38,42,43].includes(world.n) || p.n === 'Pierre verte';
      if (wall) wallTile(paint, p, mask, seed, greenery, world.n);
      else floorTile(paint, p, mask, seed, greenery);
      microDetail(paint, wall, p, seed, mask, world.n);
      if (cache.size >= 700) cache.delete(cache.keys().next().value);
      cache.set(key, part);
    }
    c.drawImage(part, x * z, y * z, z, z);
  }

  function light(c, x, y, radius, rgb, strength) {
    const beam = c.createRadialGradient(x, y, 0, x, y, radius);
    beam.addColorStop(0, `rgba(${rgb},${strength})`);
    beam.addColorStop(.45, `rgba(${rgb},${strength * .48})`);
    beam.addColorStop(1, `rgba(${rgb},0)`);
    rect(c, beam, x - radius, y - radius, radius * 2, radius * 2);
  }

  function drawActor(c, actor, z, t, row, flip, reduced, backFacing = false) {
    const x = Math.round(actor.x * z), baseY = Math.round(actor.y * z);
    const scale = Math.max(1, Math.round(z / (row === 3 ? 21 : row > 1 ? 25 : 21)));
    let state = motion.get(actor);
    if (!state) {
      state = {x: actor.x, y: actor.y, t, steps: 0, active: -2};
      motion.set(actor, state);
    }
    const delta = Math.hypot(actor.x - state.x, actor.y - state.y);
    if (delta > .0001 && delta < .6) {
      state.steps += delta;
      state.active = t;
    }
    state.x = actor.x;
    state.y = actor.y;
    const moving = t - state.active < .12;
    const frame = reduced ? 0 : row === 2 || row === 4 || row === 5 ? Math.floor(t * 6) % 4
      : moving ? Math.floor(state.steps * 7) % 4 : 0;
    // A restrained two-pixel gait gives the player and companion a readable
    // walking rhythm without changing their collision footprint or map position.
    const gait = reduced ? 0 : moving && row < 2 ? [0, -1, 0, 1][frame] * scale
      : !moving && row < 2 && Math.sin(t * 1.7 + row * 1.1) > .82 ? -Math.max(1, Math.floor(scale / 2)) : 0;
    c.save();
    c.translate(x, baseY + gait);
    const shadowWidth = moving && !reduced ? [15, 13, 15, 13][frame] : 15;
    rect(c, '#080f19a8', -Math.floor(shadowWidth / 2) * scale, 4 * scale, shadowWidth * scale, 3 * scale);
    if (atl.complete && atl.naturalWidth) {
      if (flip) c.scale(-1, 1);
      c.drawImage(atl, frame * size, row * size, size, size,
        -size / 2 * scale, -16 * scale, size * scale, size * scale);
      if (backFacing && row < 2) {
        const hood = row === 0 ? '#547071' : '#896b87';
        const seam = row === 0 ? '#718b84' : '#b68aa7';
        rect(c, hood, -2 * scale, -12 * scale, 4 * scale, scale);
        rect(c, hood, -3 * scale, -11 * scale, 5 * scale, scale);
        rect(c, hood, -3 * scale, -10 * scale, 6 * scale, scale);
        rect(c, hood, -3 * scale, -9 * scale, 5 * scale, scale);
        rect(c, seam, -scale, -12 * scale, 2 * scale, scale);
      } else if (backFacing && row === 3) {
        rect(c, '#615b4e', -2 * scale, -8 * scale, 2 * scale, scale);
        rect(c, '#7c755e', -2 * scale, -10 * scale, 3 * scale, scale);
        rect(c, '#393d3a', scale, -7 * scale, scale, 2 * scale);
      }
    } else {
      rect(c, row === 0 ? '#e6bd7a' : '#efaabd', -3, -4, 6, 8);
    }
    c.restore();
  }

  const motion = new WeakMap();

  function person(c, actor, z, human, t, reduced) {
    const flip = Math.cos(actor.angle) < -.13;
    const color = human ? '255,174,85' : '239,128,160';
    const scale = Math.max(1, Math.round(z / 21));
    const breath = reduced ? .28 : .23 + (Math.sin(t * 1.8 + (human ? 0 : 1.1)) + 1) * .025;
    light(c, actor.x * z + (flip ? -7 : 7) * scale, actor.y * z, z * .95, color, breath);
    drawActor(c, actor, z, t, human ? 0 : 1, flip, reduced, Math.sin(actor.angle) < -.35);
  }

  function enemy(c, actor, z, t, reduced) {
    const row = actor.kind === 'golem' ? 3 : actor.kind === 'warden' ? 4 : actor.kind === 'patrol' ? 5 : 2;
    const lit = actor.alert > .4;
    light(c, actor.x * z, actor.y * z, z, lit ? '244,93,116' : '124,190,183', lit ? .29 : .1);
    drawActor(c, actor, z, t, row, Math.cos(actor.heading) < -.13, reduced,
      row === 3 && Math.sin(actor.heading) < -.35);
  }

  function local(c, x, y, z, draw) {
    const scale = Math.max(1, Math.round(z / 24));
    c.save();
    c.translate(Math.round(x), Math.round(y));
    c.scale(scale, scale);
    draw();
    c.restore();
  }

  function symbol(c, x, y, label, color, z, trace = false) {
    if (trace) light(c, x, y, z * .9, color === "#f0bb56" ? "247,181,74" : "247,175,102", .27);
    local(c, x, y, z, () => {
      rect(c, '#111b23', -7, -5, 14, 11);
      rect(c, '#17242d', -5, -7, 10, 15);
      rect(c, color + '80', -5, -7, 10, 1);
      rect(c, color + '56', -7, -4, 1, 8);
      rect(c, color + '56', 6, -4, 1, 8);
      rect(c, color + '55', -5, 7, 10, 1);
      if (trace) {
        rect(c, color + '88', -4, -3, 2, 3);
        rect(c, color + 'ac', -3, 1, 2, 2);
        rect(c, color + '88', 2, -1, 2, 3);
        rect(c, color + 'ac', 2, 3, 2, 2);
      }
      symbols[label].forEach((line, j) => {
        [...line].forEach((bit, i) => {
          if (bit === '1') rect(c, color, i - 2, j - 2, 1, 1);
        });
      });
    });
  }

  function challengeMarker(c, x, y, z, kind, index = 0, active = false, t = 0, reduced = false, direction = [0,-1], accentColor = null) {
    const colors = {roots:'#a7cf83','garden-roots':'#9fc777',folios:'#e1bd77','name-gallery':'#e1bd77','lantern-control':'#a9d88d','reflection-ripple':'#78d2cd','district-plan':'#dfc285','memory-fragment':'#b8a1d3','memory-tomb':'#a997bc','final-node':'#a9b7c8',gates:'#c8a46b','detour-return':'#c8a46b','double-courts':'#b99c81','lost-relays':'#e0a65f',golems:'#d3a65c',prism:'#9de5f1',copper:'#e4ae58',reflection:'#edc97f',vows:'#c9b1dc',currents:'#79dce5','current-reflection':'#719ca5','sentinel-focus':'#bd8270'};
    const color = accentColor || colors[kind] || '#e4bd70';
    if (active) light(c, x, y, z * 1.05, kind === 'roots' || kind === 'lantern-control' ? '132,194,119' : kind === 'reflection-ripple' ? '103,194,201' : kind === 'prism' ? rgbTriplet(color) : kind === 'vows' ? '174,146,205' : kind === 'currents' || kind === 'sentinel-focus' ? '121,220,229' : '221,174,92', .16);
    local(c, x, y, z, () => {
      rect(c, '#10191d', -7, -7, 14, 14);
      rect(c, active ? '#354532' : '#252b2d', -5, -5, 10, 10);
      if (kind === 'roots' || kind === 'garden-roots') {
        rect(c, active ? color : '#74836a', -1, -5, 2, 10);
        rect(c, active ? color : '#74836a', -4, -3, 3, 1); rect(c, active ? color : '#74836a', 1, -1, 3, 1);
        rect(c, active ? '#c3df98' : '#7c9272', -5, -5, 2, 2); rect(c, active ? '#c3df98' : '#7c9272', 3, -3, 2, 2);
      } else if (kind === 'folios' || kind === 'name-gallery') {
        rect(c, active ? color : '#8b7655', -4, -4, 3, 8); rect(c, active ? '#f0d49b' : '#9b8868', -1, -5, 5, 10);
        rect(c, '#584a39', -3, -2, 1, 1); rect(c, '#584a39', -3, 1, 1, 1); rect(c, '#765e3f', 1, -2, 2, 1); rect(c, '#765e3f', 1, 1, 2, 1);
      } else if (kind === 'clock') {
        rect(c, '#795b36', -7, -7, 14, 14); rect(c, active ? '#f0d594' : '#a98855', -5, -5, 10, 10); rect(c, '#29262a', -4, -4, 8, 8);
        rect(c, color, -1, -5, 2, 1); rect(c, color, 4, -1, 1, 2); rect(c, color, -1, 4, 2, 1); rect(c, color, -5, -1, 1, 2);
        const hands = [[0,-3],[3,0],[0,3],[-3,0]], [hx,hy] = hands[((index % 4) + 4) % 4], tx = Math.max(-4, Math.min(4, direction[0] * 3)), ty = Math.max(-4, Math.min(4, direction[1] * 3));
        if (hx) rect(c, '#fff1c1', hx < 0 ? hx : 0, 0, Math.abs(hx) || 1, 1); else rect(c, '#fff1c1', 0, hy < 0 ? hy : 0, 1, Math.abs(hy) || 1);
        if (tx) rect(c, active ? '#fff5cd' : color, tx < 0 ? tx : 0, 1, Math.abs(tx) || 1, 1); else rect(c, active ? '#fff5cd' : color, 1, ty < 0 ? ty : 0, 1, Math.abs(ty) || 1);
        rect(c, '#fff4cf', -1, -1, 2, 2);
      } else if (kind === 'clock-courtyard') {
        rect(c, '#57442f', -7, -6, 14, 12); rect(c, active ? '#e8c878' : '#a98855', -5, -5, 10, 2);
        rect(c, active ? '#15201b' : '#25252a', -4, -2, 8, 8); rect(c, active ? '#9cba75' : '#8c7650', -5, 5, 10, 2);
        rect(c, active ? '#edcf84' : '#b18a56', -2, -4, 4, 3); rect(c, '#27242a', -1, -3, 2, 2);
        if (!active) rect(c, '#e4be6c', -4, 1, 8, 1); else { rect(c, '#b4d48b', -3, 0, 6, 1); rect(c, '#d8e8a9', -1, 2, 2, 1); }
      } else if (kind === 'lantern-control') {
        rect(c, '#29362c', -6, -6, 12, 12); rect(c, active ? '#9dcc81' : '#7b7452', -4, -5, 8, 2); rect(c, active ? '#c5e99a' : '#a38c59', -3, -3, 6, 6);
        rect(c, '#34302a', -2, -2, 4, 4); rect(c, active ? '#ffe49a' : '#d3ad66', -1, -2, 2, 3); rect(c, active ? '#b3dd8d' : color, -1, 3, 2, 2);
        const rays = [[0,-1],[1,0],[0,1],[-1,0]], [dx,dy] = rays[((index % 4) + 4) % 4], tx = direction[0], ty = direction[1];
        if (dx) rect(c, '#fff0bf', dx > 0 ? 2 : -5, -1, 3, 1); else rect(c, '#fff0bf', -1, dy > 0 ? 2 : -5, 1, 3);
        if (tx) rect(c, active ? '#e4f4b7' : color, tx > 0 ? 3 : -6, 1, 3, 1); else rect(c, active ? '#e4f4b7' : color, 1, ty > 0 ? 3 : -6, 1, 3);
      } else if (kind === 'reflection-ripple') {
        rect(c, '#1c3035', -7, -5, 14, 10); rect(c, '#29434a', -5, -3, 10, 6);
        rect(c, color, -5, -2, 4, 1); rect(c, color, 1, 0, 4, 1); rect(c, active ? '#d9f1d0' : color, -3, 2, 6, 1);
        const dx = direction[0], dy = direction[1];
        if (dx > 0) { rect(c, '#eff0d1', 2, -1, 3, 1); rect(c, '#eff0d1', 4, -2, 1, 3); }
        else if (dx < 0) { rect(c, '#eff0d1', -5, -1, 3, 1); rect(c, '#eff0d1', -5, -2, 1, 3); }
        else if (dy > 0) { rect(c, '#eff0d1', -1, 2, 1, 3); rect(c, '#eff0d1', -2, 4, 3, 1); }
        else { rect(c, '#eff0d1', -1, -5, 1, 3); rect(c, '#eff0d1', -2, -5, 3, 1); }
      } else if (kind === 'memory-fragment') {
        rect(c, '#322d3e', -6, -6, 12, 12); rect(c, active ? '#d7c6ee' : '#9e8bb5', -3, -5, 6, 2);
        rect(c, active ? '#f1dfa5' : '#c4a9d8', -4, -3, 8, 6); rect(c, '#3b3548', -2, -1, 4, 2);
        rect(c, active ? '#fff0c0' : '#d6c8e4', -1, -2, 2, 4); rect(c, active ? '#e7c77e' : '#b7a0cf', -2, 3, 4, 1);
        rect(c, '#e4c981', -5, -2, 1, 2); rect(c, '#e4c981', 4, -2, 1, 2);
      } else if (kind === 'memory-tomb') {
        rect(c, '#37313f', -7, -6, 14, 12); rect(c, active ? '#bba8d1' : '#837990', -5, -5, 10, 9);
        rect(c, '#554c5f', -3, -4, 6, 7); rect(c, active ? '#f0d49c' : '#c2adcf', -2, -3, 4, 5);
        if (index === 0) { rect(c, active ? '#fff0b8' : '#d5bf87', -1, -4, 2, 3); rect(c, '#6c5e53', -2, -1, 4, 1); rect(c, '#6c5e53', -1, 0, 2, 2); }
        else if (index === 1) { rect(c, active ? '#fff0b8' : '#d5bf87', -2, -3, 1, 4); rect(c, active ? '#fff0b8' : '#d5bf87', 1, -3, 1, 4); rect(c, active ? '#fff0b8' : '#d5bf87', -1, 0, 2, 2); }
        else { rect(c, active ? '#fff0b8' : '#d5bf87', -1, 1, 2, 3); rect(c, active ? '#fff0b8' : '#d5bf87', -3, -1, 2, 1); rect(c, active ? '#fff0b8' : '#d5bf87', 1, -2, 2, 1); }
      } else if (kind === 'final-node') {
        rect(c, '#202b38', -6, -6, 12, 12); rect(c, active ? '#dce9d1' : '#8295a5', -4, -4, 8, 8); rect(c, '#293641', -3, -3, 6, 6);
        const rune = active ? '#ffe1a0' : '#b6c7d1';
        if (index === 0) { rect(c, rune, -3, -2, 2, 1); rect(c, rune, -2, -1, 1, 2); rect(c, rune, 0, 0, 2, 1); rect(c, rune, 1, 1, 1, 2); }
        else if (index === 1) { rect(c, rune, -1, -3, 2, 2); rect(c, rune, -2, -1, 4, 1); rect(c, rune, -1, 0, 2, 2); rect(c, rune, -2, 2, 4, 1); }
        else { rect(c, rune, -3, -2, 2, 1); rect(c, rune, -2, -1, 1, 2); rect(c, rune, 1, -2, 2, 1); rect(c, rune, 1, -1, 1, 2); rect(c, rune, -2, 2, 4, 1); }
      } else if (kind === 'district-plan') {
        rect(c, '#5a4935', -7, -6, 14, 12); rect(c, active ? '#e3d5a5' : '#c5b27f', -5, -5, 10, 9);
        rect(c, '#756344', 2, 4, 3, 2); rect(c, '#ede1b6', 3, 4, 2, 1);
        rect(c, active ? '#887047' : '#746347', -3, -3, 2, 2); rect(c, active ? '#887047' : '#746347', 0, 0, 2, 2); rect(c, active ? '#887047' : '#746347', 3, 2, 2, 2);
        rect(c, active ? '#b58949' : '#91805c', -1, -1, 1, 1); rect(c, active ? '#b58949' : '#91805c', 2, 1, 1, 1);
        rect(c, active ? '#f3d98e' : '#d9c482', -3, -4, 2, 1); rect(c, active ? '#f3d98e' : '#d9c482', 3, -1, 2, 1);
      } else if (kind === 'gates' || kind === 'detour-return') {
        rect(c, active ? color : '#81725e', -5, -4, 2, 9); rect(c, active ? color : '#81725e', 3, -4, 2, 9);
        rect(c, active ? '#edd69f' : '#887b6b', -3, -5, 6, 2); rect(c, '#14191c', -2, -2, 4, 7);
        if (kind === 'gates') {
          const rune = active ? '#f3dfad' : '#c2a876';
          if (index === 0) { rect(c, rune, -1, -1, 2, 1); rect(c, rune, -2, 0, 1, 2); rect(c, rune, -1, 2, 2, 1); rect(c, rune, 1, 1, 1, 1); }
          else if (index === 1) { rect(c, rune, -1, -1, 2, 1); rect(c, rune, 1, 0, 1, 2); rect(c, rune, -1, 2, 2, 1); rect(c, rune, -2, 0, 1, 1); }
          else { rect(c, rune, 0, -2, 1, 6); rect(c, rune, -1, -1, 1, 2); rect(c, rune, 1, -1, 1, 2); rect(c, active ? '#f8e3a0' : '#ddbc77', -1, 3, 3, 1); }
        } else rect(c, active ? '#f3dfad' : '#9a8d7b', -1, -1, 2, 1);
      } else if (kind === 'double-courts') {
        rect(c, active ? color : '#716b62', -5, -4, 3, 8); rect(c, active ? color : '#716b62', 2, -4, 3, 8);
        rect(c, active ? '#edcf9b' : '#8a8175', -3, -5, 6, 2); rect(c, active ? '#edcf9b' : '#8a8175', -3, 3, 6, 2);
      } else if (kind === 'vows') {
        const stone = active ? color : '#746a78';
        rect(c, '#c8b4d7', -6, -6, 12, 1); rect(c, '#c8b4d7', -6, 5, 12, 1);
        rect(c, '#c8b4d7', -6, -5, 1, 10); rect(c, '#c8b4d7', 5, -5, 1, 10);
        rect(c, stone, -4, -4, 9, 9);
        if (index % 2 === 0) { rect(c, active ? '#fff0c9' : '#b8a9bc', -1, -3, 2, 6); rect(c, active ? '#fff0c9' : '#b8a9bc', -3, 2, 6, 1); }
        else { rect(c, active ? '#fff0c9' : '#b8a9bc', -1, -4, 2, 8); rect(c, active ? '#fff0c9' : '#b8a9bc', -4, -1, 8, 2); rect(c, active ? '#fff0c9' : '#b8a9bc', -2, -2, 4, 4); }
      } else if (kind === 'prism') {
        rect(c, active ? color : '#648c9a', -1, -6, 2, 3); rect(c, active ? color : '#648c9a', -3, -3, 6, 2);
        rect(c, active ? '#d2fbff' : '#789eaa', -4, -1, 8, 3); rect(c, active ? color : '#648c9a', -2, 2, 4, 2); rect(c, active ? color : '#648c9a', -1, 4, 2, 2);
        const rays = [[0,-1],[1,0],[0,1],[-1,0]], [dx,dy] = rays[((index % 4) + 4) % 4];
        if (dx) rect(c, active ? '#fff2be' : color, dx > 0 ? 3 : -7, -1, 4, 2);
        else rect(c, active ? '#fff2be' : color, -1, dy > 0 ? 3 : -7, 2, 4);
        if (!reduced) rect(c, active ? '#d2fbff' : '#7797a1', -6 + Math.floor((Math.sin(t * 2 + index) + 1) * 2), -1, 2, 1);
      } else if (kind === 'lost-relays') {
        rect(c, '#70543a', -5, -1, 10, 2); rect(c, active ? '#ffe0a1' : color, -2, -5, 4, 10);
        rect(c, active ? '#fff1c1' : '#a67d49', -4, -4, 2, 2); rect(c, active ? '#fff1c1' : '#a67d49', 2, 2, 2, 2);
      } else if (kind === 'copper') {
        rect(c, '#735333', -5, -1, 10, 2); rect(c, active ? '#ffe0a1' : color, -1, -5, 2, 10);
        rect(c, active ? '#fff1c1' : '#b98b4b', -3, -3, 2, 2); rect(c, active ? '#fff1c1' : '#b98b4b', 1, 1, 2, 2);
      } else if (kind === 'golems') {
        rect(c, active ? '#85633d' : '#514a40', -5, -4, 10, 9); rect(c, active ? '#b88749' : '#756750', -4, -5, 8, 2);
        rect(c, active ? '#e6bd70' : '#a99772', -4, 3, 8, 2); rect(c, active ? '#f8d789' : '#b18e51', -2, -2, 2, 2); rect(c, active ? '#f8d789' : '#b18e51', 1, -2, 2, 2);
        rect(c, '#282722', -1, 0, 2, 2); rect(c, active ? '#f4d995' : '#b6955a', -1, 5, 2, 2);
      } else if (kind === 'reflection') {
        if (direction[0] < 0) { rect(c, color, -6, -1, 9, 2); rect(c, color, -6, -1, 2, 4); rect(c, color, -6, -3, 2, 4); }
        else if (direction[0] > 0) { rect(c, color, -3, -1, 9, 2); rect(c, color, 4, -3, 2, 4); rect(c, color, 4, -1, 2, 4); }
        else if (direction[1] < 0) { rect(c, color, -1, -6, 2, 9); rect(c, color, -3, -6, 4, 2); rect(c, color, -1, -6, 4, 2); }
        else { rect(c, color, -1, -3, 2, 9); rect(c, color, -3, 4, 4, 2); rect(c, color, -1, 4, 4, 2); }
      } else if (kind === 'sentinel-focus') {
        const glow = active ? '#8ce5cf' : '#bd8270';
        rect(c, '#3a2827', -5, -5, 10, 10); rect(c, '#765346', -4, -4, 8, 8);
        rect(c, glow, -6, -1, 4, 2); rect(c, glow, 2, -1, 4, 2); rect(c, glow, -1, -6, 2, 4);
        rect(c, '#1c2527', -2, -2, 4, 4); rect(c, active ? '#dcfff0' : '#e0b287', -1, -1, 2, 2);
      } else if (kind === 'currents') {
        const [fx, fy] = direction, rail = active ? '#8ee8e8' : '#4f8d94', plank = active ? '#baf4e8' : '#739ba0';
        if (fx) {
          rect(c, '#17282b', -7, -5, 14, 10); rect(c, rail, -7, -5, 14, 2); rect(c, rail, -7, 3, 14, 2);
          for (let px = -5; px <= 4; px += 3) rect(c, plank, px, -2, 2, 4);
          if (fx > 0) { rect(c, active ? '#effff0' : color, 0, -1, 3, 2); rect(c, active ? '#effff0' : color, 2, -3, 2, 2); rect(c, active ? '#effff0' : color, 2, 1, 2, 2); }
          else { rect(c, active ? '#effff0' : color, -3, -1, 3, 2); rect(c, active ? '#effff0' : color, -4, -3, 2, 2); rect(c, active ? '#effff0' : color, -4, 1, 2, 2); }
        } else {
          rect(c, '#17282b', -5, -7, 10, 14); rect(c, rail, -5, -7, 2, 14); rect(c, rail, 3, -7, 2, 14);
          for (let py = -5; py <= 4; py += 3) rect(c, plank, -2, py, 4, 2);
          if (fy > 0) { rect(c, active ? '#effff0' : color, -1, 0, 2, 3); rect(c, active ? '#effff0' : color, -3, 2, 2, 2); rect(c, active ? '#effff0' : color, 1, 2, 2, 2); }
          else { rect(c, active ? '#effff0' : color, -1, -3, 2, 3); rect(c, active ? '#effff0' : color, -3, -4, 2, 2); rect(c, active ? '#effff0' : color, 1, -4, 2, 2); }
        }
      } else if (kind === 'current-reflection') {
        const [fx, fy] = direction, ripple = active ? '#b9f0e8' : '#668f98';
        if (fx) { rect(c, ripple + '88', -6, -4, 12, 1); rect(c, ripple, -4, -1, 8, 1); rect(c, ripple + '88', -6, 2, 12, 1); rect(c, color, fx > 0 ? 3 : -4, -1, 2, 2); }
        else { rect(c, ripple + '88', -4, -6, 1, 12); rect(c, ripple, -1, -4, 1, 8); rect(c, ripple + '88', 2, -6, 1, 12); rect(c, color, -1, fy > 0 ? 3 : -4, 2, 2); }
        if (!reduced) rect(c, '#d2f6ef', -1 + Math.floor((Math.sin(t * 2 + index) + 1) * 2), -1, 2, 1);
      }
      rect(c, active ? color : '#6d6b5d', -1, 6, 2, 1);
      if (['roots','garden-roots','folios','name-gallery','gates','detour-return','double-courts','lost-relays','golems','currents'].includes(kind)) {
        const glyph = symbols[String(index + 1)];
        glyph.forEach((line, row) => [...line].forEach((bit, col) => {
          if (bit === '1') rect(c, active ? '#fff0bd' : '#b8aa8b', col - 2, row + 8, 1, 1);
        }));
      }
    });
  }

  function torch(c, x, y, z, t) {
    light(c, x, y, z, '251,164,79', .17);
    const flicker = Math.floor(t * 6) % 3;
    local(c, x, y, z, () => {
      rect(c, '#1c2429', -4, 3, 8, 5);
      rect(c, '#8f7660', -4, 3, 8, 1);
      rect(c, '#ae6552', -3, -3, 6, 6);
      rect(c, '#f6a35f', -2, -5, 4, 6);
      rect(c, '#ffd086', -1 + flicker - 1, -6 - flicker, 2, 6);
      rect(c, '#fff0bd', -1, -2, 2, 3);
    });
  }

  function gate(c, x, y, z, active) {
    local(c, x, y, z, () => {
      rect(c, '#101b23', -9, -5, 18, 14);
      rect(c, '#263844', -7, -8, 14, 3);
      rect(c, '#607276', -5, -10, 10, 2);
      rect(c, '#53676a', -9, -5, 3, 13);
      rect(c, '#53676a', 6, -5, 3, 13);
      rect(c, active ? '#d9a84f' : '#596275', -5, -6, 10, 1);
      rect(c, '#0e1822', -5, -3, 10, 10);
      rect(c, active ? '#ffe29a' : '#ad8799', -1, -3, 2, 7);
      rect(c, active ? '#f0bb56' : '#ad8799', -2, -1, 4, 2);
      rect(c, '#6b7370', -10, 8, 20, 2);
    });
  }

  function trapMotif(c, motif, color, dark, t, reduced) {
    if (motif === 'rays' || motif === 'bars') {
      for (let x = -6; x <= 6; x += 4) rect(c, dark ? '#51504c' : color, x, -5, 1, 10);
      if (motif === 'rays' && !reduced && Math.floor(t * 3) % 2 === 0) rect(c, color, -7, -1, 14, 1);
    } else if (motif === 'roots' || motif === 'thorns') {
      rect(c, dark ? '#4d5645' : color, -7, -1, 14, 2);
      rect(c, dark ? '#4d5645' : color, -4, -4, 2, 4); rect(c, dark ? '#4d5645' : color, 3, 0, 2, 4);
      rect(c, dark ? '#4d5645' : color, -2, -5, 2, 4); rect(c, dark ? '#4d5645' : color, 1, 1, 2, 4);
      if (motif === 'thorns') { rect(c, dark ? '#4d5645' : color, -6, -4, 2, 2); rect(c, dark ? '#4d5645' : color, 5, 2, 2, 2); }
    } else if (motif === 'ripples' || motif === 'bog') {
      for (let y = -5; y <= 3; y += 4) { rect(c, dark ? '#48524b' : color, -6 + (y % 3), y, 5, 1); rect(c, dark ? '#48524b' : color, 2, y + 1, 5, 1); }
      rect(c, dark ? '#59614d' : color, -1, -1, 2, 3);
    } else if (motif === 'shelves' || motif === 'tomb') {
      for (let y = -5; y <= 4; y += 4) rect(c, dark ? '#514a4d' : color, -6, y, 12, 1);
      if (motif === 'tomb') { rect(c, dark ? '#514a4d' : color, -2, -4, 4, 2); rect(c, dark ? '#514a4d' : color, -1, -2, 2, 6); }
    } else if (motif === 'gear') {
      rect(c, dark ? '#565047' : color, -1, -6, 2, 12); rect(c, dark ? '#565047' : color, -6, -1, 12, 2);
      rect(c, dark ? '#565047' : color, -4, -4, 2, 2); rect(c, dark ? '#565047' : color, 2, 2, 2, 2); rect(c, dark ? '#565047' : color, -1, -1, 2, 2);
    } else if (motif === 'crystal' || motif === 'fracture') {
      rect(c, dark ? '#596172' : color, -1, -6, 2, 3); rect(c, dark ? '#596172' : color, -3, -3, 6, 2); rect(c, dark ? '#596172' : color, -4, -1, 8, 3); rect(c, dark ? '#596172' : color, -2, 2, 4, 2); rect(c, dark ? '#596172' : color, -1, 4, 2, 2);
      if (motif === 'fracture') { rect(c, dark ? '#596172' : color, 4, -4, 1, 4); rect(c, dark ? '#596172' : color, 3, 0, 1, 4); }
    } else if (motif === 'rift') {
      rect(c, dark ? '#252c32' : '#111820', -2, -7, 4, 14); rect(c, dark ? '#667178' : color, -5, -6, 1, 12); rect(c, dark ? '#667178' : color, 4, -6, 1, 12);
    } else if (motif === 'cracks') {
      rect(c, dark ? '#554e43' : color, -1, -6, 2, 5); rect(c, dark ? '#554e43' : color, -4, -2, 4, 1); rect(c, dark ? '#554e43' : color, 1, -1, 4, 1); rect(c, dark ? '#554e43' : color, 1, 0, 1, 6);
    } else if (motif === 'glass') {
      rect(c, dark ? '#58535a' : color, -1, -6, 2, 12); rect(c, dark ? '#58535a' : color, -6, -1, 12, 2);
      rect(c, dark ? '#58535a' : color, -4, -4, 2, 2); rect(c, dark ? '#58535a' : color, 2, -4, 2, 2); rect(c, dark ? '#58535a' : color, -4, 2, 2, 2); rect(c, dark ? '#58535a' : color, 2, 2, 2, 2);
    }
  }

  function trap(c, x, y, z, spent, kind = 'fatal', warned = false, t = 0, reduced = false, style = '', palette = null) {
    const slow = kind === 'slow';
    const alarm = kind === 'alarm';
    const rift = kind === 'rift' || kind === 'bridge-fail';
    const bridgeSafe = kind === 'bridge-safe';
    const index = Number.parseInt(String(style).replace(/\D/g, ''), 10) || 0;
    const fallback = trapLooks[trapLookNames[index % trapLookNames.length]] || trapLooks.seismes;
    const isChapterStyle = /^stone-\d+$/.test(style) && palette;
    const accent = isChapterStyle ? palette.accent : fallback.accent;
    const glow = isChapterStyle ? [1,3,5].map(i => parseInt(palette.accent.slice(i,i+2),16)).join(',') : fallback.glow;
    const look = trapLooks[style] || (isChapterStyle ? {...fallback,base:mix(fallback.base,palette.detail,.28),accent,glow} : fallback);
    const color = slow ? '#e3be69' : alarm ? '#d1c3ee' : bridgeSafe ? '#e9c56d' : rift ? '#a6eaff' : look.accent;
    if (!spent) light(c, x, y, z * (warned ? 1.18 : rift ? 1.05 : .72), alarm ? '178,155,221' : bridgeSafe ? '220,174,79' : look.glow, warned ? .22 : rift ? .17 : .075);
    local(c, x, y, z, () => {
      rect(c, '#17181d', -9, -8, 18, 16);
      rect(c, spent ? '#242820' : look.base, -8, -7, 16, 14);
      rect(c, spent ? '#292d26' : '#20242a', -6, -5, 12, 10);
      trapMotif(c, look.motif, spent ? '#566046' : color, spent, t, reduced);
      if (rift && !spent) { rect(c, '#d8f5ff', -4, -7, 8, 1); rect(c, '#d8f5ff', -4, 6, 8, 1); rect(c, '#78cde6', -5, -5, 1, 10); rect(c, '#78cde6', 4, -5, 1, 10); }
      if (bridgeSafe && !spent) { rect(c, '#ffe8a6', -6, -3, 12, 1); rect(c, '#d5a94e', -4, 0, 8, 1); rect(c, '#ffe8a6', -6, 3, 12, 1); }
      if (alarm && !spent) { rect(c, color, -2, -2, 4, 4); rect(c, '#20242a', -1, -1, 2, 2); }
      if (warned && !spent && !reduced && Math.floor(t * 5) % 2 === 0) rect(c, '#ffe4a2', -8, -8, 16, 1);
      rect(c, spent ? '#576048' : color, -2, 5, 4, 1);
    });
  }

  function landmarks(c, z, world) {
    if (!world.rooms) return;
    const signs = {
      meeting: '#758f67',
      gallery: '#aac19c',
      crossing: '#6a8d90',
      reunion: '#b38e79',
      niche: '#71888e'
    };
    for (const room of world.rooms) {
      if (world.layout !== 'trace-pc' && !room.feature && !room.depth) continue;
      const x = (room.x + room.w / 2) * z;
      const y = (room.y + room.h / 2) * z;
      const source = signs[room.id];
      const color = world.layout === 'trace-pc' || !world.palette?.accent ? source : mix(source, world.palette.accent, .48);
      const detail = world.palette?.detail || '#354331';
      if (room.id === 'meeting') {
        light(c, x, y - z, z * 3.4, world.layout === 'trace-pc' || !world.palette?.accent ? '107,169,123' : rgbTriplet(world.palette.accent), .23);
      }
      local(c, x, y, z, () => {
        const radius = room.id === 'niche' ? 12 : 22;
        c.globalAlpha = .35;
        for (const side of [-1, 1]) {
          rect(c, color, -radius, side * radius, radius * 2 + 1, 1);
          rect(c, color, side * radius, -radius, 1, radius * 2 + 1);
          rect(c, color, side * radius - 2, -2, 5, 5);
        }
        rect(c, color, -1, -7, 2, 15);
        rect(c, color, -5, -1, 10, 2);
        if (room.id === 'gallery') {
          rect(c, color, -12, -4, 4, 8);
          rect(c, color, 8, -4, 4, 8);
        }
        if (room.feature && world.layout !== 'trace-pc') {
          const motif = world.maze?.topology;
          c.globalAlpha = .66;
          if (motif === 'plateau') {
            rect(c, color, -1, -8, 2, 16); rect(c, color, -8, -1, 16, 2);
            rect(c, color, -5, -5, 2, 2); rect(c, color, 3, -5, 2, 2); rect(c, color, -5, 3, 2, 2); rect(c, color, 3, 3, 2, 2);
          } else if (motif === 'grove') {
            rect(c, detail, -2, -8, 4, 15); rect(c, color, -7, -3, 6, 2); rect(c, color, 1, -6, 6, 2);
            rect(c, color, -6, -5, 3, 3); rect(c, color, 4, -8, 3, 3); rect(c, detail, -5, 5, 2, 4); rect(c, detail, 3, 4, 2, 5);
          } else if (motif === 'archipelago' || motif === 'marsh') {
            rect(c, color, -9, -5, 6, 1); rect(c, color, 3, -5, 6, 1); rect(c, color, -7, -7, 3, 2); rect(c, color, 4, -7, 3, 2);
            rect(c, detail, -10, 0, 20, 1); rect(c, color, -7, 3, 14, 1); rect(c, detail, -4, 6, 8, 1);
          } else if (motif === 'archive') {
            for (let row = -6; row <= 4; row += 5) { rect(c, detail, -9, row, 18, 2); rect(c, color, -7, row - 3, 3, 3); rect(c, color, -2, row - 4, 4, 4); rect(c, color, 4, row - 2, 3, 2); }
          } else if (motif === 'clockwork') {
            rect(c, color, -1, -8, 2, 16); rect(c, color, -8, -1, 16, 2); rect(c, detail, -5, -5, 3, 3); rect(c, detail, 2, -5, 3, 3); rect(c, detail, -5, 2, 3, 3); rect(c, detail, 2, 2, 3, 3);
            rect(c, color, -1, -4, 2, 5); rect(c, color, -1, -1, 5, 2);
          } else if (motif === 'terraces') {
            rect(c, detail, -9, 5, 18, 2); rect(c, color, -7, 2, 14, 2); rect(c, detail, -5, -1, 10, 2); rect(c, color, -3, -4, 6, 2); rect(c, detail, -1, -7, 2, 2);
          } else if (motif === 'districts') {
            rect(c, detail, -7, 7, 14, 2); rect(c, color, -6, -7, 2, 15); rect(c, color, 4, -7, 2, 15); rect(c, color, -4, -8, 8, 2); rect(c, detail, -3, -3, 6, 10);
          } else if (motif === 'crystal') {
            rect(c, detail, -1, -9, 2, 3); rect(c, color, -3, -6, 6, 2); rect(c, color, -5, -4, 10, 5); rect(c, detail, -3, 1, 6, 3); rect(c, color, -1, 4, 2, 4);
          } else if (motif === 'rift') {
            rect(c, detail, -2, -9, 4, 18); rect(c, color, -5, -7, 2, 6); rect(c, color, 3, 1, 2, 6); rect(c, color, -7, -1, 3, 2); rect(c, color, 4, 3, 3, 2);
          } else if (motif === 'fortress') {
            rect(c, detail, -8, -8, 16, 2); rect(c, detail, -8, 6, 16, 2); rect(c, color, -8, -6, 2, 12); rect(c, color, 6, -6, 2, 12);
            rect(c, color, -4, -4, 8, 2); rect(c, detail, -4, 2, 8, 2); rect(c, color, -1, -2, 2, 6);
          } else if (motif === 'catacombs') {
            rect(c, detail, -7, -6, 14, 2); rect(c, color, -6, -4, 2, 9); rect(c, color, 4, -4, 2, 9); rect(c, detail, -4, 4, 8, 2);
            rect(c, color, -1, -2, 2, 5); rect(c, color, -3, 0, 6, 2);
          } else if (motif === 'nave') {
            rect(c, detail, -7, -8, 14, 2); rect(c, color, -6, -6, 2, 14); rect(c, color, 4, -6, 2, 14); rect(c, detail, -3, -5, 6, 10);
            rect(c, color, -1, -4, 2, 8); rect(c, color, -3, -1, 6, 2);
          } else if (motif === 'convergence') {
            rect(c, color, -8, -7, 13, 2); rect(c, color, 5, -5, 2, 11); rect(c, detail, -5, 4, 10, 2); rect(c, detail, -5, -3, 2, 7); rect(c, color, -2, -3, 7, 2); rect(c, color, 1, -1, 2, 3);
          } else {
            rect(c, detail, -7, -1, 14, 2); rect(c, color, -1, -7, 2, 14);
          }
        }
        if (room.depth) {
          const stoneTop = world.palette?.edge || '#8c9b73';
          const stoneFace = mix(world.palette?.wall || '#586442', ink, .46);
          const stoneSide = mix(world.palette?.wall || '#586442', ink, .24);
          const stairTop = mix(world.palette?.floor || '#354331', stoneTop, .34);
          const rune = world.palette?.accent || '#d4b367';
          c.globalAlpha = .46;
          rect(c, '#080e12', -19, 8, 38, 5);
          c.globalAlpha = .92;
          const tiers = [[-14, 5, 28], [-12, 1, 24], [-10, -3, 20], [-8, -7, 16], [-6, -11, 12]];
          for (let i = 0; i < tiers.length; i++) {
            const [x, y, width] = tiers[i];
            rect(c, '#0a1115', x + 3, y + 5, width, 5);
            rect(c, stoneFace, x, y + 2, width, 5);
            rect(c, stoneSide, x + width - 4, y, 4, 7);
            rect(c, stairTop, x, y - 1, width - 2, 3);
            rect(c, stoneTop, x + 1, y - 1, width - 5, 1);
            rect(c, mix(stairTop, ink, .32), x + 4, y + 1, Math.max(2, width - 12), 1);
            if (i % 2 === 0) rect(c, rune, x + 3, y, 3, 1);
          }
          rect(c, stoneSide, -4, -19, 3, 10);
          rect(c, stoneFace, 3, -19, 3, 10);
          rect(c, stoneTop, -5, -20, 10, 2);
          rect(c, rune, -1, -17, 2, 4);
          rect(c, mix(rune, ink, .25), -13, 10, 26, 1);
        }
      });
    }
    const steps = [[9.7,18.8], [10.1,18.55], [10.6,18.35], [11,18.05],
      [11.5,17.9], [11.9,17.61], [12.4,17.46], [12.8,17.25],
      [13.3,17.05], [13.8,16.77], [14.2,16.3], [14.65,15.8]];
    if (world.layout === 'trace-pc') for (let i = 0; i < steps.length; i++) {
      const [x,y] = steps[i];
      if (!open(world, Math.floor(x), Math.floor(y))) continue;
      local(c, x * z, y * z, z, () => {
        rect(c, '#87ab82', -1, -1, 2, 2);
        rect(c, '#a7b288', 1, -1, 1, 1);
      });
    }
    if (world.decoy) {
      const [x,y] = world.decoy;
      symbol(c, (x + .5) * z, (y + .5) * z, '✦', '#a18eac', z);
    }
  }

  function afterFog(c, {player, other, cam, z, w, h, timer, reduced, chapter = 1, palette = null}) {
    const x = w / 2 + (player.x - cam.x) * z;
    const y = h / 2 + (player.y - cam.y) * z;
    const ox = w / 2 + (other.x - cam.x) * z;
    const oy = h / 2 + (other.y - cam.y) * z;
    c.save();
    c.globalCompositeOperation = 'screen';
    light(c, x, y, z * 2.9, '247,174,95', .15);
    light(c, ox, oy, z * 1.7, '188,105,145', .10);
    for (let i = 0; i < 13; i++) {
      const phase = i * 2.399 + (reduced ? 0 : timer * .12);
      const distance = z * (.25 + i * .155);
      const px = x + Math.cos(phase) * distance, py = y + Math.sin(phase) * distance * .74;
      rect(c, i % 4 ? '#d6a96d4d' : '#bde7bd63', Math.round(px / 2) * 2, Math.round(py / 2) * 2, 2, 2);
    }
    c.restore();
    // Chapter atmosphere: palette-matched, deterministic pixel motes. They are
    // presentation-only and never affect play.
    const regions = [
      ['185,211,151', '118,169,137'], // overgrown stone
      ['211,185,143', '145,159,164'], // dust and old masonry
      ['142,193,218', '183,211,224'], // cold underground
      ['183,143,205', '126,115,177'], // fractured / arcane
      ['238,174,105', '202,128,91'],  // ember / machinery
      ['218,126,139', '157,105,143']  // hostile presence
    ];
    const region = chapter <= 8 ? 0 : chapter <= 16 ? 1 : chapter <= 24 ? 2 : chapter <= 32 ? 3 : chapter <= 40 ? 4 : 5;
    const motes = palette ? [rgbTriplet(palette.accent), rgbTriplet(palette.edge)] : regions[region];
    c.save();
    c.globalCompositeOperation = 'screen';
    for (let i = 0; i < 18; i++) {
      const seed = (i * 73 + chapter * 29) % 997;
      const baseX = (seed * 37.17) % Math.max(1, w);
      const baseY = (seed * 19.73) % Math.max(1, h);
      const drift = reduced ? 0 : timer * (2.2 + (i % 4) * .7);
      const px = (baseX + Math.sin(i * 1.7 + timer * (reduced ? 0 : .16)) * 7 + w) % w;
      const py = (baseY - drift + h * 2) % h;
      const alpha = .12 + (i % 3) * .035;
      c.globalAlpha = alpha;
      c.fillStyle = `rgba(${motes[i % 2]},${alpha})`;
      const pixel = i % 5 === 0 ? 2 : 1;
      c.fillRect(Math.round(px / 2) * 2, Math.round(py / 2) * 2, pixel, pixel);
    }
    c.restore();
  }

  function attract(c, w, h) {
    rect(c, '#0c151b', 0, 0, w, h);
  }

  root.LAJPixelArt = {tile, person, enemy, afterFog, attract, symbol, challengeMarker, torch, gate, trap, landmarks};
})(window);
