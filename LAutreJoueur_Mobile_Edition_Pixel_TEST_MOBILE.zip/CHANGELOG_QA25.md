# QA25 — Finition de l'écran de pause et des confirmations

## Base
Archive QA24 — sélection des chapitres.

## Périmètre
- Recomposition visuelle CSS du panneau de pause : hiérarchie, décor, espacement, icônes et ordre de lecture.
- Boutons reprendre, carte, réglages, recommencer et menu principal conservent leurs identifiants et leur comportement existant.
- Fenêtre de confirmation : sceau, lisibilité, boutons annuler/confirmer, focus visible et adaptation mobile.
- Adaptations spécifiques aux écrans étroits et aux mobiles en paysage de faible hauteur.
- Cache service worker : r26.

## Fichiers modifiés
- `ui-relic.css`
- `sw.js`

## Fichier ajouté
- `CHANGELOG_QA25.md`

## Préservation
Aucun changement dans `game.js`, `content.js`, les données de chapitres, les énigmes, les sauvegardes ou l'IA de L'Autre. Aucun identifiant de commande HTML n'a été modifié.

## Contrôles à effectuer
Vérifier la syntaxe CSS/JavaScript, l'intégrité de l'archive et les ressources référencées. Les essais réels sur Safari iOS, Android et ordinateur restent nécessaires ; la validation statique ne certifie pas le rendu sur appareils.
