# QA58 — La Cité des Portes, la Nécropole et le Dernier Seuil

- Chapitre 44 : le plan de quartier doit être lu avant les trois herses. Chaque porte porte un signe pixel art distinct ; le plan indique l’ordre spirale, aiguille, croissant. L’état du plan et les ouvertures sont reportés dans les repères, le contexte proche et la carte.
- Chapitre 48 : trois fragments racontés par L’Autre désignent trois tombes. Le joueur écoute tous les fragments, associe les tombes dans l’ordre, puis retrouve le souvenir caché. Les lectures de fragments et l’avancement sont sauvegardés.
- Chapitre 50 : trois signes de synthèse — trace, lanterne, serment — reçoivent un ordre propre à la carte. Le journal indique l’ordre ; les trois signes, l’exploration d’au moins la moitié des salles et la présence proche de L’Autre ouvrent les sceaux. Le choix final ensemble ou seul demeure.
- Les chapitres 44, 48 et 50 passent à `mapVersion` 10. Le cache hors ligne passe à `laj-mobile-pixel-r67`.
- Ajout de repères pixel art dédiés au plan, aux portes-signatures, aux fragments, aux tombes et aux signes finaux.

## Vérifications

- Cette passe a modifié le code et les documents de suivi. Aucun test automatisé, parcours complet ou essai sur téléphone n’a été exécuté ; l’implémentation des chapitres 44, 48 et 50 reste à vérifier en jeu.
- À vérifier ensuite : syntaxe et lancement du jeu, placement et accessibilité des repères sur les cartes générées, sauvegarde/reprise, réussite et erreurs de chaque énigme, puis essais tactiles sur iPhone et Android.
- Le parcours intégral des cinquante chapitres, l’équilibrage et la préparation de publication restent à faire.
