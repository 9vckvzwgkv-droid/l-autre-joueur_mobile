# QA9 — Animation de déplacement des personnages

## Modifications
- Ajout d'un léger cycle de déplacement vertical pour le joueur et L'Autre pendant la marche.
- Variation synchronisée de l'ombre au sol pour renforcer la perception du pas sur les petits écrans.
- L'animation est désactivée lorsque la préférence de réduction des mouvements est active.
- Les ennemis de type patrouille continuent leur cycle d'animation dédié.
- Cache PWA incrémenté de r10 à r11.

## Préservation
Aucun changement de coordonnées de jeu, collision, vitesse, navigation, IA, détection, dégâts, énigme, progression, sauvegarde, carte ou audio. Les versions PC et les archives QA précédentes restent intactes.

## Limites
Cette passe améliore uniquement le rendu visuel du déplacement. Elle ne constitue pas une validation artistique finale ni un test sur appareil physique.
