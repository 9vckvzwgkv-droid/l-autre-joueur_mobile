/* Offline shell + byte-range support for AAC playback on iOS/Safari. */
const CACHE='laj-mobile-pixel-r68';
const FILES=['./','./index.html','./style.css','./visual-pixel.css','./ui-modern.css','./ui-relic.css','./ui-polish.css','./ui-atelier.css','./ui-unity.css','./ui-pixel-finish.css','./ui-motion.css','./ui-hud-pixel.css','./ui-world-polish.css','./art/ui/stone-pixel-tile.png','./art/ui/slab-grain.png','./art/ui/vine-corner.png','./art/ui/gold-rune-divider.png','./content.js','./visual-pixel.js','./companion-ai.js','./art/seuil-pixel.png','./art/sprites-pixel.png','./game.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./audio/menu.m4a','./audio/exploration.m4a','./audio/tension.m4a'];
const shell = new URL('./index.html', self.location.href).href;
const assets = new Set(FILES.map(file => new URL(file,self.location.href).href));
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('laj-mobile-pixel-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 if(req.mode==='navigate' && assets.has(new URL(req.url).origin + new URL(req.url).pathname)){
  event.respondWith(fetch(req).catch(()=>caches.match(shell)));
  return;
 }
 if(!assets.has(req.url))return;
 event.respondWith((async()=>{
  const cached=await caches.match(req.url);
  const range=req.headers.get('Range');
  if(cached&&range){
   const match=/^bytes=(\d+)-(\d*)$/i.exec(range);
   if(match){
    const bytes=await cached.arrayBuffer(),size=bytes.byteLength;
    const start=Number(match[1]),end=match[2]?Math.min(size-1,Number(match[2])):size-1;
    if(start>=size||end<start)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});
    const headers=new Headers(cached.headers);
    headers.set('Content-Range',`bytes ${start}-${end}/${size}`);
    headers.set('Accept-Ranges','bytes');
    headers.set('Content-Length',String(end-start+1));
    return new Response(bytes.slice(start,end+1),{status:206,statusText:'Partial Content',headers});
   }
  }
  if(cached)return cached;
  const response=await fetch(req);
  if(response.ok&&!range){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(req,copy)).catch(()=>{});}
  return response;
 })());
});
