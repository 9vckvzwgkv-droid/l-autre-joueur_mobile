# QA37 — Parcours, énigmes et pièges thématiques

## Édition mobile
- La génération consomme maintenant le profil propre à chaque chapitre : nombre de salles, silhouette, largeur des passages, connexions, boucles et style de pièges.
- Les quatorze derniers chapitres utilisent quatorze graphes distincts : plateau radial, bosquet, archipel, travées d’archives, couronnes d’horlogerie, terrasses, marais tressé, cité ouverte, hub cristallin, faille à ponts, enceinte, catacombes, nef et convergence en spirale.
- Les chapitres 2 à 50 ont une combinaison d’ordre des sceaux et de gestes propre. La carte mobile dédiée du chapitre 1 (« Le Premier Seuil ») reste intacte.
- Les pièges ont des motifs pixel adaptés à leur thème. Trois effets existent : mortel, ralentissant et sonore ; l’alarme met les ennemis proches en alerte.
- Les changements de plans et de placement sont enregistrés en version de carte 5. Une sauvegarde située au milieu d’un ancien plan reprend au départ du chapitre, en gardant ses sceaux et ses souvenirs.
- Le cache hors ligne PWA passe à `laj-mobile-pixel-r40`.

## Vérifications ciblées
- Les trois scripts modifiés passent l’analyse syntaxique.
- 50/50 combinaisons d’ordre et de gestes et 50/50 cartes physiques différentes.
- Aucun objectif ou ennemi n’est posé dans un mur ; toutes les cases praticables sont reliées au départ.
- Les quatorze domaines finaux ont chacun une topologie et un style de piège différents.
- Le chapitre 1 conserve sa disposition, son départ, ses runes, sa sortie et ses pièges.

Ces vérifications portent sur les données et le code. Elles ne remplacent pas des parties complètes sur iPhone et Android.

## Limites connues
- Le paquet PC fourni est une application Unity compilée, sans le document de conception des 50 niveaux. Il confirme des repères comme « Les Traces », les fausses pistes, les portes et les chemins sûrs, mais pas les plans complets de campagne.
- Les nouvelles cartes sont générées par profils et graines, pas dessinées et jouées à la main un par un. Des familles procédurales se répètent dans les chapitres intermédiaires ; 50 grilles différentes ne signifient pas encore 50 structures ou énigmes entièrement distinctes et équilibrées.
- La proposition [CONCEPTION_LABYRINTHES_50_PROPOSITION.md](CONCEPTION_LABYRINTHES_50_PROPOSITION.md) reste à valider avec le scénario PC. Le paquet fourni ne contient pas les plans de niveaux complets.
- L’équilibrage tactile, les performances sur appareils réels, l’accessibilité et la préparation de publication restent à faire.
