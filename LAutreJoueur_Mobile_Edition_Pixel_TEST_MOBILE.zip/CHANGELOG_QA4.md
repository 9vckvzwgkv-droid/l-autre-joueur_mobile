# L’Autre Joueur — QA4

## Amélioration visuelle
- Augmentation du nombre de variantes déterministes des tuiles de décor de 9 à 23.
- Les murs et sols présentent moins de répétitions visibles à l'échelle d'un labyrinthe.
- Les détails restent calculés une seule fois puis mis en cache : aucune génération aléatoire n'est ajoutée à chaque image.
- Géométrie, collisions, objectifs, énigmes, ennemis, IA, progression et sauvegardes inchangés.

## PWA
- Cache du service worker passé de `r7` à `r8` pour forcer le renouvellement du rendu sur les installations existantes.

## Vérifications
- 50 chapitres générés et parcourus par un contrôle de connectivité : sortie, trois runes et secret accessibles dans les 50 cartes.
- 16 tests navigateur : réussis, aucun échec, aucune exception JavaScript.
- 6 tests de contrôles : réussis, aucun échec, aucune exception JavaScript.
- Syntaxe JavaScript contrôlée avec Node.js.
- Archive ZIP contrôlée.

## Limites
- Tests navigateur simulés, pas une validation sur iPhone physique.
- Pas de test HTTP/hébergement ni d'installation iOS réelle dans cette passe.
- Les 50 chapitres sont vérifiés pour la connectivité des objectifs ; cela ne remplace pas une validation manuelle de leur qualité ludique et de leur difficulté.
