# QA24 — Finition de la sélection des chapitres

## Périmètre
Cette étape affine uniquement l'écran « Les 50 chapitres ». Aucun code de gameplay, contenu narratif, progression, sauvegarde, IA, audio ou commande n'a été modifié.

## Changements visuels
- Cartes de chapitres plus aérées, avec numéros et titres mieux hiérarchisés.
- Chapitre en cours plus visible, avec repère « EN COURS ».
- Chapitres verrouillés distingués plus clairement sans modifier leur état réel.
- Séparation visuelle entre les chapitres 1–36 et les grands domaines 37–50.
- États de focus clavier plus lisibles et retour visuel au survol.
- Adaptation dédiée aux petits écrans.

## Cache
Service worker : `laj-mobile-pixel-r25`.

## Vérifications
- Le rendu est fondé sur les éléments réellement générés par `renderChapters()` : `.chapter-card`, `.current`, `.locked`.
- Les scripts de gameplay ne sont pas modifiés.
- Vérifications de syntaxe CSS/JS et intégrité ZIP effectuées lors de la préparation de l'archive.
- Validation visuelle réelle sur iPhone Safari, Android et ordinateur encore nécessaire.
