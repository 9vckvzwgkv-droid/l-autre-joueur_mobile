# QA33 — Dangers différenciés dans les grands domaines

## Chapitres 37 à 50
- Chaque domaine génère 35 pièges : 20 dalles mortelles et 15 runes engourdissantes.
- Les dangers ont deux silhouettes et deux couleurs distinctes. La lumière des pièges s'intensifie à proximité ; le guide contextuel annonce leur type avant contact.
- Une rune engourdissante ralentit brièvement le joueur et se désactive après activation.
- Une dalle mortelle augmente le compteur de captures et recommence le chapitre au seuil, en remettant à zéro les sceaux et l'exploration locale. La dalle qui a provoqué la reprise reste neutralisée.
- Les pièges des chapitres 1 à 36 conservent leur reprise au dernier point sûr.
- Les fragments déjà consignés restent acquis lors d'une reprise ou d'un retour dans leur chapitre.
- Le guide de jeu décrit les conséquences selon le type de chapitre.

## Sauvegarde et hors ligne
- L'état des pièges déjà déclenchés est conservé dans la sauvegarde existante ; les nouveaux pièges sont ajoutés sans décaler les 16 premiers emplacements des domaines.
- Le cache hors ligne passe à `laj-mobile-pixel-r34`.

## Validation
- Modification non prévisualisée dans un navigateur ou sur appareil. Les règles de reprise doivent encore être jouées et équilibrées sur téléphone et ordinateur.
