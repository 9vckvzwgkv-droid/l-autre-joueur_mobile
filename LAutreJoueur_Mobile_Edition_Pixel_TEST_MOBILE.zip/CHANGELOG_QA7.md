# QA7 — Atmosphères pixelisées par région

## Changements
- Ajout d'un voile de particules pixelisées discrètes dans le rendu après brouillard.
- Six palettes atmosphériques sélectionnées selon les régions de chapitres : végétation, poussière, froid, arcanes, braises/mécanismes et présence hostile.
- Mouvement déterministe et léger, sans aléatoire par image ; mode mouvement réduit : particules immobiles.
- Transmission du numéro de chapitre au rendu pour adapter l'atmosphère.
- Incrément de cache du service worker de r8 à r9 pour éviter de conserver l'ancien rendu après mise à jour.

## Périmètre protégé
Aucune modification des cartes, positions, collisions, règles, IA de L'Autre, ennemis, puzzles, pièges, progression, sauvegardes ou audio. Les particules sont purement visuelles.

## Vérifications effectuées
- Syntaxe JavaScript : `visual-pixel.js`, `game.js`, `sw.js` — réussie.
- Pré-vol QA5 : 10/10 contrôles statiques réussis.
- Audit structurel des cartes : 700/700 assertions réussies sur les 50 chapitres.
- Aucun test physique iPhone/Android ni validation artistique utilisateur réalisé dans cette passe.
