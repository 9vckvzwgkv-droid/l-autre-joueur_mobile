# QA20 — Harmonisation et accessibilité des menus

## Travail réalisé
- Harmonisation des contrastes secondaires, de la typographie des panneaux et des états de focus clavier.
- Ajout d'un indicateur de focus visible et cohérent sur les boutons, réglages et commandes personnalisables.
- Affichage d'une barre de défilement discrète mais repérable dans les panneaux qui contiennent beaucoup de contenu.
- Ajustements de lisibilité et de largeur sur petits écrans.
- Ajout du déplacement des quatre commandes de l'atelier tactile au clavier : flèches pour déplacer d'un pas, Maj + flèches pour cinq pas. Chaque déplacement est enregistré via le mécanisme de sauvegarde déjà existant.
- États désactivés des boutons rendus visuellement explicites.

## Préservation
- Aucun changement volontaire aux chapitres, labyrinthes, énigmes, pièges, progression, IA de L'Autre, audio ou logique de sauvegarde du jeu.
- Les déplacements au clavier concernent uniquement les quatre poignées de l'atelier de disposition. Le déplacement en jeu n'est pas modifié.
- Cache du service worker : `laj-mobile-pixel-r21`.

## Fichiers modifiés
- `index.html` : sémantique et accès clavier des poignées de l'atelier.
- `game.js` : déplacement clavier des commandes dans l'atelier uniquement.
- `ui-modern.css` : cohérence, focus, lisibilité et défilement des panneaux.
- `sw.js` : version du cache.
- `CHANGELOG_QA20.md` : présent journal.

## Vérifications
- Syntaxe JavaScript contrôlée avec Node.js.
- Intégrité de l'archive ZIP contrôlée.
- Contrôle automatisé du contenu et du changement de cache.
- Les tests réels sur iPhone/Safari, Android et ordinateur restent indispensables avant validation commerciale.
