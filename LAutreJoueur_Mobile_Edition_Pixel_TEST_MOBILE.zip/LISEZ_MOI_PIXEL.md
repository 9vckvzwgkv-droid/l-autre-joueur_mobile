# L’Autre Joueur — Édition Pixel

Le jeu fonctionne en portrait comme en paysage. Sur téléphone, utilise le joystick à gauche, **Agir**, **L’Autre** et **Courir** à droite. Sur ordinateur, utilise les flèches ou ZQSD, E pour agir, F pour appeler le compagnon, M pour la carte et Échap pour faire une pause.

## Lancer la copie locale

Sur Mac, désarchive le fichier, ouvre le dossier dans Terminal, puis lance :

```bash
python3 -m http.server 8080
```

Ouvre ensuite http://localhost:8080/ dans le navigateur. Avec un hébergement HTTPS, le manifeste et le service worker permettent d’ajouter le jeu à l’écran d’accueil et de mettre ses ressources en cache après le premier chargement complet.

## Tester sur un téléphone avec le même Wi-Fi

1. Décompresse cette archive sur le Mac et ouvre le dossier du jeu dans Terminal.
2. Lance `python3 -m http.server 8080 --bind 0.0.0.0`.
3. Sur le Mac, ouvre les détails de ta connexion Wi-Fi dans Réglages Système et relève l’adresse IP locale.
4. Connecte le téléphone au même réseau Wi-Fi, puis ouvre `http://ADRESSE-IP-DU-MAC:8080/` dans Safari ou Chrome (remplace le texte par l’adresse relevée).
5. Pour arrêter le serveur, reviens dans Terminal et appuie sur Ctrl+C.

Cette méthode permet de jouer et d’éprouver les commandes sur téléphone. Le mode installation et le cache hors ligne exigent un site publié en HTTPS ; ils ne sont pas activés avec cette adresse locale.

## Contenu

- Le Premier Seuil reprend la géométrie 48 × 36 du chapitre PC **Trace**. Les positions des trois empreintes, de la niche et de la sortie correspondent au plan PC. L’interaction tactile, les pièges et le choix à la sortie utilisent les règles de la campagne mobile.
- Les 49 cartes suivantes reprennent les noms, thèmes et données narratives de la Mobile V3.2, avec des salles ouvertes, des passages larges et une architecture propre à chaque chapitre. Les chapitres 2 à 36 ont aussi une épreuve jouable et une famille de pièges dédiée ; les chapitres 37 à 50 gardent leurs quatorze grands domaines et leurs conditions de résolution particulières. Certaines salles proposent un changement de cadrage 2.5D.
- Les trois sceaux, le souvenir et la sortie se trouvent dans des salles distinctes pour encourager l’exploration de plusieurs espaces.
- Cette édition reste conçue d’abord pour téléphone, avec commandes tactiles réglables. Les menus, le HUD, la carte et les commandes utilisent la même direction artistique de pierre sombre, mousse et runes ambrées.
- L’Autre garde une mémoire locale de tes déplacements, des dangers rencontrés, des appels et des salles explorées. Cette mémoire influence légèrement son suivi et ses avertissements, et apparaît dans le carnet ; les sauvegardes déjà créées restent compatibles.
- Le chapitre 1 conserve sa géométrie PC spéciale ; les cartes suivantes gardent la campagne mobile, ses 50 chapitres, ses sceaux, ses pièges, ses ennemis et L’Autre.
- Le document [CONCEPTION_LABYRINTHES_50_PROPOSITION.md](CONCEPTION_LABYRINTHES_50_PROPOSITION.md) garde la référence de conception validée pour les 50 cartes et énigmes. Ce n’est pas la fiche PC originale : le ZIP PC fourni ne contenait pas les plans détaillés de la campagne.
- Les trois musiques fournies sont incluses. La sauvegarde de cette édition est isolée. Une sauvegarde mobile V3.2 est importable dans les Réglages. Les chapitres débloqués, choix et souvenirs sont conservés à l’import. Si tu reprends au milieu du chapitre 1 de la V3.2, sa nouvelle carte redémarre à l’entrée. Tu retrouveras ta position lors des prochaines ouvertures de cette édition.
- Les sprites transparents sont dans `art/sprites-pixel.png`, avec quatre images de 24 × 24 pixels par ligne. De haut en bas, le voyageur, L’Autre, le drone, le golem et le Gardien.

## Installer l’application sur iPhone

Cette édition est préparée comme une application web installable (PWA). Pour l’installer sur iPhone, le jeu doit d’abord être publié sur une adresse HTTPS accessible. Une archive ZIP seule ne peut pas être installée directement comme une application iOS.

1. Ouvre l’adresse HTTPS du jeu dans **Safari** sur l’iPhone.
2. Appuie sur **Partager**.
3. Choisis **Sur l’écran d’accueil**.
4. Vérifie le nom « L’Autre Joueur », puis appuie sur **Ajouter**.
5. Lance le jeu depuis la nouvelle icône. L’interface s’adapte au portrait comme au paysage.
6. Laisse le premier chargement se terminer avec une connexion active : le service worker met ensuite en cache le jeu et ses ressources pour les ouvertures hors ligne.

Sur ordinateur, ouvre l’adresse HTTPS dans un navigateur compatible et utilise la commande d’installation proposée par celui-ci, si elle est disponible.

**État actuel :** le manifeste, les icônes, le mode autonome, le jeu tactile en portrait et en paysage, et le cache hors ligne sont intégrés au paquet. Les chapitres 44, 48 et 50 ont passé les contrôles statiques et structurels de la QA59. La QA60 rend l’échec de sauvegarde visible et ajoute une sauvegarde à la fermeture de la page ; cette amélioration n’a pas encore été éprouvée sur appareil. Les cinquante chapitres n’ont pas été parcourus intégralement ; les essais de jeu sur iPhone et Android, l’hébergement HTTPS et la préparation d’une éventuelle version App Store restent à effectuer.

Le dernier état détaillé et les points restants figurent dans [tests/QA60_ETAT_DU_PROJET.md](tests/QA60_ETAT_DU_PROJET.md).

## Publier une version de test en HTTPS avec GitHub Pages

Le workflow [`.github/workflows/deploy-pages.yml`](.github/workflows/deploy-pages.yml) prépare seulement les fichiers nécessaires au jeu, puis les publie avec GitHub Pages. Il se lance à la demande ou après un envoi sur la branche principale du dépôt. Dans les réglages GitHub du dépôt, la source Pages doit être réglée sur **GitHub Actions**.

Le dépôt GitHub que tu as fourni publie maintenant le jeu sur [cette adresse HTTPS](https://9vckvzwgkv-droid.github.io/l-autre-joueur_mobile/). Son workflow extrait l’archive placée à la racine du dépôt. Le dossier de travail local n’est pas relié à ce dépôt : l’archive QA60 locale a été créée après la publication et ses améliorations de sauvegarde ne sont pas encore présentes sur le site. Toute personne disposant de l’adresse peut ouvrir le jeu.
