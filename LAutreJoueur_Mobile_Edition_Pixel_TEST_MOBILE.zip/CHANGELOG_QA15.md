# QA15 — Correctifs d'affichage mobile et identité des menus

## Corrections ciblées
- Reprise des hauteurs des panneaux avec prise en compte des zones de sécurité iOS (`safe-area-inset-*`) et de la hauteur dynamique du navigateur.
- Suppression des contraintes de hauteur contradictoires héritées des couches QA12–QA14 pour les panneaux et le menu principal.
- Accueil paysage recomposé en deux zones compactes : identité du jeu à gauche, navigation à droite ; tailles typographiques et boutons adaptés aux petits écrans paysage.
- Menu Pause compacté en paysage afin de rendre ses cinq actions plus facilement accessibles sans masquer la fin du panneau.
- Défilement tactile inertiel conservé pour les panneaux longs (chapitres, réglages, carnet et carte).
- Largeurs et contenus des cartes sécurisés contre les débordements ; zones tactiles des curseurs préservées.
- Cache PWA incrémenté de `r15` à `r16` pour forcer le chargement des styles corrigés après publication.

## Préservation
- Aucune modification de `game.js`, `content.js`, `visual-pixel.js`, `style.css`, `visual-pixel.css`, des cartes, des 50 chapitres, des collisions, déplacements, ennemis, IA, énigmes, pièges, progression, sauvegardes, audio ou commandes tactiles.
- Modifications limitées à `ui-modern.css`, `sw.js` et à la documentation QA.

## Validation et limites
- Les contrôles statiques doivent confirmer l'intégrité HTML/JavaScript et les ressources locales.
- Aucun rendu visuel iPhone physique n'est simulé ici : le comportement final doit encore être confirmé sur l'appareil après publication, notamment en Safari paysage.
