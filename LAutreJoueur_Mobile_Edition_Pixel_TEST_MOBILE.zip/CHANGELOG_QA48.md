# QA48 — Jeu tactile en portrait et paysage

- Le démarrage et les écrans de jeu ne bloquent plus le portrait.
- Une rotation du téléphone ne masque plus le HUD ou les commandes et ne force plus l’ouverture de la pause.
- Les entrées de déplacement sont relâchées au changement d’orientation pour éviter un mouvement coincé.
- Le canevas et ses commandes tactiles se redimensionnent avec la fenêtre, dans les deux orientations.
- Les commandes par défaut s’espacent différemment en portrait ; un placement personnalisé reste conservé.
- La consigne plein écran « tourne ton téléphone » a été retirée ; le manifeste PWA autorise les deux orientations.
- Le guide d’installation iPhone et le suivi de conception indiquent maintenant le jeu en portrait ou paysage.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r57`.

## Vérifications

- Les gardes qui empêchaient le démarrage ou la reprise en portrait ont été retirées.
- L’interface tactile reste pilotée par la détection d’écran tactile et par le redimensionnement du canevas.
- Redimensionnement simulé à 320 × 568 puis à 844 × 390 : la partie reste active, les commandes restent visibles et l’entrée est relâchée au pivot.
- La validation du rendu sur iPhone et Android physiques reste à effectuer.
