# QA44 — Les pièges sonores déplacent les patrouilles

- Les alarmes attirent maintenant les patrouilles et autres ennemis mobiles proches vers leur source, en suivant les couloirs. Les sentinelles restent en poste et se mettent en alerte.
- Le niveau d’alerte provoqué par le son est plafonné sous le seuil de capture : l’alarme signale une menace et dirige les ennemis, sans capturer instantanément le joueur. Les alarmes des grands domaines sont replacées si nécessaire pour qu’au moins une patrouille mobile puisse les entendre.
- La recherche de chemin utilise désormais la surface complète de la carte. L’ancienne limite fixe pouvait empêcher le compagnon ou les patrouilles d’atteindre une cible éloignée dans les grands domaines.
- L’aide en jeu décrit le comportement sonore et le cache PWA passe à `laj-mobile-pixel-r53`.

## Vérification

- Analyse syntaxique réussie pour les scripts du jeu et le script intégré à la page ; les 29 ressources mises en cache hors ligne sont présentes.
- Génération des 50 cartes et recherche d’un trajet départ-sortie contrôlées ; longueurs obtenues de 25 à 175 cases.
- Chacune des 14 cartes finales contient des alarmes à portée d’au moins une patrouille mobile ; le déplacement vers leur source a été contrôlé dans chaque domaine.
- La version de carte reste 9 : la géométrie est inchangée et les états des pièges restent associés à leurs indices. Les sauvegardes de campagne gardent donc leur position et leurs sceaux.
- Les parcours complets, l’équilibrage et les essais sur téléphone restent à faire.
