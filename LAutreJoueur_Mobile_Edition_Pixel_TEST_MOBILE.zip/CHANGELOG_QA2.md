# Changelog — Édition Pixel QA2

Cette version ajoute une passe de finition pixel art aux tuiles de murs et de sols du labyrinthe. Les détails sont déterministes et mis en cache. Le moteur de jeu, les 50 cartes, les collisions, les énigmes, les ennemis, les sauvegardes et les musiques restent inchangés.

Voir `tests/QA_PIXEL_QA2_2026-11-14.md` pour les tests exécutés et les limites connues.
