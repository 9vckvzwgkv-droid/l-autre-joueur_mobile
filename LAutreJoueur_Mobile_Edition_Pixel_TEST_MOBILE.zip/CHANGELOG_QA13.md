# QA13 — Corrections d’interface

## Corrections ciblées depuis les captures iPhone paysage
- Réinitialisation du défilement d’un panneau à chaque ouverture/retour : les premiers libellés des réglages ne restent plus hors écran.
- Ajustement des hauteurs, marges et boutons du panneau Pause pour limiter la coupure du dernier bouton.
- Panneaux secondaires mieux contenus dans la hauteur disponible, avec défilement conservé mais barre visuelle masquée.
- Carte du labyrinthe agrandie dans son panneau, avec une hauteur adaptée au paysage.
- Chapitres verrouillés éclaircis pour améliorer la lecture sans les rendre sélectionnables.
- Curseurs de réglages harmonisés avec la palette ambre.
- Accueil : espace supérieur et défilement interne sécurisés pour éviter le titre rogné.

## Préservation
Aucun changement aux données des 50 chapitres, cartes, collisions, déplacements, ennemis, IA, énigmes, pièges, progression, sauvegardes, commandes ou audio. Dans game.js, seul le comportement d’ouverture des panneaux UI a été ajusté pour remettre leur scroll en haut.

## Validation
Contrôles de syntaxe et de structure à effectuer après génération. Test physique iPhone non effectué dans cette session.
