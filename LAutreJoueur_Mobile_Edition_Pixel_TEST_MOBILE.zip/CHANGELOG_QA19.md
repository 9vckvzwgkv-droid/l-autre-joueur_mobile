# QA19 — Transitions et expérience tactile

## Étape 1 — transitions entre menus
- Ajout d’une arrivée courte et cohérente pour le menu principal et les panneaux.
- Mouvement doux, léger fondu et profondeur discrète, sans transition qui retarde les actions.
- Respect du réglage « Réduire les animations » via `prefers-reduced-motion` au niveau système.

## Étape 2 — ergonomie tactile
- Harmonisation des zones d’activation, états pressés et retours visuels des boutons tactiles.
- Renforcement de la prise en main du joystick et des trois boutons d’action.
- Curseurs et cases à cocher plus faciles à toucher dans les réglages.
- Atelier de disposition : bornes de déplacement calculées selon la taille réelle des commandes afin de limiter leur sortie de la zone d’aperçu.
- Ajustements de l’atelier sur petits écrans et en paysage.
- Harmonisation des bordures, surfaces et repères de panneaux avec l’identité relique/ pierre/ or patiné.

## Préservation
- Aucun changement volontaire aux cartes, chapitres, énigmes, pièges, sauvegardes, audio, progression ou comportement de L’Autre.
- Fichiers modifiés : `game.js` (bornes de déplacement dans l’éditeur uniquement), `ui-modern.css`, `sw.js`.
- Cache du service worker : `laj-mobile-pixel-r20`.

## Vérifications
- Vérifier la syntaxe JavaScript et l’intégrité de l’archive avant livraison.
- Les transitions, la taille réelle des commandes et la manipulation tactile devront encore être validées sur iPhone/Safari.
