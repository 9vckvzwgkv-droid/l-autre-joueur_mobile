# QA36 — Mémoire persistante de L’Autre

## Édition mobile
- Ajout d'un modèle déterministe séparé pour la mémoire de L’Autre, chargé avant le jeu et inclus dans le cache hors ligne PWA (r38).
- La sauvegarde suit les déplacements à pied ou en course, les pièges et captures, les appels et pauses demandés, les moments passés près de L’Autre, les salles visitées et les chapitres abordés.
- Cette mémoire change légèrement la distance de suivi, la vitesse de retour et l'anticipation des dangers. Le carnet raconte l'habitude dominante observée.
- Les sauvegardes antérieures et les imports restent acceptés ; leurs nouvelles statistiques commencent à zéro, tandis que la progression et les réglages sont gardés.
- Les reprises de partie et les redémarrages d'un chapitre ne comptent pas comme une nouvelle entrée. Les commandes tactiles et l'interface de jeu mobile restent en place.

## Vérification ciblée
- 15 contrôles ciblés passent : compatibilité avec les sauvegardes précédentes, valeurs manquantes et bornées, adaptation selon le rythme, les dangers, les rappels et les pauses, texte du carnet, chargement hors ligne, présence des entrées tactiles, analyse des scripts et redémarrages de chapitre.
- Le comportement a été vérifié au niveau du modèle JavaScript. Aucune validation visuelle ou tactile sur iPhone ou Android n'est revendiquée.
