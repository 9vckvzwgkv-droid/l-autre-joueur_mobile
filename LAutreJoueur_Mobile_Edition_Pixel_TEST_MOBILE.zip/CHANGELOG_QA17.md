# QA17 — Identité visuelle exclusive

Base : QA16.

## Habillage ajouté
- Langage visuel de reliques et de sceaux : filets dorés patinés, doubles encadrements fins, halos discrets et motifs circulaires.
- Emblème central animé sur l'écran d'accueil.
- Médaillon propre à chaque grande fenêtre (chapitres, réglages, commandes, aide, pause, carte, journal, fin).
- Boutons primaires et secondaires harmonisés avec une finition de métal ancien et de pierre sombre.
- Animations sobres limitées aux menus, avec prise en compte de `prefers-reduced-motion`.

## Périmètre préservé
- Modifications limitées à `ui-modern.css` et `sw.js`, plus ce journal.
- Aucun changement à `game.js`, `content.js`, `visual-pixel.js`, aux données des 50 chapitres, aux cartes, aux énigmes, aux pièges, aux sauvegardes ou à l'IA.
- Clé de cache du service worker incrémentée en r18.

## Vérification et limites
- Contrôle statique de l'archive et confirmation que le patch visuel est ajouté à la feuille de style de l'interface.
- Aucun test sur iPhone réel ni validation visuelle dans Safari n'a été effectué dans cette étape.
- Les symboles et ornements sont générés en CSS : aucun fichier image externe ni dépendance supplémentaire.
