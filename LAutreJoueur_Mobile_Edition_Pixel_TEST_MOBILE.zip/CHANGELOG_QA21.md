# QA21 — Refonte intégrale de l'identité des menus

## Direction artistique
Refonte de l'habillage de l'ensemble des menus et panneaux dans une identité propre à L’AUTRE JOUEUR : sanctuaire ancien envahi par la végétation, pierre sombre texturée en pixel art, sceaux géométriques, runes, filets d'or patiné et lumière discrète.

## Écrans concernés
- Accueil et menu principal ; sélection des 50 chapitres ; réglages et cartes de préférences ; atelier tactile ; guide ; pause ; carte et carnet ; choix de fin de chapitre ; écran de conclusion ; confirmations et notifications.

## Travail réalisé
- Cadres de pierre, doubles filets, coins gravés et motifs de sceau.
- Nouvelle hiérarchie typographique et palette ivoire, mousse, pierre charbon et or patiné.
- Boutons primaires, secondaires et destructifs différenciés par matière, relief et contraste.
- Cartes de chapitres et cartes de réglages intégrées au même langage visuel.
- Curseurs, cases à cocher, commandes de carte et notifications harmonisés.
- Adaptations spécifiques au mobile, aux écrans paysage courts et aux appareils tactiles.
- Textures CSS légères, sans asset externe, compatibles avec le fonctionnement hors ligne.

## Préservation fonctionnelle
Aucune modification volontaire de game.js, content.js, de la progression, des chapitres, des énigmes, des pièges, des sauvegardes, de l'IA ou de l'audio. Les identifiants HTML et boutons existants sont conservés. Cache service worker : `laj-mobile-pixel-r22`.

## Vérifications
Contrôle de syntaxe JavaScript, intégrité ZIP et comparaison des fichiers. Tests visuels et fonctionnels sur iPhone Safari, Android et ordinateur encore indispensables avant validation commerciale.
