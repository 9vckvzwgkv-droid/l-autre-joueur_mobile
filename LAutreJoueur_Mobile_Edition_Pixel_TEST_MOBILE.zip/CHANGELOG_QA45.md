# QA45 — Salles à paliers en 2.5D

- Les salles marquées en profondeur montrent maintenant un escalier de pierre en cinq paliers, avec surfaces supérieures, contremarches et faces latérales ombrées.
- Les pierres reprennent les couleurs de mur, de sol et d’accent du chapitre ; les lignes ambrées relient l’escalier au langage visuel des runes.
- La modification reste dans la couche de rendu : collisions, déplacements, objectifs et sauvegardes ne changent pas.
- Cache PWA hors ligne porté à `laj-mobile-pixel-r54`.

## Vérification

- Analyse syntaxique réussie pour les scripts et le script intégré de la page.
- Rendu des 182 salles en profondeur des 50 chapitres exécuté sans erreur ; les 50 trajets départ-sortie restent accessibles.
- Le cadrage et la lisibilité doivent encore être confirmés sur téléphone réel.
