# QA6 — Audit de jouabilité structurelle des 50 chapitres

## Travail effectué
- Ajout de `tools/qa6_map_audit.js`, audit reproductible des cartes à partir du générateur réel `content.js`.
- Contrôle pour chacun des 50 chapitres : dimensions et nombre de tuiles, départ et sortie praticables, trois runes présentes et praticables, secret praticable, pièges et ennemis placés sur des cases praticables.
- Calcul indépendant de connectivité par parcours en largeur (BFS) entre le départ et la sortie, chacune des trois runes et le secret.
- Vérification du chemin retourné par l'API `LAJContent.path` jusqu'à la sortie.
- Conservation des résultats détaillés par chapitre dans `tests/QA6_MAP_AUDIT.json`.

## Résultats
- 700 assertions réussies, 0 échec.
- Les 50 chapitres passent les contrôles de structure et de connectivité.
- Les 36 labyrinthes et les 14 grands domaines sont inclus.
- Le pré-vol QA5 est rejoué : 10/10 contrôles statiques réussis.
- Vérification syntaxique Node réussie pour les scripts principaux et le nouvel outil d'audit.

## Périmètre inchangé
Aucun changement au gameplay, aux règles, à l'IA de L'Autre, aux collisions, aux positions générées, aux ennemis, aux sauvegardes, aux sons ou au rendu. Le jeu PC et la version publiée ne sont pas modifiés.

## Limites
Cet audit confirme la praticabilité structurelle des objectifs sur les cartes générées, pas la qualité ludique, la difficulté, la lisibilité, l'équilibrage, la détection réelle des pièges ni le comportement adaptatif en session. Aucun test physique iPhone/Android n'est effectué dans cette passe. QA6 est un paquet de contrôle et de développement, pas une certification commerciale.
