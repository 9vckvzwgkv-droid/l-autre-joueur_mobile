# QA16 — Finition et stabilisation de l'interface

## Corrections ciblées
- Correction de la grille de l'accueil : définition explicite des six rangées, dont la rangée de pied de page, pour éviter le chevauchement et les rangées implicites.
- Stabilisation de la structure verticale des panneaux : en-têtes et actions gardent leur place, les zones de contenu peuvent se réduire sans pousser les boutons hors écran.
- Harmonisation de la pause, du carnet, de la carte et des réglages.
- Atelier tactile : disposition initiale des quatre commandes rendue immédiatement visible, meilleure zone de prévisualisation et maintien du déplacement tactile.
- Carte : commandes de zoom plus accessibles.
- Réglages : meilleure tenue des libellés longs et des valeurs sur petit écran.
- Animation décorative légère du panneau d'accueil, désactivée lorsque le système demande une réduction des animations.
- Cache PWA incrémenté pour forcer le chargement de la nouvelle feuille de style.

## Préservation
- Aucun changement à game.js, content.js, visual-pixel.js, aux données des chapitres, cartes, collisions, déplacements, ennemis, IA, énigmes, pièges, progression, sauvegardes ou ressources audio.
- Modifications limitées à ui-modern.css, sw.js et ce journal QA.

## Validation
- Contrôle syntaxique CSS/HTML et contrôle d'intégrité des fichiers à effectuer avant publication.
- Le rendu et les interactions sur appareils réels restent à tester par l'utilisateur après la fin de la refonte.
