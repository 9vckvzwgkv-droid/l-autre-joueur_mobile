/* Persistent, deterministic habit model for L'Autre. */
(function(root){
  'use strict';
  const defaults={walkSeconds:0,runSeconds:0,trapHits:0,enemyCaptures:0,callCount:0,waitCount:0,nearCompanionSeconds:0,roomsVisited:0,chaptersEntered:0};
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
  function cleanMemory(raw={}){
    const input=raw&&typeof raw==='object'?raw:{};
    const out={};
    for(const [key,fallback] of Object.entries(defaults)){
      const value=Number(input[key]);
      out[key]=Number.isFinite(value)?clamp(value,0,1e8):fallback;
    }
    return out;
  }
  function profile(memory){
    const m=cleanMemory(memory),travel=Math.max(1,m.walkSeconds+m.runSeconds);
    return {
      hurry:clamp(m.runSeconds/travel,0,1),
      caution:clamp((m.trapHits+m.enemyCaptures*1.4)/(1+travel/240),0,1),
      bond:clamp((m.callCount+m.nearCompanionSeconds/45)/(2+Math.max(0,m.chaptersEntered-1)),0,1),
      exploration:clamp(m.roomsVisited/Math.max(6,m.chaptersEntered*5),0,1),
      patience:clamp(m.waitCount/Math.max(2,m.chaptersEntered*2),0,1)
    };
  }
  function followDistance(trust,p){
    const base=trust<35?2.3:trust>65?.92:1.25;
    return clamp(base+p.hurry*.45-p.caution*.5-p.bond*.2-p.exploration*.12+p.patience*.18,.72,2.9);
  }
  function followSpeed(trust,distance,p){
    return 2.25+trust/125+(distance>5?.85:0)+p.caution*.35+p.bond*.15-p.hurry*.15;
  }
  function warningSettings(trust,p){
    return {
      enabled:trust>=Math.max(28,45-p.caution*18-p.bond*5),
      radius:2.8+p.caution*1.8-p.hurry*.35+p.patience*.28,
      companionRange:4+p.caution,
      cooldown:17-p.caution*7-p.bond*2+p.hurry*2-p.patience*.5
    };
  }
  function insight(p){
    if(p.caution>.48)return 'L’Autre garde en mémoire tes passages difficiles. Il veille plus tôt sur les dalles et les ennemis.';
    if(p.hurry>.62)return 'L’Autre s’est adapté à ton rythme pressé et maintient un peu plus de distance.';
    if(p.bond>.58)return 'L’Autre remarque que tu le rappelles souvent et revient plus rapidement vers toi.';
    if(p.patience>.58)return 'L’Autre a compris que tu prends le temps d’observer. Il veille sur les passages pendant tes pauses.';
    if(p.exploration>.62)return 'L’Autre a remarqué les salles que tu explores et reste attentif aux détours.';
    return 'L’Autre observe encore ton rythme et les chemins que tu choisis.';
  }
  const api={defaults,cleanMemory,profile,followDistance,followSpeed,warningSettings,insight};
  root.LAJCompanionAI=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
