# QA31 — HUD, commandes et audit global

## Modifications de l’interface
- Recomposition compacte du HUD : titre du chapitre, sceaux, confiance et actions mieux hiérarchisés.
- Compteurs de sceaux et jauge de confiance harmonisés au pixel art, sans animation permanente.
- Mini-carte avec cadre plus discret et dimensions mieux contenues.
- Correction du calque tactile : il occupe désormais toute la scène, afin que les coordonnées sauvegardées soient calculées depuis l’écran et non depuis la seule hauteur du joystick.
- Répartition par défaut des commandes tactiles ajustée pour mieux séparer « Agir », « L’Autre » et « Courir ». Les positions personnalisées restent conservées ; les anciennes positions par défaut sont migrées vers la nouvelle disposition.

## Préservation
Aucune modification des algorithmes de labyrinthe, des énigmes, des pièges, des ennemis, du suivi de L’Autre, de la progression ou du format de sauvegarde. Le seul changement dans `game.js` concerne les valeurs par défaut et la migration des coordonnées des commandes tactiles.

## Audit
- Les 50 chapitres ont été générés et contrôlés individuellement.
- Les 36 labyrinthes et 14 domaines sont présents.
- Les 50 cartes n’ont aucun secteur praticable isolé dans le test de connectivité ; départ, sortie, sceaux, souvenir, pièges et ennemis apparaissent sur des cases accessibles.
- Les fichiers appelés par le HTML, les feuilles CSS et le service worker sont contrôlés dans le rapport QA31.
- Les limites fonctionnelles restantes sont décrites dans `tests/QA31_ETAT_DU_PROJET.md`.

## Validation et limites
- Vérifications syntaxiques JavaScript, cohérence des ressources, structure HTML, manifeste, feuilles CSS et intégrité ZIP.
- Un lancement automatisé dans Chromium a été tenté, mais l’environnement de travail a bloqué l’accès du navigateur aux pages locales (`ERR_BLOCKED_BY_ADMINISTRATOR`). Aucun test navigateur, iPhone ou appareil physique n’est donc revendiqué pour QA31.
