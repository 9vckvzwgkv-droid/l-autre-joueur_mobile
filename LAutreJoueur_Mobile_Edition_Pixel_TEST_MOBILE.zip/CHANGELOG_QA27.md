# QA27 — Atelier des réglages et commandes tactiles

## Objectif visuel
Poursuivre l'identité du sanctuaire : pierre sombre texturée, gravures fines, mousse, métal patiné et fil d'or. Cette étape se concentre exclusivement sur l'écran Réglages et l'Atelier tactile.

## Modifications
- Nouvelle feuille `ui-atelier.css`, chargée après les feuilles existantes.
- En-tête des réglages transformé en plaque gravée avec sceau et hiérarchie typographique renforcée.
- Cartes Son, Visibilité, Affichage et Carte différenciées par de subtils accents matériels, sans perdre la cohérence d'ensemble.
- Curseurs, cases à cocher, actions audio et zone de sauvegarde intégrés au langage visuel du jeu.
- Atelier tactile retravaillé comme une table de calibration ancienne : grille, repères, commandes individualisées et relief renforcé.
- Adaptations portrait, petits écrans et paysage court; prise en compte du contraste élevé et de la réduction des animations.

## Périmètre préservé
Aucun changement dans `game.js`, `content.js`, `visual-pixel.js`, les données, la logique de sauvegarde, les commandes ou les interactions. Seuls `index.html`, `sw.js` et la nouvelle feuille CSS sont modifiés/ajoutés.

## Contrôles
- Vérifier syntaxe CSS avec tinycss2.
- Vérifier syntaxe JavaScript du service worker.
- Vérifier que la feuille et ses ressources sont référencées dans le cache hors ligne.
- Vérifier l'intégrité de l'archive ZIP.
- La capture Chromium n'a pas pu être obtenue dans cet environnement; aucun test réel Safari iOS / Android / ordinateur n'est revendiqué.
