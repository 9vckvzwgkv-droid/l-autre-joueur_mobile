# QA32 — Direction artistique pierre noire et runes ambrées

## Interface
- Ajout d'une feuille de style dédiée qui harmonise le menu principal, les panneaux, les réglages, la carte, les commandes tactiles et le HUD.
- Palette centrée sur la roche sombre, les verts de mousse, l'or patiné et l'ambre.
- Cadres à double filet, texture minérale et détails de lierre pour rapprocher les menus de l'univers des seuils et sanctuaires.
- Éclairage ambré limité aux sceaux, au bouton principal et aux interactions utiles ; l'animation du sceau respecte la préférence de réduction des animations.
- Ajustements distincts pour l'accueil en portrait et en paysage.
- Sceaux éveillés, porte et marqueurs de carte réaccordés à l'ambre et au vert mousse.

## PWA
- Le nouveau style est inclus dans le précache hors ligne.
- Le cache passe à `laj-mobile-pixel-r33`.
- Les couleurs de fond et de barre du navigateur suivent la nouvelle palette sombre.

## Validation
- La prévisualisation intégrée n'a pas pu ouvrir le fichier local selon sa règle d'accès aux pages `file:`.
- Le lancement local du serveur est bloqué par les permissions réseau de l'environnement ; aucune validation visuelle dans un navigateur ou sur appareil n'est revendiquée pour cette passe.
