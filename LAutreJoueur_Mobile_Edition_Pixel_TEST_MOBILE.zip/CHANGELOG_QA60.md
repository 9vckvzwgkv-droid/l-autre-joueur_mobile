# QA60 — protection des sauvegardes mobiles

- La sauvegarde automatique tente maintenant aussi une écriture à l’événement `pagehide`, en complément de la mise en arrière-plan, de la pause et de l’enregistrement périodique.
- Si le navigateur refuse l’écriture locale, un message apparaît dans les Réglages ; en jeu, un avertissement signale qu’il faut exporter une copie.
- L’export précise si l’écriture locale a échoué, tout en téléchargeant la progression actuellement en mémoire.
- Le cache hors ligne passe de `laj-mobile-pixel-r68` à `laj-mobile-pixel-r69`.
- Ajout du workflow GitHub Pages, adapté aux fichiers du projet : il publie les ressources du jeu depuis la branche principale et expose l’adresse de déploiement.

La publication GitHub Pages du dépôt fourni a réussi après correction du chemin dans l’archive. La page est disponible à https://9vckvzwgkv-droid.github.io/l-autre-joueur_mobile/. Le site publié vient du ZIP alors présent dans le dépôt ; l’archive QA60 locale n’a pas été synchronisée dans ce dépôt. Aucun parcours sur téléphone n’a été effectué dans cette passe ; la reprise après fermeture réelle sur Safari iOS et Chrome Android reste à vérifier.
