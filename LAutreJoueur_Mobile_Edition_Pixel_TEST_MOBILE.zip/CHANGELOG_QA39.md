# QA39 — Épreuves des quatorze grands domaines

- Les chapitres 37 à 50 ont chacun une condition de domaine jouable et nommée : discrétion, clairières à suivre, marée, feuillets, cadran, lanternes, reflets, portes de quartier, prismes, silence, golems, souvenir, serment et exploration convergente.
- Les chapitres 38, 40 et 44 possèdent trois repères numérotés à franchir ou activer dans l’ordre. Leur progression reste dans la sauvegarde.
- Les reflets affichent un marqueur de côté d’approche ; les prismes ont leur propre repère lumineux. Les cycles de marée et de cadran affichent leur état au sceau et dans le carnet.
- Les énigmes de lumière utilisent des lanternes distinctes des sceaux. Les chapitres de domaine qui reposent dessus demandent les trois alignements.
- La génération passe en version 7 ; le cache PWA hors ligne passe à `laj-mobile-pixel-r42`.

## Vérifications ciblées
- Les trois scripts modifiés passent l’analyse syntaxique.
- 14/14 mécaniques finales distinctes ; les 50 combinaisons d’ordre/gestes et les 50 plans physiques restent distincts.
- Les repères, lanternes, prismes et approches ne se trouvent pas dans des murs ; les trois séries de jalons ont chacune trois éléments.
- Aucun repère numéroté ne chevauche un piège, une lanterne ou un ennemi généré.
- Le chapitre 1 reste sur sa carte dédiée.

Ces vérifications valident les données et les conditions programmées. Elles ne remplacent pas un parcours complet ni un essai sur appareil mobile réel.

## Limites à poursuivre
- Les chapitres 2 à 36 n’ont pas encore de mécaniques spécifiques comparables à celles des quatorze domaines finaux.
- Les graphes procéduraux des chapitres intermédiaires gardent des familles répétées. Les plans uniques au niveau des cases ne prouvent pas une différence de ressenti suffisante.
- La proposition des 50 chapitres est validée par le joueur, mais elle n’est pas le document PC original. Le ZIP fourni ne contient pas les fiches de conception.
- La difficulté, la lisibilité tactile et les scènes doivent encore être jouées et réglées sur téléphone.
