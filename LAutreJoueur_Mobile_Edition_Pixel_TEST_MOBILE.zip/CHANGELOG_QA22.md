# QA22 — Reconstruction de l'interface des menus

## Pourquoi cette reprise
La QA21 avait ajouté une couche de styles visuels au-dessus de la composition existante. Elle ne remplaçait pas proprement les anciennes règles de menu. La QA22 retire cette couche redondante et charge une feuille d'interface dédiée en dernier dans la cascade.

## Direction artistique
- Sanctuaire de ruines en pixel art 2D, avec la porte illustrée `art/seuil-pixel.png` conservée comme décor de fond
- Stèles et panneaux en pierre sombre, texture pixelisée réelle, bordures taillées
- Végétation/mousse sur les angles des panneaux
- Filets et séparateurs runiques en or patiné
- Palette charbon, pierre, mousse, ivoire et ambre doré
- Boutons primaires, secondaires et destructifs différenciés par matière et relief

## Menus et écrans habillés
- Accueil : composition asymétrique, décor visible à droite, stèle de menu à gauche sur ordinateur
- Accueil mobile portrait : décor en haut et panneau lisible en bas, avec défilement interne si nécessaire
- Sélection des 50 chapitres : médaillons numérotés, noms et thèmes mieux hiérarchisés
- Réglages : quatre cartes distinctes, curseurs et cases à cocher conservant leurs contrôles natifs
- Atelier tactile : scène d'aperçu quadrillée et commandes en plaques de pierre
- Guide, pause, carte, carnet, choix de chapitre et fin
- Dialogues de confirmation, notifications et éléments du HUD

## Assets ajoutés
- `art/ui/stone-pixel-tile.png` — texture répétable de maçonnerie sombre
- `art/ui/slab-grain.png` — grain fin de stèle
- `art/ui/vine-corner.png` — végétation pixelisée et filigrane doré
- `art/ui/gold-rune-divider.png` — séparateur runique

## Préservation fonctionnelle
Aucun changement de logique dans `game.js`, `content.js` ou `visual-pixel.js`. Les identifiants, boutons, contrôles, sauvegardes, cartes, progression, chapitres, énigmes, pièges, IA et audio sont conservés. `index.html` charge `ui-relic.css` après les feuilles précédentes. Cache service worker : `laj-mobile-pixel-r23`.

## Vérifications effectuées
- Syntaxe des scripts JavaScript contrôlée avec Node
- Feuille CSS dédiée analysée sans erreur de syntaxe par tinycss2
- Références des textures et leur présence dans l'archive contrôlées
- Intégrité ZIP contrôlée
- Comparaison avec QA21 : aucun fichier de gameplay modifié

## Tests restant nécessaires
Le rendu exact et les interactions doivent encore être validés sur iPhone Safari, Android et ordinateur. Cette archive ne constitue pas à elle seule une certification commerciale ou une validation sur appareils réels.
