# QA5 — Pré-vol qualité et préparation de livraison

## Travail effectué
- Ajout de `tools/qa5_preflight.py`, audit statique reproductible du paquet.
- Vérification des identifiants HTML, des noms accessibles des boutons, des ressources locales référencées, des icônes et du manifeste PWA.
- Vérification que toutes les ressources déclarées dans le précache du service worker existent.
- Vérification de la présence des mécanismes d'export/import et de sauvegarde de secours.

## Résultats
- 10 contrôles statiques réussis sur 10.
- Aucun identifiant HTML dupliqué.
- Aucun bouton sans nom accessible détecté.
- Toutes les ressources locales et ressources de précache référencées existent.
- Manifeste en mode autonome et orientation paysage.

## Périmètre inchangé
Aucune modification du gameplay, de l'IA de L'Autre, des cartes, des collisions, des ennemis, des sauvegardes, des musiques ou du rendu. Le jeu PC n'a pas été touché.

## Limites
Cette passe n'est pas une certification commerciale. Elle ne remplace pas les tests réels sur iPhone/Android, les tests de sauvegarde après fermeture/réinstallation, les essais de réseau hors ligne, l'audit de sécurité/confidentialité, les tests d'accessibilité utilisateurs, l'équilibrage humain des 50 chapitres, ni la vérification des droits sur les ressources audio et graphiques.
