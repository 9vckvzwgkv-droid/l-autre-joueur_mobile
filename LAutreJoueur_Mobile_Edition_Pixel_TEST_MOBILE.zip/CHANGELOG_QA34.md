# QA34 — Salles explorables et cadrage de profondeur mobile

## Cartes
- Les chapitres 2 à 50 utilisent désormais une génération « salles d'abord » : chambres de 4 à 6 cases dans les labyrinthes, chambres de 7 à 11 cases dans les grands domaines, passages larges de trois cases et boucles entre les salles.
- Le nombre et l'identité des chapitres, thèmes, runes, secrets, pièges et ennemis sont conservés. Le Premier Seuil garde sa géométrie PC dédiée.
- Certaines salles reçoivent un élément de sanctuaire et une transition de projection oblique 2.5D. La scène s'aplatit et s'incline progressivement ; le HUD et les commandes tactiles restent dans le plan de l'écran.
- Le joystick et le clavier compensent la projection 2.5D pour que les directions demandées correspondent aux directions visibles à l'écran.
- La génération des emplacements d'objets a été rendue moins coûteuse pour les ouvertures sur téléphone.

## Progression existante
- Les sauvegardes antérieures conservent les sceaux obtenus, fragments de mémoire, confiance et choix.
- À la migration des cartes, la position, l'exploration locale et les pièges déjà déclenchés repartent au seuil afin d'éviter de restaurer des coordonnées de l'ancienne géométrie dans un mur.

## Contrôle structurel
- Les 50 chapitres ont été générés : toutes les cases praticables sont reliées au départ ; les sorties, runes, secrets, pièges et ennemis sont placés sur des cases accessibles.
- Les chapitres 37 à 50 produisent bien chacun 20 pièges mortels et 15 pièges ralentisseurs.
- Les scripts JavaScript modifiés ont été analysés avec le parseur.
- Aucune validation visuelle sur navigateur ni essai tactile sur téléphone n'est revendiqué pour cette passe.

## Cache hors ligne
- Cache PWA incrémenté à `laj-mobile-pixel-r36`.
