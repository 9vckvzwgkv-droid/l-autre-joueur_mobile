/* L’Autre Joueur · Mobile 2D · world generation, no external dependencies. */
(function(root){
'use strict';
const chapterNames=[
'Le Premier Seuil','Les Traces','Le Choix','Le Miroir','La Première Coopération','Le Détour',
'Le Couloir des Murmures','Les Dalles Endormies','La Salle des Doubles','Les Trois Serments',
'La Porte Sans Clé','Le Passage Renversé','Les Marches Brisées','Les Horloges Muettes',
'La Chambre des Échos','Les Reflets Trompeurs','Le Relais Perdu','Les Jardins Oubliés',
'Les Veilleurs de Pierre','La Galerie des Noms','Le Cercle des Ombres','Les Portes Jumelles',
'Le Chemin du Retour','Les Runes du Silence','La Salle des Décisions','Le Labyrinthe Mouvant',
'Les Veines de Cuivre','La Marche du Golem','Les Yeux du Labyrinthe','La Confiance Fragile',
'Le Puits des Souvenirs','La Dernière Patrouille','La Première Vérité','L’Absence',
'L’Origine des Traces','Le Carrefour des Choix',
'Le Plateau des Sentinelles','La Forêt de Basalte','La Mer des Brumes','La Bibliothèque Infinie',
'Le Désert des Horloges','Les Jardins Suspendus','Les Marais des Reflets',
'La Cité des Portes','Les Profondeurs Cristallines','La Faille du Silence',
'Le Royaume des Golems','La Nécropole des Mémoires','La Cathédrale des Serments','Au-delà du Dernier Seuil'];
const descriptions=[
'Une lanterne, trois marques et le sentiment d’être suivi.',
'Des empreintes vraies et de fausses pistes conduisent à une première découverte.',
'Deux chemins mettent la confiance à l’épreuve.',
'Ce que montre une surface n’est pas toujours devant elle.',
'La première porte que deux personnes peuvent ouvrir ensemble.',
'Un chemin s’ouvre quand un autre se referme.',
'Les voix voyagent sous la mousse, mais aucune ne vient de la salle où tu te tiens.',
'Des dalles lourdes gardent les traces d’un passage que la lanterne révèle par éclats.',
'Une même salle semble abriter deux silhouettes, mais une seule laisse des empreintes.',
'Trois serments éclairent les marques du seuil ; aucun ne promet que tu ressortiras seul.',
'La porte n’a pas de serrure. Elle attend un geste que les murs ont oublié.',
'Le couloir revient sur lui-même ; les signes gravés à rebours suggèrent une autre voie.',
'Des marches brisées montent vers des salles que la pierre a depuis longtemps condamnées.',
'Toutes les horloges se sont tues à des heures différentes.',
'Un murmure revient après chaque détour, plus proche que l’écho précédent.',
'Les reflets gardent l’image de passages que la lanterne ne trouve plus.',
'Deux pierres éloignées se répondent à travers le cuivre enfoui.',
'Sous les ronces, des lanternes nourrissent les racines pâles du jardin.',
'Les veilleurs de pierre couvrent les salles sans jamais regarder dans la même direction.',
'Des noms gravés dans la galerie pâlissent à mesure que tu t’en approches.',
'Les ombres dessinent un cercle autour d’une lumière que personne ne voit.',
'Chaque arche ressemble à la précédente ; seules les traces distinguent la bonne route.',
'Les empreintes du retour se superposent à celles de l’aller jusqu’au carrefour effacé.',
'Les runes les plus anciennes sont presque muettes ; leurs intervalles gardent l’ordre.',
'Une décision ouvre une voie et en assombrit une autre. La confiance en garde la marque.',
'Les couloirs semblent changer de place dès que la brume avale tes repères.',
'Des fils de cuivre suivent les veines de la roche jusque sous les seuils.',
'Le golem ne garde pas un trésor : il attend qu’on lui rende son nom.',
'Les yeux sculptés n’éclairent rien. Leur regard, lui, ne perd jamais la route.',
'Le seuil s’éclaire quand vous avancez ensemble et s’éteint lorsque la confiance s’éloigne.',
'Au fond du puits, les souvenirs n’appartiennent pas tous à celui qui les trouve.',
'La dernière patrouille répète la ronde d’un veilleur qui n’est jamais revenu.',
'Les marques ressemblent à celles des anciens, jusqu’à ce qu’une empreinte porte ton pas.',
'La salle la plus claire ne contient personne ; le silence autour révèle une absence.',
'Les premières traces que tu as suivies semblent avoir été laissées pour toi.',
'Toutes les routes convergent ici. Le dernier passage attend votre décision.'];
const labyrinthLore=[
'Une inscription ancienne parle de deux voyageurs, mais une seule signature a été gravée.',
'La plus petite empreinte s’arrête net ; la plus grande revient sur ses pas.',
'Un détour fut choisi avant même que la première porte soit bâtie.',
'Le miroir ne reflète pas le premier voyageur qui l’a traversé.',
'Deux noms furent gravés côte à côte, puis l’un fut effacé à la hâte.',
'La trace qui quitte le chemin principal revient toujours près de l’autre.',
'Quelqu’un a murmuré ton nom dans une salle vide, bien avant ton arrivée.',
'Une dalle porte la marque d’un pas qui n’a jamais touché le sol.',
'Les deux silhouettes gravées ont la même ombre, mais pas le même visage.',
'Le premier serment promettait de ne jamais laisser l’autre derrière.',
'La porte la plus ancienne a été ouverte de l’intérieur.',
'Un scribe a dessiné le labyrinthe à l’envers pour ne pas oublier la sortie.',
'Les marches n’ont pas été brisées par le temps, mais par quelqu’un qui redescendait.',
'La dernière horloge s’est arrêtée au moment où deux pas se sont séparés.',
'Un écho répond encore à une voix qui n’existe plus dans ces murs.',
'La surface polie a gardé le reflet d’une main posée contre la pierre.',
'Un fil de cuivre reliait autrefois les deux pierres du relais.',
'Sous chaque racine repose une lanterne éteinte, soigneusement protégée.',
'Les veilleurs n’ont jamais été tournés vers l’entrée, mais vers le chemin du retour.',
'Un nom revient dans la galerie avec une lettre de moins à chaque détour.',
'L’ombre au centre du cercle appartient à quelqu’un qui marche encore.',
'Les arches ont été copiées sur un même dessin ; aucune ne mène au même souvenir.',
'Celui qui est revenu avait oublié le chemin, mais pas la personne qui l’attendait.',
'Les runes ne racontent pas une promesse. Elles comptent les silences entre deux voix.',
'La décision la plus difficile fut prise sans témoin, puis gravée pour être retrouvée.',
'Le cartographe a laissé des espaces blancs aux endroits où il avait peur de continuer.',
'Le cuivre conserve la chaleur d’une main qui a disparu depuis des années.',
'Sur le front du golem, un nom est caché sous la poussière et les coups.',
'Les yeux de pierre furent taillés par quelqu’un qui ne pouvait plus voir.',
'La confiance ne se brise pas d’un seul coup ; elle s’use sur la distance.',
'Le puits garde les souvenirs qu’on n’a pas osé confier à l’autre.',
'Le veilleur a terminé sa ronde, puis a laissé la lanterne allumée pour son remplaçant.',
'La première vérité fut gravée avant le premier mensonge.',
'L’absence n’est pas un vide : elle porte la forme exacte de celui qui manque.',
'Les empreintes anciennes et les tiennes partagent la même entaille au talon.',
'Le carrefour fut construit pour qu’aucun voyageur ne choisisse à la place de l’autre.'
];
const epicDescriptions=[
'Des tours de veille balayent un plateau de pierre sous un ciel de cendres.',
'Des arbres de basalte émergent des brumes et barrent les anciennes voies.',
'Des étendues mouvantes dissimulent les sentiers entre des îlots de pierre.',
'Des galeries d’archives infinies conservent des noms qui ne devraient plus exister.',
'Des horloges enfouies découpent un désert de poussière et de rouages.',
'Des terrasses oubliées retiennent une végétation nourrie par des lanternes antiques.',
'Des mares reflètent de faux passages au milieu de sentiers submergés.',
'Une cité sans habitants s’ouvre sur des centaines de portes rivales.',
'Des aiguilles de cristal dispersent la lumière en fragments glacés.',
'Un gouffre silencieux semble absorber les sons, les traces et les promesses.',
'Des géants de pierre veillent sur les marches de leur ancien royaume.',
'Les sépultures murmurent les souvenirs d’inconnus et de compagnons perdus.',
'Une cathédrale monumentale attend que deux voix honorent leur serment.',
'Au bord du monde, le dernier seuil attend une décision que personne ne peut prendre à ta place.'
];
const epicLore=[
'La surveillance fut installée bien avant ton arrivée.',
'Les racines de pierre poussent autour des noms oubliés.',
'Le brouillard garde une direction que la carte ne montre pas.',
'Une page vierge porte deux signatures à l’encre pâle.',
'Une montre arrêtée marque l’heure de la première séparation.',
'Un jardinier inconnu entretenait les lanternes, non les fleurs.',
'Un reflet reste immobile après ton départ.',
'Une porte ne mène nulle part ; elle se souvient pourtant de pas.',
'Un cristal répète un nom que personne n’a prononcé.',
'Le silence de la faille n’efface pas les souvenirs.',
'Les golems gardent des serments qu’ils ne peuvent comprendre.',
'Une stèle porte une date dont tu ne te souviens pas.',
'Deux symboles gravés ne forment qu’un seul engagement.',
'Le dernier seuil ne dit jamais qui doit le franchir.'
];
const themes=[
{n:'Basalte et ivoire',floor:'#202b31',wall:'#53606a',edge:'#83959d',accent:'#e6ae6a',mist:'#06090d',detail:'#293940'},
{n:'Sépia et poussière',floor:'#322c30',wall:'#6d5c5a',edge:'#a9968a',accent:'#e4af80',mist:'#080609',detail:'#423339'},
{n:'Cuivre et ardoise',floor:'#263039',wall:'#617077',edge:'#b1b9b6',accent:'#e4a363',mist:'#080b0d',detail:'#38454b'},
{n:'Miroirs bleus',floor:'#202939',wall:'#506d81',edge:'#94bcd0',accent:'#a8e3ed',mist:'#060b14',detail:'#263e53'},
{n:'Pierre et ambre',floor:'#322f32',wall:'#716a68',edge:'#c1a49a',accent:'#f3bd76',mist:'#0b090b',detail:'#474146'},
{n:'Galeries écarlates',floor:'#33282c',wall:'#77545c',edge:'#b08586',accent:'#e8aa72',mist:'#0e070a',detail:'#52343a'},
{n:'Mousse violette',floor:'#262435',wall:'#595878',edge:'#aea1cd',accent:'#c7a4ff',mist:'#080712',detail:'#39354e'},
{n:'Cendres froides',floor:'#242d31',wall:'#526672',edge:'#a9b8c2',accent:'#bce7ef',mist:'#070b0f',detail:'#384850'},
{n:'Pierre verte',floor:'#28332e',wall:'#546e63',edge:'#a1b6a7',accent:'#b7dd95',mist:'#070d09',detail:'#3a4940'},
{n:'Or oublié',floor:'#332f2a',wall:'#776a52',edge:'#c0b18b',accent:'#f3d68e',mist:'#0e0b07',detail:'#4a4135'},
{n:'Silence glacé',floor:'#26323b',wall:'#617c88',edge:'#b2d3de',accent:'#afe7ff',mist:'#070e14',detail:'#385361'},
{n:'Obsidienne',floor:'#23232b',wall:'#575563',edge:'#b0a9b6',accent:'#f4b0a6',mist:'#090810',detail:'#3b3945'},
{n:'Ruines enchantées',floor:'#2d3040',wall:'#656c8f',edge:'#adb7e7',accent:'#a3d8ff',mist:'#090914',detail:'#424766'},
{n:'Cristaux profonds',floor:'#222a3c',wall:'#4f6497',edge:'#8dc5ee',accent:'#a7eaff',mist:'#05091a',detail:'#2d4473'}];
const epicThemes=[
{n:'Plateau des Sentinelles',floor:'#282d35',wall:'#667584',edge:'#c0d1d8',accent:'#a5c5e8',mist:'#080c12',detail:'#3b5163'},
{n:'Forêt de Basalte',floor:'#27342f',wall:'#527264',edge:'#a8cfaf',accent:'#c2df8d',mist:'#07120c',detail:'#345343'},
{n:'Mer des Brumes',floor:'#27353c',wall:'#64808a',edge:'#bad5e0',accent:'#b9f2ef',mist:'#061118',detail:'#345460'},
{n:'Bibliothèque Infinie',floor:'#302d37',wall:'#766780',edge:'#cfb8cc',accent:'#ebc78c',mist:'#0c0810',detail:'#4e415a'},
{n:'Désert des Horloges',floor:'#393128',wall:'#90745a',edge:'#e1be8f',accent:'#f5d995',mist:'#120b06',detail:'#5b4c37'},
{n:'Jardins Suspendus',floor:'#26382f',wall:'#58846b',edge:'#a4d5b3',accent:'#d8d3a1',mist:'#051109',detail:'#3f634b'},
{n:'Marais des Reflets',floor:'#253739',wall:'#597985',edge:'#b0d3cf',accent:'#8ed7e7',mist:'#041111',detail:'#355a63'},
{n:'Cité des Portes',floor:'#343139',wall:'#877987',edge:'#c9bac9',accent:'#edcba3',mist:'#0d0b12',detail:'#504959'},
{n:'Profondeurs Cristallines',floor:'#22263e',wall:'#6469a4',edge:'#a9bdff',accent:'#80eaff',mist:'#050619',detail:'#373d77'},
{n:'Faille du Silence',floor:'#20282e',wall:'#586974',edge:'#a4b7be',accent:'#dedde3',mist:'#05080c',detail:'#30444c'},
{n:'Royaume des Golems',floor:'#38312b',wall:'#867560',edge:'#d0b996',accent:'#ffbd75',mist:'#0c0905',detail:'#584739'},
{n:'Nécropole des Mémoires',floor:'#302b3b',wall:'#756a92',edge:'#bfb4d5',accent:'#e3a9ca',mist:'#080713',detail:'#4a3b63'},
{n:'Cathédrale des Serments',floor:'#2d2e33',wall:'#777c84',edge:'#ced1d5',accent:'#f5d4ac',mist:'#090a0e',detail:'#464c52'},
{n:'Au-delà du Dernier Seuil',floor:'#252e3d',wall:'#6a8199',edge:'#c2def3',accent:'#f0d7a7',mist:'#060912',detail:'#374960'}];
const motifs=['gravures','traces','serments','miroirs','relais','échos','lanternes','sceaux'];
const behaviors=['observe tes hésitations','ralentit lorsque tu t’éloignes','te rejoint par le chemin sûr','attend devant les reflets','peut maintenir un mécanisme','cherche un détour','réagit aux bruits','évite les dalles instables','observe tes choix répétés','fait signe devant un danger','se souvient des portes refermées','cherche les chemins non visités','surveille les marches','s’arrête pour écouter','retient les traces','hésite devant les miroirs','prend position près des relais','suit la lumière','évite les gardiens de pierre','marque les noms découverts','reste hors des ombres profondes','reconnaît les portes semblables','attend un retour','se méfie des runes effacées','réagit à ton choix précédent','suit les nouveaux passages','observe les mécanismes','ralentit devant les golems','t’avertit d’une présence','module sa distance selon la confiance','reconnaît un souvenir','évite les rondes','cherche la première vérité','résiste à la séparation','se souvient de votre rencontre','s’adapte à l’issue de ton choix'];
const puzzleRules={free:{name:'libre',hint:'aucun geste imposé',prompt:'AGIR · Le sceau est prêt',failure:'Le sceau ne répond pas encore.'},still:{name:'immobilité',hint:'reste immobile près du sceau un instant',prompt:'AGIR · Arrête-toi près du sceau',failure:'La gravure attend que tes pas se taisent.'},near:{name:'proximité',hint:'garde L’Autre près de toi',prompt:'AGIR · Reste près de L’Autre',failure:'Le sceau attend que L’Autre te rejoigne.'},far:{name:'séparation',hint:'laisse L’Autre à distance',prompt:'AGIR · Éloigne-toi de L’Autre',failure:'Le sceau s’assombrit. L’Autre doit rester derrière.'},wait:{name:'halte',hint:'demande à L’Autre d’attendre près du sceau',prompt:'AGIR · Fais attendre L’Autre près du sceau',failure:'Le relais attend L’Autre, immobile à proximité.'},call:{name:'appel',hint:'rappelle L’Autre pendant cette étape',prompt:'AGIR · Appelle L’Autre avant le sceau',failure:'Le sceau attend un nouvel appel à L’Autre.'},light:{name:'lanterne',hint:'approche le sceau dans la lumière d’une lanterne',prompt:'AGIR · Rejoins une lanterne',failure:'La gravure reste froide dans l’obscurité.'},face:{name:'orientation',hint:'regarde le sceau avant de l’activer',prompt:'AGIR · Fais face au sceau',failure:'Le symbole doit être regardé de face.'},walk:{name:'marche',hint:'approche-toi sans courir',prompt:'AGIR · Approche sans courir',failure:'La pierre se dérobe sous les pas précipités.'}};
const runeOrders=[[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]];
const domainPuzzleRules=[['face','wait','light'],['walk','near','still'],['light','far','call'],['still','face','call'],['still','walk','light'],['light','near','wait'],['face','far','walk'],['wait','call','face'],['light','still','near'],['still','walk','near'],['wait','face','near'],['still','far','light'],['near','face','wait'],['face','still','call']];
const domainPuzzleMechanics=[
  {id:'sentinels',hint:'observe la balise : quand les trois faisceaux convergent et virent au turquoise, traverse les alcôves d’ombre et active chaque sceau hors des cônes',failure:'Les faisceaux ne convergent pas encore, ou ton ombre a été balayée. Attends leur lumière turquoise ou abrite-toi derrière la roche.'},
  {id:'roots',hint:'suis les trois clairières marquées par les racines, dans l’ordre',failure:'Les racines n’ont pas encore relié ces clairières.'},
  {id:'currents',hint:'lis les flèches des ponts et suis, dans l’ordre, les trois courants qui relient réellement les îlots ; les nappes bleues sont des reflets',failure:'Le courant ne mène pas à l’îlot suivant. Cherche un pont réel et suis sa flèche.'},
  {id:'folios',hint:'compare les cotes incomplètes et lis les volumes des travées A, B puis C ; leur inventaire révèle une page aux signatures pâles manquante dans les archives',failure:'La cote ne correspond pas à l’ordre des travées. Lis les volumes A, B puis C, retrouve la page manquante et découvre le nom qui ouvre l’archive.'},
  {id:'clock',hint:'règle les trois horloges sur les heures gravées, puis active le grand cadran afin d’ouvrir la cour centrale',failure:'Les trois cadrans arrêtés attendent leurs heures gravées. Accorde-les, puis active le grand cadran de la cour.'},
  {id:'lanterns',hint:'oriente les trois lanternes-guide vers leurs signes gravés pour faire pousser les racines lumineuses entre les terrasses et rejoindre le seuil',failure:'Les racines attendent encore une lanterne orientée. Reprends son signe gravé et fais pousser les trois passages.'},
  {id:'reflections',hint:'compare les rides réelles aux fausses images du marais, puis lis les trois courants qui conduisent au seuil',failure:'Ce courant est un reflet inversé. Cherche les rides qui rejoignent réellement le passage.'},
  {id:'gates',hint:'retrouve le plan de quartier incomplet, lis l’enchaînement des enseignes et ouvre les trois portes dans l’ordre indiqué',failure:'La porte ne correspond pas à la prochaine enseigne du plan de quartier.'},
  {id:'prism',hint:'tourne les trois cristaux jusqu’à réfracter, pour chacun, la couleur gravée sur son cadre',failure:'Le rayon réfracté n’a pas encore la couleur gravée sur ce cadre.'},
  {id:'bridge-vibrations',hint:'aucun appel n’est nécessaire : éprouve les trois ponts, la vibration régulière désigne celui qui tient',failure:'Les secousses irrégulières annoncent un pont instable. Cherche la vibration grave et régulière.'},
  {id:'golems',hint:'rappelle les trois golems numérotés à leurs socles, dans l’ordre, puis attends qu’ils reforment la garde du trône',failure:'La garde de pierre n’est pas encore reformée. Rappelle les golems dans l’ordre et laisse-les regagner leurs socles.'},
  {id:'memories',hint:'écoute les trois fragments du compagnon, associe-les aux tombes qu’ils désignent dans l’ordre, puis retrouve le souvenir caché de la nécropole',failure:'La nécropole attend les trois fragments, leurs tombes dans l’ordre et le souvenir caché.'},
  {id:'vows',hint:'pour chaque sceau, place-toi sur sa marque et L’Autre sur la marque distincte ; fais-le attendre avant d’activer le serment',failure:'Le serment attend que vous teniez chacun une marque distincte.'},
  {id:'convergence',hint:'recompose le dernier récit dans l’ordre des trois signes, explore les salles et retrouve L’Autre avant le seuil',failure:'Le dernier seuil attend les trois signes dans l’ordre, une exploration plus ample et votre réunion.'}
];
const middlePuzzleMechanics=[
  {id:'trace-reading',hint:'examine la trace pâle pour comparer sa forme à la piste véritable',failure:'La fausse trace n’a pas encore révélé sa cassure.'},
  {id:'branch-choice',hint:'choisis une aile du labyrinthe, explore ses deux salles puis rejoins le seuil par la route que tu as retenue',failure:'Le choix attend que tu explores plus loin dans l’aile que tu as prise.'},
  {id:'mirror-split',hint:'approche chaque sceau depuis le côté indiqué par son double',failure:'Le miroir montre un côté différent pour atteindre cette gravure.'},
  {id:'cooperative-plate',hint:'fais tenir L’Autre sur une dalle pendant que tu actives le sceau',failure:'La plaque jumelle attend L’Autre, arrêté près de toi.'},
  {id:'detour-return',hint:'découvre l’alcôve du détour, puis reviens au seuil par la boucle intérieure',failure:'Le détour visible n’a pas encore été parcouru.'},
  {id:'echo-call',hint:'appelle L’Autre depuis la chambre qui renvoie son écho',failure:'L’écho n’a pas encore été lancé depuis la bonne chambre.'},
  {id:'sleeping-plates',hint:'les dalles s’éveillent brièvement au rythme de leur pulsation ambrée',failure:'Les dalles dorment encore. Attends leur prochaine pulsation.'},
  {id:'double-courts',hint:'explore les deux cours jumelles et compare leurs signes pour ouvrir la voie de sortie',failure:'Les deux cours n’ont pas encore été comparées.'},
  {id:'three-oaths',hint:'le premier serment demande L’Autre près de toi, le second son attente, le dernier son rappel',failure:'Le serment de cette salle attend une autre posture de L’Autre.'},
  {id:'keyless-secret',hint:'cherche la niche cachée : la porte sans serrure répond au souvenir retrouvé',failure:'La porte sans clé reste muette. Trouve d’abord le souvenir de la niche.'},
  {id:'reverse-order',hint:'suis les trois signes en remontant leur ordre, du dernier au premier',failure:'Le passage renversé exige le signe opposé à celui que tu as choisi.'},
  {id:'broken-stairs',hint:'atteins une terrasse haute signalée par le changement de perspective, puis retrouve le seuil depuis ce nouveau palier',failure:'La terrasse n’a pas encore été atteinte. Cherche une marche qui monte.'},
  {id:'clockwork-window',hint:'repère la fenêtre claire de l’horloge muette et rejoins le seuil pendant son ouverture',failure:'L’aiguille n’a pas encore ouvert la fenêtre claire.'},
  {id:'echo-cadence',hint:'réponds à la chambre par deux appels espacés d’un souffle régulier',failure:'L’écho n’a pas reçu deux appels au bon intervalle.'},
  {id:'water-mirror',hint:'approche chaque sceau par la rive que son reflet ne montre pas',failure:'Le reflet d’eau te renvoie vers l’autre rive.'},
  {id:'lost-relays',hint:'réactive les trois relais de cuivre dans l’ordre des lueurs',failure:'Le réseau attend encore le relais précédent.'},
  {id:'garden-roots',hint:'traverse les trois clairières fleuries dans l’ordre de pousse des racines',failure:'Les racines du jardin attendent leur ordre de pousse.'},
  {id:'watchtowers',hint:'traverse la place par les angles morts des quatre veilleurs, sans entrer dans leurs faisceaux',failure:'Un veilleur garde encore ta position. Rejoins une autre salle et attends son passage.'},
  {id:'name-gallery',hint:'lis les trois noms gravés dans leurs alcôves pour reconstituer le nom qui ouvre la galerie',failure:'La galerie attend que les trois noms soient lus.'},
  {id:'shadow-circle',hint:'reste dans l’ombre des colonnes, hors du halo des torches',failure:'La lumière te découvre. Éloigne-toi des torches et des braseros.'},
  {id:'twin-doors',hint:'laisse L’Autre de l’autre côté de la galerie pour séparer les deux portes',failure:'Les portes jumelles ne s’ouvrent que lorsque L’Autre garde ses distances.'},
  {id:'return-circuit',hint:'quitte le seuil par la galerie extérieure puis retrouve-le par la boucle intérieure',failure:'Le circuit n’est pas complet. Reviens au seuil initial par l’autre galerie.'},
  {id:'silent-run',hint:'immobilise-toi dans la chapelle et laisse le silence s’installer avant de rejoindre le seuil',failure:'La chapelle vibre encore. Immobilise-toi sans appeler.'},
  {id:'decision-order',hint:'la première aile choisie détermine l’ordre des signes qui suivront',failure:'Engage-toi dans une aile avant de toucher à ce signe.'},
  {id:'shifting-grid',hint:'explore les salles-charnières et rejoins le seuil quand elles s’alignent pendant leur phase claire',failure:'Les passages glissent encore. Attends que la grille s’aligne.'},
  {id:'copper-alignment',hint:'oriente-toi vers la veine de cuivre voisine pour conduire l’impulsion jusqu’au passage de sortie',failure:'La veine de cuivre pointe vers une autre direction.'},
  {id:'golem-courts',hint:'attends que les golems tournent le dos et masque-toi derrière une paroi',failure:'Une présence de pierre voit encore ton passage.'},
  {id:'watcher-angle',hint:'passe derrière les yeux de pierre sans entrer dans leur faisceau',failure:'Un œil de pierre suit encore ta silhouette.'},
  {id:'trust-rails',hint:'garde L’Autre assez près pour traverser les rails de confiance ensemble',failure:'L’Autre est trop loin pour soutenir ce passage.'},
  {id:'memory-echo',hint:'retrouve le souvenir caché puis appelle L’Autre depuis la chambre qui lui répond',failure:'Le souvenir doit d’abord être retrouvé et partagé par un appel.'},
  {id:'patrol-circuits',hint:'laisse passer les rondes, sans courir, lorsque les trois circuits se croisent',failure:'Une ronde approche ou tes pas sont trop pressés. Attends une ouverture.'},
  {id:'first-truth',hint:'examine la trace incohérente avant de suivre les marques authentiques',failure:'La fausse piste doit être examinée avant de reconnaître la vraie trace.'},
  {id:'absence-hub',hint:'reste hors de la lumière et laisse un espace entre toi et L’Autre',failure:'La salle vide attend le silence de la lumière et une vraie distance.'},
  {id:'origin-trace',hint:'reviens une fois au premier seuil avec L’Autre avant de poursuivre les traces',failure:'L’origine des traces attend votre retour commun au premier seuil.'},
  {id:'final-crossroads',hint:'explore presque toutes les chambres puis rejoins L’Autre face au dernier choix',failure:'Le carrefour demande que vous ayez parcouru presque toutes ses voies.'}
];
function puzzleDesign(n){if(n===1)return {id:'trace-pc',order:[0,1,2],rules:['free','free','free']};if(n>=37)return {id:`domain-${n}`,order:runeOrders[(n-1)%runeOrders.length],rules:domainPuzzleRules[n-37],mechanic:domainPuzzleMechanics[n-37]};const i=n-2,a=i%8,b=Math.floor(i/8)%8,c=(a+b+1)%8,ids=Object.keys(puzzleRules).filter(key=>key!=='free');let order=runeOrders[i%runeOrders.length],rules=[ids[a],ids[b],ids[c]];if(n===10)rules=['near','wait','call'];if(n===12)order=[2,1,0];if(n===24)rules=['still','walk','still'];return {id:`ritual-${String(n).padStart(2,'0')}`,order,rules,mechanic:middlePuzzleMechanics[i]};}
const roomShapes=['rectangle','octagon','ellipse','cross','hexagon','notch','terrace'];
const domainBlueprints=[
  {id:'plateau-sentinels',cols:7,rows:4,topology:'plateau',shape:'octagon',corridorRadius:1,loops:.18,trapStyle:'sentinel',atmosphere:'cendres et faisceaux de veille'},
  {id:'foret-basalte',cols:5,rows:6,topology:'grove',shape:'ellipse',corridorRadius:1,loops:.22,trapStyle:'racines',atmosphere:'brume verte et troncs de roche'},
  {id:'mer-brumes',cols:8,rows:4,topology:'archipelago',shape:'ellipse',corridorRadius:1,loops:.16,trapStyle:'noyade',atmosphere:'îlots noyés sous les nappes de brume'},
  {id:'bibliotheque-infinie',cols:8,rows:4,topology:'archive',shape:'terrace',corridorRadius:1,loops:.27,trapStyle:'rayonnages',atmosphere:'travées répétées et poussière dorée'},
  {id:'desert-horloges',cols:6,rows:6,topology:'clockwork',shape:'octagon',corridorRadius:1,loops:.22,trapStyle:'engrenages',atmosphere:'cadrans enfouis sous le sable'},
  {id:'jardins-suspendus',cols:5,rows:6,topology:'terraces',shape:'cross',corridorRadius:1,loops:.25,trapStyle:'ronces',atmosphere:'terrasses moussues et racines lumineuses'},
  {id:'marais-reflets',cols:6,rows:5,topology:'marsh',shape:'ellipse',corridorRadius:1,loops:.3,trapStyle:'vase',atmosphere:'eau noire, roseaux et reflets trompeurs'},
  {id:'cite-portes',cols:7,rows:4,topology:'districts',shape:'rectangle',corridorRadius:2,loops:.5,trapStyle:'herses',atmosphere:'places minérales et longues rues de basalte'},
  {id:'profondeurs-cristallines',cols:5,rows:6,topology:'crystal',shape:'hexagon',corridorRadius:1,loops:.2,trapStyle:'cristaux',atmosphere:'cavernes facettées et éclats froids'},
  {id:'faille-silence',cols:6,rows:4,topology:'rift',shape:'notch',corridorRadius:1,loops:.14,trapStyle:'abime',atmosphere:'deux plateaux séparés par le vide'},
  {id:'royaume-golems',cols:6,rows:5,topology:'fortress',shape:'octagon',corridorRadius:1,loops:.25,trapStyle:'seismes',atmosphere:'enceintes concentriques et cours de pierre'},
  {id:'necropole-memoires',cols:5,rows:5,topology:'catacombs',shape:'rectangle',corridorRadius:1,loops:.23,trapStyle:'tombes',atmosphere:'cours funéraires et cryptes en alcôves'},
  {id:'cathedrale-serments',cols:7,rows:5,topology:'nave',shape:'cross',corridorRadius:2,loops:.27,trapStyle:'vitraux',atmosphere:'nef axiale, transepts et chapelles latérales'},
  {id:'dernier-seuil',cols:6,rows:6,topology:'convergence',shape:'hexagon',corridorRadius:1,loops:.21,trapStyle:'fracture',atmosphere:'couronnes de pierre autour du seuil final'}
];
const middleBlueprints=[
  ['trace-loops',5,4,'octagon',.16,'boucles gravées et herse latérale'],
  ['three-forks',5,5,'cross',.12,'deux ailes et un passage transversal'],
  ['mirror-panes',6,4,'ellipse',.12,'moitiés jumelles et faille du reflet'],
  ['cooperation-wings',5,5,'cross',.14,'cour centrale et ailes éloignées'],
  ['detour-u',5,5,'rectangle',.12,'détour en U autour d’une salle close'],
  ['echo-well',5,4,'ellipse',.18,'chambres acoustiques autour du puits'],
  ['sleeping-plates',5,5,'hexagon',.14,'îlots rituels et traverses lumineuses'],
  ['double-courts',6,4,'octagon',.12,'deux cours reliées par une porte étroite'],
  ['three-oaths',5,5,'cross',.12,'trois salles de serment autour d’une cour'],
  ['keyless-ring',5,5,'rectangle',.14,'anneau intérieur et galerie sans serrure'],
  ['reverse-passage',6,5,'notch',.12,'spirale inversée et repères retournés'],
  ['broken-stairs',5,5,'terrace',.12,'terrasses décalées autour du vide'],
  ['silent-clocks',5,5,'octagon',.14,'anneaux et portes d’horloge'],
  ['echo-chambers',6,4,'ellipse',.14,'chambres en écho de tailles croissantes'],
  ['water-reflections',6,4,'ellipse',.14,'galeries jumelles au bord de l’eau'],
  ['lost-relays',5,5,'hexagon',.12,'postes isolés et fils de cuivre'],
  ['forgotten-gardens',5,5,'ellipse',.18,'bosquet ramifié et clairières fleuries'],
  ['stone-watch',5,5,'cross',.12,'place centrale et tours de veille'],
  ['name-gallery',6,4,'rectangle',.12,'nef longitudinale et alcôves de lecture'],
  ['shadow-circle',5,5,'ellipse',.14,'couronnes autour d’un foyer obscur'],
  ['twin-doors',6,4,'rectangle',.14,'voies parallèles et portes jumelles'],
  ['return-circuit',5,5,'octagon',.15,'boucle complète et retour raccourci'],
  ['silent-run',5,5,'notch',0,'parcours sans détour dans les chapelles'],
  ['choice-tree',5,5,'cross',.1,'carrefour à trois branches de décision'],
  ['shifting-grid',6,5,'rectangle',.16,'plans superposés et salles-charnières'],
  ['copper-veins',5,5,'hexagon',.12,'filons ramifiés et bornes de cuivre'],
  ['golem-courts',5,5,'octagon',.15,'cours concentriques autour de la forge'],
  ['watcher-eyes',5,5,'ellipse',.14,'chambres radiales et angles morts'],
  ['trust-rails',6,4,'rectangle',.12,'rails parallèles et salles de rencontre'],
  ['memory-well',5,5,'ellipse',.16,'anneaux descendants et alcôves-mémoire'],
  ['patrol-circuits',6,5,'cross',.14,'circuits croisés autour d’une place sûre'],
  ['first-truth',5,5,'notch',.1,'pistes contradictoires et axe authentique'],
  ['absence-hub',5,5,'ellipse',.12,'cour centrale vide et anneau de marques'],
  ['origin-trace',6,4,'terrace',.14,'chemin ancien superposé au chemin présent'],
  ['final-crossroads',5,5,'cross',.16,'routes réunies dans une grande chambre']
].map(([topology,cols,rows,shape,loops,atmosphere],i)=>({id:`chapter-${String(i+2).padStart(2,'0')}`,cols,rows,topology,shape,corridorRadius:i%9===3?2:1,loops,phase:i,trapStyle:`stone-${i+2}`,atmosphere}));
const trapNames={sentinel:'rayon de veille',racines:'racine de basalte',noyade:'dalle noyée',rayonnages:'presse d’archives',engrenages:'engrenage enfoui',ronces:'ronce runique',vase:'mare de vase',herses:'herse de pierre',cristaux:'éclat cristallin',abime:'faille dissimulée',seismes:'dalle sismique',tombes:'sarcophage piégé',vitraux:'vitrail brisé',fracture:'fracture du seuil'};
const trapEffectProfiles={
  sentinel:{slowDuration:3.2,slowFactor:.68,alarmRadius:15,alarmDuration:2.2},
  racines:{slowDuration:5.8,slowFactor:.42,alarmRadius:9,alarmDuration:1.3},
  noyade:{slowDuration:5.4,slowFactor:.5,alarmRadius:10,alarmDuration:1.5},
  rayonnages:{slowDuration:3.4,slowFactor:.62,alarmRadius:8,alarmDuration:2.2},
  engrenages:{slowDuration:2.6,slowFactor:.48,alarmRadius:12,alarmDuration:1.4},
  ronces:{slowDuration:6.2,slowFactor:.4,alarmRadius:10,alarmDuration:1.2},
  vase:{slowDuration:6.6,slowFactor:.38,alarmRadius:7.5,alarmDuration:1.65},
  herses:{slowDuration:3.8,slowFactor:.58,alarmRadius:14,alarmDuration:2},
  cristaux:{slowDuration:4.1,slowFactor:.56,alarmRadius:12,alarmDuration:1.85},
  abime:{slowDuration:5,slowFactor:.52,alarmRadius:7,alarmDuration:1},
  seismes:{slowDuration:2.4,slowFactor:.45,alarmRadius:13,alarmDuration:2.1},
  tombes:{slowDuration:5.5,slowFactor:.49,alarmRadius:8.5,alarmDuration:2.35},
  vitraux:{slowDuration:3,slowFactor:.4,alarmRadius:11,alarmDuration:2.6},
  fracture:{slowDuration:4.8,slowFactor:.47,alarmRadius:9.5,alarmDuration:1.75}
};
const middleTrapNames=['herse de fausse trace','dalle de bifurcation','éclat de miroir noir','plaque de serment','faille de détour','cloche d’écho','dalle dormante','fosse des salles jumelles','pierre de serment','verrou sans clé','marche inversée','pierre d’escalier fendue','roue d’horloge','cloche à retardement','mare de reflet','fil de relais coupant','ronce de jardin','rayon de tour','tablette coulissante','ombre mouvante','herse jumelle','dalle de retour','rune sonore','porte de décision','mur mobile','impulsion de cuivre','dalle de forge','faisceau des yeux','rail de confiance','sarcophage d’écho','ronde de sentinelles','trace contradictoire','puits d’absence','faille des origines','fracture du carrefour'];
for(let i=0;i<middleTrapNames.length;i++)trapNames[`stone-${i+2}`]=middleTrapNames[i];
function mazeBlueprint(n){if(n===1)return {id:'trace-pc',cols:5,rows:4,topology:'handcrafted',shape:'rectangle',corridorRadius:1,loops:0,phase:0,trapStyle:'trace',atmosphere:'plan PC conservé'};if(n>=37)return {...domainBlueprints[n-37],phase:n-37};return {...middleBlueprints[n-2]};}
function rotateHue(hex,turn){const raw=hex.slice(1),r=parseInt(raw.slice(0,2),16)/255,g=parseInt(raw.slice(2,4),16)/255,b=parseInt(raw.slice(4,6),16)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,l=(max+min)/2;let h=0,s=0;if(d){s=l>.5?d/(2-max-min):d/(max+min);if(max===r)h=(g-b)/d+(g<b?6:0);else if(max===g)h=(b-r)/d+2;else h=(r-g)/d+4;h/=6;}h=(h+turn/360)%1;const hue2rgb=(p,q,t)=>{if(t<0)t++;if(t>1)t--;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;};const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,toHex=x=>Math.round(x*255).toString(16).padStart(2,'0');return '#'+toHex(hue2rgb(p,q,h+1/3))+toHex(hue2rgb(p,q,h))+toHex(hue2rgb(p,q,h-1/3));}
function middlePalette(n){const i=n-2,base=themes[(n-1)%themes.length],turn=(i*17)%360;return {...base,n:chapterNames[n-1],floor:rotateHue(base.floor,turn),wall:rotateHue(base.wall,turn),edge:rotateHue(base.edge,turn),accent:rotateHue(base.accent,turn),mist:rotateHue(base.mist,turn),detail:rotateHue(base.detail,turn)};}
function chapter(n){if(n<1||n>50)throw Error('chapitre hors limites');const huge=n>36,t=huge?epicThemes[n-37]:n===1?themes[0]:middlePalette(n);return {n,name:chapterNames[n-1],kind:huge?'domaine':'labyrinthe',size:huge?'Immense':'Labyrinthe',palette:t,theme:t.n,mode:['glyph','memory','relay','mirror','glyph','relay','memory','mirror'][(n-1)%8],puzzle:puzzleDesign(n),maze:mazeBlueprint(n),behavior:behaviors[(n-1)%behaviors.length],description:huge?epicDescriptions[n-37]:descriptions[n-1],lore:huge?`Fragment ${String(n).padStart(2,'0')} : ${epicLore[n-37]}`:`Fragment ${String(n).padStart(2,'0')} : ${labyrinthLore[n-1]}`,enemySet:n<3?['sentry']:n<10?['sentry','patrol']:n<25?['sentry','patrol','golem']:['sentry','patrol','golem'],special:n===50?'warden':null};}
function rand(seed){let s=(seed>>>0)||1;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};}
const shuffle=(list,r)=>{for(let i=list.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[list[i],list[j]]=[list[j],list[i]];}return list;};
function inside(w,h,x,y){return x>0&&y>0&&x<w-1&&y<h-1;}
function bfs(tiles,w,h,start){const seen=new Int32Array(w*h).fill(-1),queue=[start];seen[start[1]*w+start[0]]=0;let head=0;while(head<queue.length){const [x,y]=queue[head++],d=seen[y*w+x]+1;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const xx=x+dx,yy=y+dy;if(!inside(w,h,xx,yy)||tiles[yy*w+xx]||seen[yy*w+xx]>=0)continue;seen[yy*w+xx]=d;queue.push([xx,yy]);}}return {seen,queue};}
// Trace, based on the hand-authored PC chapter of the same campaign.
function firstThreshold() {
  const w = 48, h = 36;
  const tiles = new Uint8Array(w * h).fill(1);
  const rooms = [
    {id:'meeting', x:2, y:14, w:12, h:10},
    {id:'gallery', x:16, y:2, w:13, h:11},
    {id:'crossing', x:33, y:14, w:13, h:10},
    {id:'reunion', x:16, y:24, w:13, h:11},
    {id:'niche', x:2, y:2, w:10, h:8}
  ];
  const routes = [
    [[12,17],[14,17],[14,9],[17,9]],
    [[27,9],[30,9],[30,17],[34,17]],
    [[39,22],[39,27],[27,27]],
    [[17,30],[13,30],[13,20],[12,20]],
    [[5,15],[5,11],[5,8]]
  ];
  const clear = (x, y) => { tiles[y * w + x] = 0; };
  for (const room of rooms) {
    for (let y = room.y + 1; y < room.y + room.h - 1; y++) {
      for (let x = room.x + 1; x < room.x + room.w - 1; x++) clear(x, y);
    }
  }
  for (const route of routes) {
    for (let i = 1; i < route.length; i++) {
      let [x,y] = route[i - 1];
      const [endX,endY] = route[i];
      const dx = Math.sign(endX - x), dy = Math.sign(endY - y);
      const width = Math.abs(endX - x) + Math.abs(endY - y);
      for (let step = 0; step <= width; step++, x += dx, y += dy) {
        for (let yy = -1; yy <= 1; yy++) {
          for (let xx = -1; xx <= 1; xx++) clear(x + xx, y + yy);
        }
      }
    }
  }
  for (let y = 5; y < 9; y++) tiles[y * w + 23] = 1;
  return {
    ...chapter(1), w, h, tiles, rooms, layout:'trace-pc', start:[7,19], companion:[8,20],
    runes:[[14,13],[20,7],[37,17]], exit:[22,29], secret:[5,5], decoy:[15,11],
    traps:[[15,10],[38,19],[27,28],[11,17]],
    torches:[[4,18],[11,16],[14,15],[18,5],[27,9],[30,14],[34,17],[41,19],[38,25],[22,27],[7,7]],
    enemies:[{id:0,kind:'sentry',x:43.5,y:20.5,home:[43.5,20.5],heading:2.8,seed:5,speed:.8,patrolPhase:0,alert:0}],
    seed:92178
  };
}
function spiralGridOrder(cols,rows){const out=[];let left=0,right=cols-1,top=0,bottom=rows-1;while(left<=right&&top<=bottom){for(let c=left;c<=right;c++)out.push([c,top]);top++;for(let r=top;r<=bottom;r++)out.push([right,r]);right--;if(top<=bottom){for(let c=right;c>=left;c--)out.push([c,bottom]);bottom--;}if(left<=right){for(let r=bottom;r>=top;r--)out.push([left,r]);left++;}}return out;}
function buildRoomEdges(profile,cols,rows,r){
  const edges=[],seen=new Set(),key=(a,b)=>a[1]*cols+a[0]+'>'+b[1]*cols+b[0];
  const add=(a,b)=>{if(!a||!b||a[0]<0||a[1]<0||b[0]<0||b[1]<0||a[0]>=cols||b[0]>=cols||a[1]>=rows||b[1]>=rows||(a[0]===b[0]&&a[1]===b[1]))return;const ia=a[1]*cols+a[0],ib=b[1]*cols+b[0],pair=ia<ib?`${ia}:${ib}`:`${ib}:${ia}`;if(!seen.has(pair)){seen.add(pair);edges.push([a,b]);}};
  const H=(c,row)=>add([c,row],[c+1,row]),V=(col,row)=>add([col,row],[col,row+1]),phase=profile.phase||0;
  const snake=()=>{for(let row=0;row<rows;row++){if(row%2===0){for(let col=0;col<cols-1;col++)H(col,row);}else{for(let col=cols-2;col>=0;col--)H(col,row);}if(row<rows-1)V(row%2===0?cols-1:0,row);}};
  const columnSnake=()=>{for(let col=0;col<cols;col++){if(col%2===0){for(let row=0;row<rows-1;row++)V(col,row);}else{for(let row=rows-2;row>=0;row--)V(col,row);}if(col<cols-1)H(col%2===0?col:col,col%2===0?rows-1:0);}};
  const grid=()=>{for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){if(col<cols-1)H(col,row);if(row<rows-1)V(col,row);}};
  const ring=(left,top,right,bottom)=>{if(left>right||top>bottom)return;for(let c=left;c<right;c++)add([c,top],[c+1,top]);for(let y=top;y<bottom;y++)add([right,y],[right,y+1]);if(bottom>top)for(let c=right;c>left;c--)add([c,bottom],[c-1,bottom]);if(right>left)for(let y=bottom;y>top;y--)add([left,y],[left,y-1]);};
  const route=order=>{for(let i=1;i<order.length;i++)add(order[i-1],order[i]);};
  const columnRange=(left,right)=>{const order=[];for(let col=left;col<=right;col++){if((col-left)%2===0){for(let row=0;row<rows;row++)order.push([col,row]);}else{for(let row=rows-1;row>=0;row--)order.push([col,row]);}}route(order);};
  const rowRange=(top,bottom)=>{const order=[];for(let row=top;row<=bottom;row++){if((row-top)%2===0){for(let col=0;col<cols;col++)order.push([col,row]);}else{for(let col=cols-1;col>=0;col--)order.push([col,row]);}}route(order);};
  switch(profile.topology){
    case 'trace-loops':{ring(0,0,cols-1,rows-1);if(cols>3&&rows>3)ring(1,1,cols-2,rows-2);for(let row=0;row<rows;row+=2)add([0,row],[1,row]);break;}
    case 'three-forks':{const trunk=Math.floor(cols/2);for(let row=0;row<rows-1;row++)V(trunk,row);for(const row of [0,Math.floor((rows-1)/2),rows-1]){for(let col=0;col<cols-1;col++)H(col,row);}break;}
    case 'mirror-panes':{const spine=Math.floor(cols/2);for(let row=0;row<rows-1;row++)V(spine,row);for(let row=0;row<rows;row++){for(let col=0;col<spine;col++)if((row+col+phase)%2===0)H(col,row);for(let col=spine;col<cols-1;col++)if((row+cols-col+phase)%2===0)H(col,row);}for(let row=phase%2;row<rows;row+=2)V(Math.max(0,spine-1),row);break;}
    case 'cooperation-wings':{rowRange(Math.floor(rows/2),Math.floor(rows/2));for(let col=0;col<cols;col++){for(let row=0;row<Math.floor(rows/2);row++)V(col,row);for(let row=Math.floor(rows/2);row<rows-1;row++)V(col,row);}for(let col=0;col<cols-1;col++)if(col%2===phase%2){H(col,0);H(col,rows-1);}break;}
    case 'detour-u':{const order=[];for(let row=0;row<rows;row++)order.push([0,row]);for(let col=1;col<cols;col++)order.push([col,rows-1]);for(let row=rows-2;row>=0;row--)order.push([cols-1,row]);for(let col=cols-2;col>0;col--)add([col,rows-2],[col,rows-1]);route(order);break;}
    case 'echo-well':{const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=0;row<rows;row++)for(let col=0;col<cols;col++)if((row+col+phase)%2===0)add(center,[col,row]);ring(0,0,cols-1,rows-1);break;}
    case 'sleeping-plates':{snake();for(let row=phase%2;row<rows-1;row+=2){const col=(row+phase)%cols;V(col,row);if(col+2<cols)V(col+2,row);}break;}
    case 'double-courts':{const split=Math.floor(cols/2);columnRange(0,split-1);columnRange(split,cols-1);for(let row=0;row<rows;row+=Math.max(1,rows-1))add([split-1,row],[split,row]);break;}
    case 'three-oaths':{const trunk=Math.floor(cols/2),middle=Math.floor(rows/2);for(let row=0;row<rows-1;row++)V(trunk,row);for(const row of [0,middle,rows-1])for(let col=0;col<cols-1;col++)H(col,row);for(let col=0;col<cols-1;col++)if(col%2===phase%2)H(col,middle);break;}
    case 'keyless-ring':{ring(0,0,cols-1,rows-1);const inner=spiralGridOrder(Math.max(1,cols-2),Math.max(1,rows-2)).map(([c,y])=>[c+1,y+1]);route(inner);add([0,Math.floor(rows/2)],[1,Math.floor(rows/2)]);add([cols-1,Math.floor(rows/2)],[cols-2,Math.floor(rows/2)]);break;}
    case 'reverse-passage':{route(spiralGridOrder(cols,rows).reverse());for(let row=0;row<rows;row++)if((row+phase)%2===0)add([0,row],[cols-1,rows-1-row%rows]);for(let col=0;col<cols;col++)if(col%3===phase%3)V(col,Math.floor((rows-1)/2));break;}
    case 'broken-stairs':{const order=[];for(let row=0;row<rows;row++){const start=(row+phase)%2?cols-1:0,end=(row+phase)%2?0:cols-1,step=Math.sign(end-start)||1;for(let col=start;;col+=step){order.push([col,row]);if(col===end)break;}}route(order);for(let row=0;row<rows-1;row++){const stair=(row+phase)%cols;V(stair,row);}break;}
    case 'silent-clocks':{for(let layer=0;layer<Math.ceil(Math.min(cols,rows)/2);layer++)ring(layer,layer,cols-1-layer,rows-1-layer);const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=phase%2;row<rows;row+=2)add(center,[0,row]);for(let col=(phase+1)%2;col<cols;col+=2)add(center,[col,0]);break;}
    case 'echo-chambers':{route(spiralGridOrder(cols,rows));const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let i=0;i<cols;i+=2)add(center,[i,Math.floor(rows/2)]);for(let row=0;row<rows;row++)if(row%2===phase%2)add([0,row],[Math.min(1,cols-1),row]);break;}
    case 'water-reflections':{const split=Math.floor(cols/2);columnRange(0,split-1);columnRange(split,cols-1);for(let row=phase%2;row<rows;row+=2)add([split-1,row],[split,row]);for(let col=0;col<cols-1;col++)if(col%2===0)V(col,Math.floor((rows-1)/2));break;}
    case 'lost-relays':{const middle=Math.floor(rows/2);for(let col=0;col<cols-1;col++)H(col,middle);for(let col=0;col<cols;col++){if(col%2===0){for(let row=0;row<middle;row++)V(col,row);}else{for(let row=middle;row<rows-1;row++)V(col,row);}}for(let row=0;row<rows;row++)if(row===0||row===rows-1)for(let col=0;col<cols-1;col+=2)H(col,row);break;}
    case 'forgotten-gardens':{route(spiralGridOrder(cols,rows));for(let row=0;row<rows;row++)for(let col=0;col<cols-1;col++)if((row*3+col+phase)%5===0)H(col,row);for(let row=0;row<rows-1;row++)for(let col=0;col<cols;col++)if((row+col*2+phase)%6===0)V(col,row);break;}
    case 'stone-watch':{const midC=Math.floor(cols/2),midR=Math.floor(rows/2);for(let row=0;row<rows-1;row++)V(midC,row);for(let col=0;col<cols-1;col++)H(col,midR);for(let col=0;col<cols;col++)for(let row=0;row<rows;row++)if(col!==midC&&row!==midR)add([col,row],[midC,row]);break;}
    case 'name-gallery':{const axis=Math.floor(rows/2);for(let col=0;col<cols-1;col++)H(col,axis);for(let col=0;col<cols;col+=2){for(let row=0;row<rows-1;row++)V(col,row);}for(let row=phase%2;row<rows;row+=2)for(let col=0;col<cols-1;col++)if((col+row)%3===0)H(col,row);break;}
    case 'shadow-circle':{for(let layer=0;layer<Math.ceil(Math.min(cols,rows)/2);layer++){const skip=(layer+phase)%4;let points=[];for(let col=layer;col<=cols-1-layer;col++)points.push([col,layer]);for(let row=layer+1;row<=rows-1-layer;row++)points.push([cols-1-layer,row]);for(let col=cols-2-layer;col>=layer;col--)points.push([col,rows-1-layer]);for(let row=rows-2-layer;row>layer;row--)points.push([layer,row]);const kept=points.filter((_,i)=>i%Math.max(3,points.length)!==skip);route(kept);if(points.length)add(points[0],points[points.length-1]);}route(spiralGridOrder(cols,rows));break;}
    case 'twin-doors':{const upper=Math.max(0,Math.floor(rows/2)-1),lower=Math.min(rows-1,upper+1);rowRange(upper,upper);rowRange(lower,lower);for(const col of [0,Math.floor((cols-1)/2),cols-1])add([col,upper],[col,lower]);for(let row=0;row<rows-1;row++)if(row!==upper)V(phase%2?cols-1:0,row);break;}
    case 'return-circuit':{ring(0,0,cols-1,rows-1);if(cols>3&&rows>3)ring(1,1,cols-2,rows-2);for(const row of [0,rows-1])add([Math.floor((cols-1)/2),row],[Math.floor((cols-1)/2),row===0?1:rows-2]);break;}
    case 'silent-run':{columnSnake();break;}
    case 'choice-tree':{const trunk=Math.floor(cols/2),middle=Math.floor(rows/2);for(let row=0;row<rows-1;row++)V(trunk,row);for(const [start,end,row] of [[0,trunk,0],[trunk,cols-1,middle],[0,trunk,rows-1]])for(let col=start;col<end;col++)H(col,row);for(let col=0;col<cols;col++)if(col!==trunk){const target=col<trunk?0:rows-1;for(let row=Math.min(target,middle);row<Math.max(target,middle);row++)if(col%2===phase%2)V(col,row);}break;}
    case 'shifting-grid':{snake();for(let row=0;row<rows-1;row++){const col=(phase+row*2)%cols;V(col,row);if(cols>4)V((col+Math.floor(cols/2))%cols,row);}for(let col=phase%2;col<cols-1;col+=2)H(col,Math.floor((rows-1)/2));break;}
    case 'copper-veins':{columnSnake();for(let row=0;row<rows;row++)for(let col=0;col<cols-1;col++)if((col+row*2+phase)%4===0)H(col,row);for(let col=0;col<cols;col++)if((col+phase)%3===0)V(col,Math.floor((rows-1)/2));break;}
    case 'golem-courts':{ring(0,0,cols-1,rows-1);if(cols>3&&rows>3)ring(1,1,cols-2,rows-2);const midC=Math.floor(cols/2),midR=Math.floor(rows/2);for(let col=0;col<cols-1;col++)H(col,midR);for(let row=0;row<rows-1;row++)V(midC,row);break;}
    case 'watcher-eyes':{const center=[Math.floor(cols/2),Math.floor(rows/2)];ring(0,0,cols-1,rows-1);for(let row=0;row<rows;row++)for(let col=0;col<cols;col++)if((row===0||row===rows-1||col===0||col===cols-1)&&((row+col+phase)%2===0))add(center,[col,row]);route(spiralGridOrder(cols,rows));break;}
    case 'trust-rails':{const upper=0,lower=rows-1;for(let col=0;col<cols-1;col++){H(col,upper);H(col,lower);}for(const col of [0,Math.floor((cols-1)/2),cols-1])for(let row=0;row<rows-1;row++)if(col===0||col===cols-1||row===Math.floor(rows/2))V(col,row);for(let row=1;row<rows-1;row++)if(row%2===phase%2)H(0,row);break;}
    case 'memory-well':{route(spiralGridOrder(cols,rows));for(let layer=0;layer<Math.ceil(Math.min(cols,rows)/2);layer++){if(layer%2===phase%2)ring(layer,layer,cols-1-layer,rows-1-layer);}const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=0;row<rows;row+=2)add(center,[Math.floor(cols/2),row]);break;}
    case 'patrol-circuits':{for(let row=0;row<rows;row+=2)ring(0,row,cols-1,Math.min(rows-1,row+1));for(let col=0;col<cols-1;col++)H(col,Math.floor(rows/2));for(let row=0;row<rows-1;row++)V(Math.floor(cols/2),row);route(spiralGridOrder(cols,rows));break;}
    case 'first-truth':{const spine=Math.floor(cols/2);for(let row=0;row<rows-1;row++)V(spine,row);for(let row=0;row<rows;row++){const ends=row%2===phase%2?[0,spine]:[spine,cols-1];for(let col=ends[0];col<ends[1];col++)H(col,row);}for(let row=1;row<rows-1;row+=2)if(row!==Math.floor(rows/2))H(0,row);break;}
    case 'absence-hub':{const midC=Math.floor(cols/2),midR=Math.floor(rows/2);ring(0,0,cols-1,rows-1);for(let col=0;col<cols;col++)if(col!==midC)add([col,0],[col,Math.max(0,midR-1)]);for(let row=0;row<rows;row++)if(row!==midR)add([0,row],[Math.max(0,midC-1),row]);for(let col=0;col<cols-1;col++)if(col%2===phase%2)H(col,midR);for(let row=0;row<rows-1;row++)if(row%2!==phase%2)V(midC,row);break;}
    case 'origin-trace':{snake();const spiral=spiralGridOrder(cols,rows);for(let i=0;i<spiral.length-1;i+=2)add(spiral[i],spiral[i+1]);for(let row=phase%2;row<rows-1;row+=2){const col=(row+phase)%cols;V(col,row);}break;}
    case 'final-crossroads':{const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=0;row<rows;row++)add(center,[0,row]);for(let row=0;row<rows;row++)add(center,[cols-1,row]);for(let col=0;col<cols;col++)add(center,[col,0]);for(let col=0;col<cols;col++)add(center,[col,rows-1]);ring(0,0,cols-1,rows-1);break;}
    case 'plateau':{const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=0;row<rows;row++)for(let col=0;col<cols;col++)add(center,[col,row]);ring(0,0,cols-1,rows-1);for(let col=0;col<cols;col++)V(col,Math.floor((rows-1)/2));break;}
    case 'grove':{const start=[phase%cols,Math.floor(rows/2)],stack=[start],visited=new Set([start[1]*cols+start[0]]);while(stack.length){const cur=stack[stack.length-1],next=shuffle([[cur[0]+1,cur[1]],[cur[0]-1,cur[1]],[cur[0],cur[1]+1],[cur[0],cur[1]-1]].filter(([c,y])=>c>=0&&y>=0&&c<cols&&y<rows&&!visited.has(y*cols+c)),r)[0];if(!next){stack.pop();continue;}add(cur,next);visited.add(next[1]*cols+next[0]);stack.push(next);}break;}
    case 'archipelago':{const islandCols=Math.ceil(cols/2),islandRows=Math.ceil(rows/2);for(let islandRow=0;islandRow<islandRows;islandRow++)for(let islandCol=0;islandCol<islandCols;islandCol++){const left=islandCol*2,top=islandRow*2,right=Math.min(cols-1,left+1),bottom=Math.min(rows-1,top+1);if(left<right){H(left,top);if(top<bottom)H(left,bottom);}if(top<bottom){V(left,top);if(left<right)V(right,top);}}for(let islandRow=0;islandRow<islandRows;islandRow++)for(let islandCol=0;islandCol<islandCols-1;islandCol++){const row=islandRow*2+((islandCol+islandRow+phase)%2),left=islandCol*2+1,right=left+1;if(left<cols-1&&row<rows)add([left,row],[right,row]);}for(let islandCol=0;islandCol<islandCols;islandCol++){const col=islandCol*2+((islandCol+phase)%2),top=islandRows>1?1:-1;if(top>=0&&top+1<rows&&col<cols)add([col,top],[col,top+1]);}break;}
    case 'archive':{for(let row=0;row<rows;row++)for(let col=0;col<cols-1;col++)H(col,row);for(let row=0;row<rows-1;row++){const col=(phase+row*2)%cols;V(col,row);if((row+phase)%2===0)V((col+Math.floor(cols/2))%cols,row);}break;}
    case 'clockwork':{for(let layer=0;layer<Math.ceil(Math.min(cols,rows)/2);layer++)ring(layer,layer,cols-1-layer,rows-1-layer);const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let col=0;col<cols;col++)if((col+phase)%2===0)add(center,[col,0]);for(let row=0;row<rows;row++)if((row+phase)%2===0)add(center,[0,row]);break;}
    case 'terraces':{snake();for(let row=0;row<rows-1;row++){const col=(phase+row*2)%cols;V(col,row);if(cols>4)V((col+2)%cols,row);}break;}
    case 'marsh':{snake();for(let row=0;row<rows;row++)for(let col=0;col<cols-1;col++)if((row+col+phase)%3===0)H(col,row);for(let row=0;row<rows-1;row++)for(let col=0;col<cols;col++)if((row*2+col+phase)%4===0)V(col,row);break;}
    case 'districts':grid();break;
    case 'crystal':{const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let row=0;row<rows;row++)for(let col=0;col<cols;col++)add(center,[col,row]);for(let layer=0;layer<Math.ceil(Math.min(cols,rows)/2);layer++)ring(layer,layer,cols-1-layer,rows-1-layer);break;}
    case 'rift':{const split=Math.floor(cols/2);for(let row=0;row<rows;row++)for(let col=0;col<cols-1;col++)if((col<split-1)||(col>=split))H(col,row);for(let row=0;row<rows-1;row++)for(let col=0;col<cols;col++)V(col,row);const bridges=[0,Math.floor((rows-1)/2),rows-1];for(let i=0;i<bridges.length;i++){const row=(bridges[i]+phase)%rows;add([split-1,row],[split,row]);}break;}
    case 'fortress':{ring(0,0,cols-1,rows-1);if(cols>3&&rows>3){ring(1,1,cols-2,rows-2);for(let col=1;col<cols-1;col+=2){V(col,0);V(col,rows-2);}for(let row=1;row<rows-1;row+=2){H(0,row);H(cols-2,row);}}const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let col=1;col<cols-1;col++)add(center,[col,Math.floor(rows/2)]);break;}
    case 'catacombs':{const blockCols=Math.ceil(cols/2),blockRows=Math.ceil(rows/2);for(let br=0;br<blockRows;br++)for(let bc=0;bc<blockCols;bc++){const l=bc*2,t=br*2,rr=Math.min(cols-1,l+1),bb=Math.min(rows-1,t+1);if(l<rr)H(l,t);if(t<bb)V(l,t);if(l<rr&&t<bb){H(l,bb);V(rr,t);}}const blocks=[];for(let br=0;br<blockRows;br++){const row=[];for(let bc=0;bc<blockCols;bc++)row.push([bc,br]);if(br%2)row.reverse();blocks.push(...row);}for(let i=1;i<blocks.length;i++){const [bc,br]=blocks[i],[pc,pr]=blocks[i-1];if(bc!==pc){const y=br*2;add([Math.min(bc,pc)*2+1,y],[Math.min(bc,pc)*2+2,y]);}else{const x=bc*2;add([x,Math.min(br,pr)*2+1],[x,Math.min(br,pr)*2+2]);}}break;}
    case 'nave':{const midC=Math.floor(cols/2),midR=Math.floor(rows/2);for(let col=0;col<cols-1;col++)H(col,midR);for(let row=0;row<rows-1;row++)V(midC,row);for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){if(col!==midC)add([col,row],[midC,row]);if(row!==midR)add([col,row],[col,midR]);}break;}
    case 'convergence':{const order=spiralGridOrder(cols,rows);for(let i=1;i<order.length;i++)add(order[i-1],order[i]);const center=[Math.floor(cols/2),Math.floor(rows/2)];for(let i=0;i<order.length;i+=Math.max(2,Math.floor(order.length/6)))add(center,order[i]);ring(0,0,cols-1,rows-1);break;}
    default:snake();break;
  }
  // Every room graph must remain navigable even when a chapter's silhouette
  // intentionally separates wings, courts or galleries.
  const roomCount=cols*rows,adjacency=()=>{const links=Array.from({length:roomCount},()=>[]);for(const [a,b] of edges){const ia=a[1]*cols+a[0],ib=b[1]*cols+b[0];links[ia].push(ib);links[ib].push(ia);}return links;};
  let links=adjacency(),reachable=new Uint8Array(roomCount),queue=[0];reachable[0]=1;for(let head=0;head<queue.length;head++)for(const next of links[queue[head]])if(!reachable[next]){reachable[next]=1;queue.push(next);}
  while(queue.length<roomCount){let bridged=false;for(let row=0;row<rows&&!bridged;row++)for(let col=0;col<cols&&!bridged;col++){const index=row*cols+col;if(reachable[index])continue;for(const [nc,nr] of [[col-1,row],[col+1,row],[col,row-1],[col,row+1]])if(nc>=0&&nr>=0&&nc<cols&&nr<rows&&reachable[nr*cols+nc]){add([col,row],[nc,nr]);bridged=true;break;}}if(!bridged)break;links=adjacency();for(let i=0;i<roomCount;i++)reachable[i]=0;queue=[0];reachable[0]=1;for(let head=0;head<queue.length;head++)for(const next of links[queue[head]])if(!reachable[next]){reachable[next]=1;queue.push(next);}}
  // Seeded side passages add alternate routes while each chapter keeps its own topology.
  if(!['districts','rift','archive','silent-run','archipelago'].includes(profile.topology)){for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){if(col<cols-1&&r()<profile.loops)H(col,row);if(row<rows-1&&r()<profile.loops)V(col,row);}}
  return edges;
}
function roomShapeContains(shape,dx,dy,w,h){const x=Math.abs(dx)/(Math.max(1,w-1)/2),y=Math.abs(dy)/(Math.max(1,h-1)/2);if(shape==='octagon')return !(x>.58&&y>.58);if(shape==='ellipse')return x*x+y*y<=1.08;if(shape==='cross')return x<=.42||y<=.42;if(shape==='hexagon')return x*.86+y<=1.42;if(shape==='notch')return x+y<=1.48||x<=.35||y<=.35;if(shape==='terrace')return y<.62||x<=.68;return true;}
function generate(n){if(n===1)return firstThreshold();const ch=chapter(n),r=rand(n*90467+1711),huge=n>36;
const w=huge?75+(n%4)*8:35+(n%4)*4,h=huge?67+(n%3)*8:35+(n%3)*6;
const tiles=new Uint8Array(w*h).fill(1),set=(x,y,v=0)=>{if(inside(w,h,x,y))tiles[y*w+x]=v;};
// Room-first layouts: broad chambers are the play space; short, 2–3 tile
// passages connect them. A connected graph keeps routes readable but not linear.
const blueprint=ch.maze,cols=blueprint.cols,rows=blueprint.rows,cellW=(w-2)/cols,cellH=(h-2)/rows;
const rooms=[],roomOwner=new Int16Array(w*h).fill(-1),roomAt=(col,row)=>rooms[row*cols+col];
for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
  const left=1+Math.floor(col*cellW),top=1+Math.floor(row*cellH);
  const right=col===cols-1?w-1:1+Math.floor((col+1)*cellW),bottom=row===rows-1?h-1:1+Math.floor((row+1)*cellH);
  const availW=right-left,availH=bottom-top;
  const minW=huge?7:4,minH=huge?6:4;
  const rw=Math.max(3,Math.min(availW-1,minW+Math.floor(r()*(huge?5:3)))),rh=Math.max(3,Math.min(availH-1,minH+Math.floor(r()*(huge?5:3))));
  const cx=left+Math.floor(availW/2),cy=top+Math.floor(availH/2);
  const x=Math.max(left+1,Math.min(right-rw-1,cx-Math.floor(rw/2))),y=Math.max(top+1,Math.min(bottom-rh-1,cy-Math.floor(rh/2)));
  const room={id:['meeting','gallery','crossing','reunion','niche'][(row*cols+col+n)%5],x,y,w:rw,h:rh,cx,cy,shape:blueprint.shape,feature:(row*cols+col+n)%7===2,depth:(row*cols+col+blueprint.phase)%Math.max(7,Math.floor(cols*rows/4))===Math.floor(cols*rows/4)-1};
  const roomIndex=rooms.length;rooms.push(room);for(let yy=y;yy<y+rh;yy++)for(let xx=x;xx<x+rw;xx++)if(roomShapeContains(blueprint.shape,xx-cx,yy-cy,rw,rh)){set(xx,yy);roomOwner[yy*w+xx]=roomIndex;}
}
function carveHall(a,b){let x=a.cx,y=a.cy;const radius=blueprint.corridorRadius;const horizontal=()=>{const step=Math.sign(b.cx-x);while(step&&x!==b.cx){for(let off=-radius;off<=radius;off++)set(x,y+off);x+=step;}for(let off=-radius;off<=radius;off++)set(x,y+off);};const vertical=()=>{const step=Math.sign(b.cy-y);while(step&&y!==b.cy){for(let off=-radius;off<=radius;off++)set(x+off,y);y+=step;}for(let off=-radius;off<=radius;off++)set(x+off,y);};if(r()<.5){horizontal();vertical();}else{vertical();horizontal();}}
// Each chapter uses its own room graph: radial plateau, winding grove,
// archipelago, archive aisles, clockwork rings, terraces, marsh braids,
// open districts, crystal hub, split rift, fortress rings, catacombs, nave,
// or a final spiral convergence.
const edges=buildRoomEdges(blueprint,cols,rows,r);
for(const [[c1,r1],[c2,r2]] of edges)carveHall(roomAt(c1,r1),roomAt(c2,r2));
// Room metadata also drives optional landmark dressing and depth-camera beats.
const start=[rooms[0].cx,rooms[0].cy];
const {seen,queue}=bfs(tiles,w,h,start);let unreachable=0;for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++)if(!tiles[y*w+x]&&seen[y*w+x]===-1)unreachable++;
// Rare isolated cleared areas are connected to the main maze by a straight safe corridor.
if(unreachable){for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++)if(!tiles[y*w+x]&&seen[y*w+x]===-1){let xx=x;while(xx>1){set(xx,y);xx--;}let yy=y;while(yy>1){set(1,yy);yy--;}}}
const distances=bfs(tiles,w,h,start),chamberCells=distances.queue.filter(p=>roomOwner[p[1]*w+p[0]]>=0);let exitDistance=-1;for(const point of chamberCells)exitDistance=Math.max(exitDistance,distances.seen[point[1]*w+point[0]]);const exitPool=chamberCells.filter(p=>distances.seen[p[1]*w+p[0]]>=exitDistance*.88),exit=exitPool[Math.floor(r()*exitPool.length)]||[rooms[rooms.length-1].cx,rooms[rooms.length-1].cy],exitRoomIndex=roomOwner[exit[1]*w+exit[0]],reserved=[start,exit],usedRooms=new Set([0,exitRoomIndex]);
function pick(minDistance=5,preferFar=true){const minFromStart=minDistance,farLimit=exitDistance*.25;let candidates=distances.queue.filter(p=>distances.seen[p[1]*w+p[0]]>minFromStart);if(preferFar){const far=candidates.filter(p=>distances.seen[p[1]*w+p[0]]>=farLimit);if(far.length)candidates=far;}let p=null;for(let attempt=0;attempt<Math.min(256,candidates.length);attempt++){const q=candidates[Math.floor(r()*candidates.length)];if(!reserved.some(v=>Math.abs(v[0]-q[0])+Math.abs(v[1]-q[1])<5)){p=q;break;}}if(!p)p=candidates.find(q=>!reserved.some(v=>q[0]===v[0]&&q[1]===v[1]))||start;reserved.push(p);return [...p];}
function pickInRoom(room,minDistance=6){let candidates=[];for(let y=room.y;y<room.y+room.h;y++)for(let x=room.x;x<room.x+room.w;x++)if(!tiles[y*w+x]&&distances.seen[y*w+x]>minDistance)candidates.push([x,y]);let separated=candidates.filter(p=>!reserved.some(v=>Math.abs(v[0]-p[0])+Math.abs(v[1]-p[1])<4));if(separated.length)candidates=separated;const p=candidates[Math.floor(r()*candidates.length)]||[room.cx,room.cy];reserved.push(p);return [...p];}
function chooseRoom(minDistance){let candidates=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i)&&v.d>minDistance);if(!candidates.length)candidates=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i));if(!candidates.length)return rooms[Math.min(rooms.length-1,rooms.length-2)];candidates.sort((a,b)=>b.d-a.d);const top=candidates.slice(Math.max(0,Math.floor(candidates.length*.2)),Math.ceil(candidates.length*.8)||candidates.length);const choice=top[Math.floor(r()*top.length)]||candidates[0];usedRooms.add(choice.i);return choice.room;}
const runeRoomList=[chooseRoom(exitDistance*.12),chooseRoom(exitDistance*.26),chooseRoom(exitDistance*.4)],runeRooms=runeRoomList.map(room=>rooms.indexOf(room)),runes=runeRoomList.map(room=>pickInRoom(room,8));if(['water-mirror','first-truth'].includes(ch.puzzle.mechanic?.id)){for(let i=0;i<3;i++){const old=runes[i],oldIndex=reserved.findIndex(p=>p[0]===old[0]&&p[1]===old[1]);if(oldIndex>=0)reserved.splice(oldIndex,1);const room=runeRoomList[i],candidates=[];for(let y=room.y+1;y<room.y+room.h-1;y++)for(let x=room.x+1;x<room.x+room.w-1;x++){if(tiles[y*w+x]||distances.seen[y*w+x]<8||reserved.some(p=>Math.abs(p[0]-x)+Math.abs(p[1]-y)<4))continue;if([[0,-1],[1,0],[0,1],[-1,0]].some(([dx,dy])=>inside(w,h,x+dx,y+dy)&&inside(w,h,x-dx,y-dy)&&!tiles[(y+dy)*w+x+dx]&&!tiles[(y-dy)*w+x-dx]))candidates.push([x,y]);}candidates.sort((a,b)=>Math.abs(a[0]-room.cx)+Math.abs(a[1]-room.cy)-Math.abs(b[0]-room.cx)-Math.abs(b[1]-room.cy));if(candidates.length)runes[i]=candidates[0];reserved.push(runes[i]);}}if(ch.puzzle.mechanic?.id==='broken-stairs')for(const index of runeRooms)rooms[index].depth=true;ch.puzzle.runeRooms=runeRooms;let secretRooms=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i)&&v.room.feature&&v.d>8);if(!secretRooms.length)secretRooms=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i)&&v.d>8);const mechanic=ch.puzzle.mechanic?.id||'',secretRoom=secretRooms[Math.floor(r()*secretRooms.length)]?.room||chooseRoom(0),secret=pickInRoom(secretRoom,8);if(mechanic==='currents'){function laneCandidates(interIsland){const out=[];for(const [[c1,r1],[c2,r2]] of edges){const sameIsland=Math.floor(c1/2)===Math.floor(c2/2)&&Math.floor(r1/2)===Math.floor(r2/2);if(interIsland?sameIsland:!sameIsland)continue;const a=roomAt(c1,r1),b=roomAt(c2,r2),route=path({w,h,tiles},[a.cx+.5,a.cy+.5],[b.cx+.5,b.cy+.5]),lanes=[];for(let i=1;i<route.length-1;i++){const previous=route[i-1],point=route[i],next=route[i+1],dx=Math.sign(next[0]-previous[0]),dy=Math.sign(next[1]-previous[1]);if((dx&&dy)||(!dx&&!dy))continue;const cell=[Math.floor(point[0]),Math.floor(point[1])],flat=cell[1]*w+cell[0];if(tiles[flat]||roomOwner[flat]>=0||reserved.some(p=>Math.abs(p[0]-cell[0])+Math.abs(p[1]-cell[1])<2))continue;const before=distances.seen[Math.floor(previous[1])*w+Math.floor(previous[0])],after=distances.seen[Math.floor(next[1])*w+Math.floor(next[0])];if(before<0||after<0)continue;lanes.push({cell,flow:before<=after?[dx,dy]:[-dx,-dy],distance:distances.seen[flat],offset:Math.abs(i-route.length/2)});}lanes.sort((x,y)=>x.offset-y.offset);if(lanes.length)out.push(lanes[0]);}return out;}function spacedLanes(candidates,targets,spacing=6){const chosen=[];for(const target of targets){const pool=candidates.filter(item=>!chosen.some(other=>Math.abs(other.cell[0]-item.cell[0])+Math.abs(other.cell[1]-item.cell[1])<spacing));pool.sort((a,b)=>Math.abs(a.distance-target)-Math.abs(b.distance-target));if(pool[0])chosen.push(pool[0]);}if(chosen.length<targets.length){const pool=candidates.filter(item=>!chosen.includes(item)).sort((a,b)=>a.distance-b.distance);while(chosen.length<targets.length&&pool.length){const next=pool.shift();if(!chosen.some(other=>Math.abs(other.cell[0]-next.cell[0])+Math.abs(other.cell[1]-next.cell[1])<3))chosen.push(next);}}return chosen;}const targets=[exitDistance*.24,exitDistance*.5,exitDistance*.76],currents=spacedLanes(laneCandidates(false),targets,8).sort((a,b)=>a.distance-b.distance),reflectionPool=laneCandidates(true),reflections=spacedLanes(reflectionPool,targets,8).filter(item=>currents.every(other=>Math.abs(other.cell[0]-item.cell[0])+Math.abs(other.cell[1]-item.cell[1])>=5));for(const item of reflectionPool.sort((a,b)=>a.distance-b.distance)){if(reflections.length>=3)break;if(currents.some(other=>Math.abs(other.cell[0]-item.cell[0])+Math.abs(other.cell[1]-item.cell[1])<5)||reflections.some(other=>Math.abs(other.cell[0]-item.cell[0])+Math.abs(other.cell[1]-item.cell[1])<5))continue;reflections.push(item);}ch.puzzle.currents=currents.map((item,index)=>({...item,index}));ch.puzzle.currentReflections=reflections.map((item,index)=>({...item,index}));reserved.push(...currents.map(item=>[...item.cell]),...reflections.map(item=>[...item.cell]));}const trapCount=huge?35:4+Math.floor(n/10),traps=Array.from({length:trapCount},()=>pick(7,false));
const checkpointRooms=[],markers=[],routeMechanics=['roots','folios','clock','lanterns','gates','lost-relays','garden-roots','name-gallery','detour-return'];if(routeMechanics.includes(mechanic)){const blockedRooms=new Set([...usedRooms,roomOwner[secret[1]*w+secret[0]]]),available=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!blockedRooms.has(v.i)&&!reserved.some(p=>p[0]===v.room.cx&&p[1]===v.room.cy));const count=mechanic==='detour-return'?1:3;for(let step=0;step<count;step++){const target=exitDistance*(step+1)/(count+1),candidates=available.filter(v=>!checkpointRooms.includes(v.i)).sort((a,b)=>Math.abs(a.d-target)-Math.abs(b.d-target));const choice=candidates[0];if(!choice)break;checkpointRooms.push(choice.i);const marker=[choice.room.cx,choice.room.cy];markers.push(marker);reserved.push(marker);}ch.puzzle.checkpointRooms=checkpointRooms;ch.puzzle.markers=markers;}
if(mechanic==='folios'){const cotes=['B-1?','C-2?','A-0?'];ch.puzzle.folioCatalog=markers.map((_,index)=>({cote:cotes[index],rank:index===0?2:index===1?3:1}));ch.puzzle.folioOrder=ch.puzzle.folioCatalog.map((entry,index)=>({index,rank:entry.rank})).sort((a,b)=>a.rank-b.rank).map(entry=>entry.index);ch.puzzle.signaturePageRequired=true;ch.puzzle.hiddenName='ELIA';ch.lore='Fragment 40 : La page aux signatures pâles garde un nom : ELIA. L’autre signature a été grattée dans la pierre.';}if(mechanic==='clock'){ch.puzzle.clockTargets=[0,1,2].map(index=>(index+1+blueprint.phase)%4);ch.puzzle.clockLabels=['12 h','3 h','6 h','9 h'];ch.puzzle.clockCourtyard=Math.floor(blueprint.rows/2)*blueprint.cols+Math.floor(blueprint.cols/2);ch.puzzle.clockCourtyardPoint=pickInRoom(rooms[ch.puzzle.clockCourtyard],0);}if(mechanic==='lanterns'){ch.puzzle.lanternTargets=[0,1,2].map(index=>1+((index+blueprint.phase)%3));ch.puzzle.lanternDirections=['nord','est','sud','ouest'];}if(mechanic==='gates'){const blocked=new Set([...usedRooms,...checkpointRooms,roomOwner[secret[1]*w+secret[0]]]),candidates=rooms.map((room,index)=>({room,index,d:distances.seen[room.cy*w+room.cx]})).filter(item=>!blocked.has(item.index)).sort((a,b)=>a.d-b.d);ch.puzzle.districtPlanPoint=pickInRoom(candidates[0]?.room||rooms[0],0);ch.puzzle.gateOrder=[1,2,0];ch.puzzle.gateSymbols=['croissant','spirale','aiguille'];ch.puzzle.districtPlanRequired=true;}
if(mechanic==='memories'){usedRooms.add(roomOwner[secret[1]*w+secret[0]]);const tombSymbols=['lanterne','voile','racine'],memoryLines=['L’Autre se rappelle la veilleuse qui resta allumée : ce souvenir repose sous la pierre gravée d’une lanterne.','L’Autre revoit le voile posé sur la dernière marque : cherche la tombe du voile.','Une racine dorée traversait le dernier jardin : ce souvenir rejoint la tombe aux racines.'],memoryOrder=shuffle([0,1,2],r),memoryFragments=memoryOrder.map((tombIndex,index)=>{const room=chooseRoom(exitDistance*.08);return {index,tombIndex,point:pickInRoom(room,0),text:memoryLines[tombIndex]};}),memoryTombs=tombSymbols.map((symbol,index)=>{const room=chooseRoom(exitDistance*.08);return {index,symbol,point:pickInRoom(room,0)};});ch.puzzle.memoryFragments=memoryFragments;ch.puzzle.memoryTombs=memoryTombs;ch.puzzle.memoryOrder=memoryOrder;}
if(mechanic==='convergence'){usedRooms.add(roomOwner[secret[1]*w+secret[0]]);const finalSymbols=['trace','lanterne','serment'],finalOrder=shuffle([0,1,2],r),finalNodes=finalSymbols.map((symbol,index)=>{const room=chooseRoom(exitDistance*.08);return {index,symbol,point:pickInRoom(room,0)};});ch.puzzle.finalNodes=finalNodes;ch.puzzle.finalOrder=finalOrder;ch.puzzle.finalRiddle=finalOrder.map(index=>finalSymbols[index]).join(' → ');}
const torchCount=huge?30:11;const torches=Array.from({length:torchCount},()=>pick(4,false)),runeLights={},directions=[[0,-1],[1,0],[0,1],[-1,0]];
function placeNear(point,preferDistance=2){const offsets=[];for(const distance of [preferDistance,1,3])for(let i=0;i<4;i++){const [dx,dy]=directions[(i+blueprint.phase)%4];offsets.push([dx*distance,dy*distance]);}for(const [dx,dy] of offsets){const x=point[0]+dx,y=point[1]+dy;if(inside(w,h,x,y)&&!tiles[y*w+x]&&!reserved.some(p=>p[0]===x&&p[1]===y)){const pos=[x,y];reserved.push(pos);return pos;}}return [...point];}
for(let step=0;step<3;step++){const runeIndex=ch.puzzle.order[step];if(ch.puzzle.rules[step]==='light'||mechanic==='lanterns'){const lamp=placeNear(runes[runeIndex],2);runeLights[runeIndex]=lamp;torches.push([...lamp]);}}
if(['reflections','mirror-split','water-mirror','first-truth'].includes(mechanic)){ch.puzzle.approaches={};for(let runeIndex=0;runeIndex<3;runeIndex++){const [rx,ry]=runes[runeIndex],order=[0,1,2,3].map(i=>directions[(i+runeIndex+blueprint.phase)%4]),bothSides=['water-mirror','first-truth'].includes(mechanic);ch.puzzle.approaches[runeIndex]=order.find(([dx,dy])=>inside(w,h,rx+dx,ry+dy)&&!tiles[(ry+dy)*w+rx+dx]&&(!bothSides||inside(w,h,rx-dx,ry-dy)&&!tiles[(ry-dy)*w+rx-dx]))||[0,-1];}}if(mechanic==='reflections'){ch.puzzle.reflectionClues=[];const basinInRoom=(room,origin,preferred)=>{const candidates=[];for(let y=room.y;y<room.y+room.h;y++)for(let x=room.x;x<room.x+room.w;x++){const distance=Math.hypot(x-origin[0],y-origin[1]);if(tiles[y*w+x]||distance<1.25||reserved.some(p=>p[0]===x&&p[1]===y))continue;candidates.push({point:[x,y],distance});}candidates.sort((a,b)=>Math.abs(a.distance-preferred)-Math.abs(b.distance-preferred));if(candidates.length){reserved.push(candidates[0].point);return candidates[0].point;}return placeNear(origin,preferred);};for(let runeIndex=0;runeIndex<3;runeIndex++){const flow=ch.puzzle.approaches[runeIndex],mirrorFlow=[-flow[0],-flow[1]],room=runeRoomList[runeIndex],realBasin=basinInRoom(room,runes[runeIndex],2),mirrorBasin=basinInRoom(room,runes[runeIndex],3);ch.puzzle.reflectionClues.push({point:realBasin,runeIndex,real:true,flow},{point:mirrorBasin,runeIndex,real:false,flow:mirrorFlow});}}
if(['prism','copper-alignment'].includes(mechanic)){ch.puzzle.aimPoints={};for(let runeIndex=0;runeIndex<3;runeIndex++){const point=placeNear(runes[runeIndex],2);ch.puzzle.aimPoints[runeIndex]=point;torches.push([...point]);}if(mechanic==='prism'){const prismPalette=['#9de5f1','#f4ca78','#c9a7e9','#abd487'];ch.puzzle.prismSolutions=[0,1,2].map(runeIndex=>1+(n+runeIndex)%3);ch.puzzle.prismColors=ch.puzzle.prismSolutions.map(orientation=>prismPalette[orientation]);}}
if(['echo-call'].includes(mechanic)){const choices=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i)&&!reserved.some(p=>p[0]===v.room.cx&&p[1]===v.room.cy)).sort((a,b)=>b.d-a.d);const target=choices[0]||{room:rooms[rooms.length-1],i:rooms.length-1};ch.puzzle.challengeRooms=[target.i];ch.puzzle.markers=[[target.room.cx,target.room.cy]];reserved.push([target.room.cx,target.room.cy]);}
if(['double-courts'].includes(mechanic)){const choices=rooms.map((room,i)=>({room,i,d:distances.seen[room.cy*w+room.cx]})).filter(v=>!usedRooms.has(v.i)&&!reserved.some(p=>p[0]===v.room.cx&&p[1]===v.room.cy)).sort((a,b)=>b.d-a.d).slice(0,2);ch.puzzle.challengeRooms=choices.map(v=>v.i);ch.puzzle.markers=choices.map(v=>[v.room.cx,v.room.cy]);reserved.push(...ch.puzzle.markers.map(p=>[...p]));}
if(mechanic==='vows'){ch.puzzle.oathPairs={};for(let runeIndex=0;runeIndex<3;runeIndex++){const otherMark=placeNear(runes[runeIndex],2);ch.puzzle.oathPairs[runeIndex]={player:[...runes[runeIndex]],other:otherMark};}}
const decoy=['trace-reading','first-truth'].includes(mechanic)?pickInRoom(chooseRoom(8),8):null;
const trapStyles=Array.from({length:traps.length},()=>blueprint.trapStyle),riftSlots=new Set(huge&&blueprint.trapStyle==='abime'?[4,15,26]:[]),hugeTrapOrder=huge?shuffle(Array.from({length:traps.length},(_,i)=>i).filter(i=>!riftSlots.has(i)),r):[],alarmSlots=new Set(hugeTrapOrder.slice(0,3)),slowSlots=new Set(hugeTrapOrder.slice(3,15-riftSlots.size)),trapKinds=Array.from({length:traps.length},(_,i)=>{if(huge){if(riftSlots.has(i))return 'rift';return alarmSlots.has(i)?'alarm':slowSlots.has(i)?'slow':'fatal';}if(n>=10&&(i+n)%11===0)return 'alarm';return (i+n)%4===0?'slow':'fatal';});
if(mechanic==='bridge-vibrations'){const cut=1+Math.floor(Math.floor(cols/2)*cellW),spans=[];for(let y=1;y<h-1;){if(tiles[y*w+cut-1]||tiles[y*w+cut]){y++;continue;}const start=y;while(y<h-1&&!tiles[y*w+cut-1]&&!tiles[y*w+cut])y++;spans.push([start,y-1]);}if(spans.length===3){const safeBridge=Math.floor(r()*spans.length),bridges=spans.map(([from,to],index)=>({index,cell:[cut,Math.floor((from+to)/2)],safe:index===safeBridge})),riftIndices=trapKinds.map((kind,index)=>kind==='rift'?index:-1).filter(index=>index>=0);for(const bridge of bridges)reserved.push([...bridge.cell]);for(let index=0;index<bridges.length;index++){let trapIndex=riftIndices[index];if(trapIndex<0){trapIndex=traps.length;traps.push([...bridges[index].cell]);trapKinds.push(bridges[index].safe?'bridge-safe':'bridge-fail');trapStyles.push(blueprint.trapStyle);}else{const old=[...traps[trapIndex]],oldReservation=reserved.findIndex(point=>point[0]===old[0]&&point[1]===old[1]);if(oldReservation>=0)reserved.splice(oldReservation,1);for(let otherIndex=0;otherIndex<traps.length;otherIndex++)if(otherIndex!==trapIndex&&traps[otherIndex][0]===bridges[index].cell[0]&&traps[otherIndex][1]===bridges[index].cell[1])traps[otherIndex]=pick(7,false);traps[trapIndex]=[...bridges[index].cell];trapKinds[trapIndex]=bridges[index].safe?'bridge-safe':'bridge-fail';} }ch.puzzle.bridges=bridges;}}
const enemies=[];const count=huge?15+Math.floor(n/8):Math.max(1,Math.min(8,Math.floor(n/5)+1));for(let i=0;i<count;i++){const p=pick(12,false);let kind=ch.enemySet[(i+n)%ch.enemySet.length];if(ch.special&&i===0)kind='warden';enemies.push({id:i,kind,x:p[0]+.5,y:p[1]+.5,home:[p[0]+.5,p[1]+.5],heading:r()*Math.PI*2,seed:r()*10,speed:kind==='golem'?.44:kind==='warden'?1.16:.8,patrolPhase:r()*6,alert:0});}
if(mechanic==='sentinels'){
  const clearSight=(a,b)=>{const d=Math.hypot(b[0]-a[0],b[1]-a[1]),steps=Math.ceil(d*4);for(let i=1;i<steps;i++){const t=i/steps,x=Math.floor(a[0]+(b[0]-a[0])*t),y=Math.floor(a[1]+(b[1]-a[1])*t);if(tiles[y*w+x])return false;}return true;};
  const focusCandidates=rooms.map((room,index)=>{const point=[room.cx+.5,room.cy+.5],visibleRooms=rooms.map((target,i)=>({target,i})).filter(({target,i})=>i!==index&&clearSight(point,[target.cx+.5,target.cy+.5])).map(({i})=>i),runeClearance=Math.min(...runes.map(([x,y])=>Math.hypot(point[0]-x-.5,point[1]-y-.5))),centerDistance=Math.hypot(room.cx-w/2,room.cy-h/2);return {room,index,point,visibleRooms,runeClearance,score:visibleRooms.length*100+runeClearance*2-centerDistance*.1};}).filter(candidate=>candidate.runeClearance>=10&&candidate.visibleRooms.length>=3).sort((a,b)=>b.score-a.score);
  const focusChoice=focusCandidates[0]||{room:rooms[Math.floor(rooms.length/2)],index:Math.floor(rooms.length/2),point:[rooms[Math.floor(rooms.length/2)].cx+.5,rooms[Math.floor(rooms.length/2)].cy+.5],visibleRooms:rooms.map((_,i)=>i)};
  const focus=focusChoice.point,sentryCandidates=enemies.filter(enemy=>enemy.kind==='sentry').slice(0,3),otherEnemies=enemies.filter(enemy=>!sentryCandidates.includes(enemy)),placements=[];
  const roomCells=index=>{const room=rooms[index],cells=[];for(let y=room.y+1;y<room.y+room.h-1;y++)for(let x=room.x+1;x<room.x+room.w-1;x++)if(!tiles[y*w+x]&&roomOwner[y*w+x]===index)cells.push([x+.5,y+.5]);return cells;};
  const availableRooms=focusChoice.visibleRooms.filter(index=>index!==focusChoice.index&&!usedRooms.has(index));
  while(placements.length<3){let candidates=[];for(const index of availableRooms){if(placements.some(item=>item.room===index))continue;for(const point of roomCells(index)){const clearanceToRune=Math.min(...runes.map(([x,y])=>Math.hypot(point[0]-x-.5,point[1]-y-.5))),clearanceToTrap=Math.min(...traps.map(([x,y])=>Math.hypot(point[0]-x-.5,point[1]-y-.5))),clearanceToTorch=Math.min(...torches.map(([x,y])=>Math.hypot(point[0]-x-.5,point[1]-y-.5))),clearanceToEnemy=Math.min(...otherEnemies.map(enemy=>Math.hypot(point[0]-enemy.x,point[1]-enemy.y)));if(clearanceToRune<8||clearanceToTrap<4||clearanceToTorch<2.5||clearanceToEnemy<3.5||!clearSight(point,focus))continue;const spread=placements.length?Math.min(...placements.map(item=>Math.hypot(point[0]-item.point[0],point[1]-item.point[1]))):Math.hypot(point[0]-focus[0],point[1]-focus[1]);candidates.push({room:index,point,spread});}}candidates.sort((a,b)=>b.spread-a.spread);if(!candidates.length)break;placements.push(candidates[0]);}
  const sync={period:16,amplitude:.82,tolerance:.32,focus};for(let index=0;index<Math.min(3,sentryCandidates.length,placements.length);index++){const tower=sentryCandidates[index],point=placements[index].point;tower.x=point[0];tower.y=point[1];tower.home=[point[0],point[1]];tower.heading=Math.atan2(focus[1]-point[1],focus[0]-point[0]);tower.syncSweep={period:sync.period,amplitude:sync.amplitude,baseHeading:tower.heading,range:Math.hypot(focus[0]-point[0],focus[1]-point[1])+1.5};}
  ch.puzzle.sentinelTowers=sentryCandidates.slice(0,Math.min(3,placements.length)).map(tower=>tower.id);ch.puzzle.sentinelFocusRoom=focusChoice.index;ch.puzzle.sentinelSync=sync;
}
if(mechanic==='golems'){const targets=enemies.filter(e=>e.kind==='golem').slice(0,3).map((enemy,index)=>{const home=[...enemy.home],marker=placeNear([Math.floor(home[0]),Math.floor(home[1])],2);return {enemyId:enemy.id,home,marker,index};});ch.puzzle.golemTargets=targets;ch.puzzle.markers=targets.map(target=>[...target.marker]);}
// Keep each sound trap relevant: if its generated position has no mobile listener
// in range, move it to a clear floor tile near a patrol route without crowding objectives.
if(huge)for(let i=0;i<traps.length;i++)if(trapKinds[i]==='alarm'){
  const profile=trapEffectProfiles[trapStyles[i]],radius=profile?.alarmRadius||11,hasListener=enemies.some(e=>e.kind!=='sentry'&&Math.hypot(e.x-traps[i][0]-.5,e.y-traps[i][1]-.5)<radius);
  if(hasListener)continue;
  const old=traps[i],oldIndex=reserved.findIndex(p=>p[0]===old[0]&&p[1]===old[1]);if(oldIndex>=0)reserved.splice(oldIndex,1);
  const protectedPoints=reserved.filter(p=>!enemies.some(e=>Math.floor(e.x)===p[0]&&Math.floor(e.y)===p[1]));
  const candidates=distances.queue.filter(([x,y])=>!tiles[y*w+x]&&!protectedPoints.some(p=>Math.abs(p[0]-x)+Math.abs(p[1]-y)<5)&&enemies.some(e=>e.kind!=='sentry'&&Math.hypot(e.x-x-.5,e.y-y-.5)>=4.1&&Math.hypot(e.x-x-.5,e.y-y-.5)<radius-.5));
  const replacement=candidates[Math.floor(r()*candidates.length)];if(replacement){traps[i]=[...replacement];reserved.push([...replacement]);}else reserved.push([...old]);
}
return {...ch,w,h,tiles,rooms,start,exit,runes,secret,...(decoy?{decoy}:{}),traps,trapKinds,trapStyles,torches,runeLights,enemies,mapVersion:[37,39,40,41,42,43,44,46,48,49,50].includes(n)?10:9,seed:n*90467+1711};}
function path(world,a,b,max=world.w*world.h){const w=world.w,h=world.h,start=[Math.floor(a[0]),Math.floor(a[1])],end=[Math.floor(b[0]),Math.floor(b[1])];if(start[0]===end[0]&&start[1]===end[1])return [end];const seen=new Uint8Array(w*h),prev=new Int32Array(w*h).fill(-1),q=[start[1]*w+start[0]];seen[q[0]]=1;let head=0,goal=end[1]*w+end[0];while(head<q.length&&head<max){const idx=q[head++],x=idx%w,y=Math.floor(idx/w);if(idx===goal)break;for(const d of [1,-1,w,-w]){const ni=idx+d,nx=ni%w,ny=Math.floor(ni/w);if(nx<1||ny<1||nx>=w-1||ny>=h-1||Math.abs(nx-x)+Math.abs(ny-y)!==1||seen[ni]||world.tiles[ni])continue;seen[ni]=1;prev[ni]=idx;q.push(ni);}}if(!seen[goal])return [];const out=[];let cur=goal;while(cur!==q[0]){out.push([cur%w+.5,Math.floor(cur/w)+.5]);cur=prev[cur];if(cur<0)break;}return out.reverse();}
const api={chapters:Array.from({length:50},(_,i)=>chapter(i+1)),chapter,generate,path,bfs,puzzleRules,runeOrders,trapNames,trapEffectProfiles};root.LAJContent=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
